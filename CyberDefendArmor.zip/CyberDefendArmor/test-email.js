import axios from 'axios';

/**
 * This script tests the email functionality of the application
 * by sending a test email using the Brevo integration
 */
async function testEmailService() {
  try {
    console.log('Sending test email...');
    
    // Call the test email endpoint
    const response = await axios.post('http://localhost:5000/api/email/test');
    
    if (response.data.success) {
      console.log('✅ Test email sent successfully!');
      console.log('Check your inbox at capitalcopycraft@gmail.com');
    } else {
      console.error('❌ Failed to send test email:', response.data.message);
    }
  } catch (error) {
    console.error('❌ Error testing email service:', error.message);
    if (error.response) {
      console.error('Server response:', error.response.data);
    }
  }
}

// Run the test
testEmailService();