// Simple script to test real-time WebSocket notifications
import axios from 'axios';

// Test vulnerability data
const vulnerability = {
  severity: "critical",
  title: "Test Critical XSS Vulnerability",
  description: "This is a simulated vulnerability for testing real-time notifications",
  targetUrl: "https://example.com/vulnerable-page",
  reportId: "test-" + Date.now()
};

// Send the test notification
async function sendTestNotification() {
  try {
    console.log('Sending test notification...');
    const response = await axios.post('http://localhost:5000/api/direct-report/test', vulnerability);
    console.log('Response:', response.data);
    console.log('Notification sent! Check the UI for a toast notification.');
  } catch (error) {
    console.error('Error sending notification:', error.response?.data || error.message);
  }
}

// Execute the test
sendTestNotification();