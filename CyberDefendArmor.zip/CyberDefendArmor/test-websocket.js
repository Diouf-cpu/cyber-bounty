import axios from 'axios';

// Test data for a vulnerability report
const vulnerability = {
  reportId: "test-" + Date.now(), 
  targetUrl: "https://example.com",
  title: "Test XSS Vulnerability",
  severity: "critical",
  description: "This is a test Cross-Site Scripting vulnerability found during testing",
  vulnerabilityType: "xss",
  timestamp: new Date().toISOString(),
  impact: "Could allow attackers to steal cookies and hijack user sessions",
  proofOfConcept: "<script>alert('XSS')</script>",
  stepsToReproduce: "1. Go to the search page\n2. Enter payload\n3. Submit the form",
  cvssScore: "8.5",
  scanId: 12345
};

// Function to simulate a direct report
async function simulateDirectReport() {
  try {
    // First, test WebSocket connection by getting all reports
    const reportsResponse = await axios.get('http://localhost:5000/api/direct-reports');
    console.log('Current reports:', reportsResponse.data);
    
    // Now directly send the test report
    const response = await axios.post('http://localhost:5000/api/direct-report/test', vulnerability);
    console.log('Response:', response.data);
  } catch (error) {
    console.error('Error:', error.response ? error.response.data : error.message);
  }
}

// Run the test
simulateDirectReport();