/**
 * This script tests the report generation and email sending functionality
 * with detailed debugging information
 */
import { generatePdfReport, generateWordReport, saveReportToDisk } from './server/reportGenerator.js';
import { sendPdfReportEmail, sendWordReportEmail } from './server/brevoEmailService.js';

// Create a sample vulnerability for testing
const sampleVulnerabilities = [
  {
    id: 1,
    title: "SQL Injection Vulnerability",
    description: "A SQL injection vulnerability exists in the login form that allows attackers to bypass authentication.",
    severity: "high",
    status: "open",
    location: "https://example.com/login",
    details: "The login endpoint doesn't properly sanitize user input, allowing SQL injection attacks.",
    request: "POST /login HTTP/1.1\nHost: example.com\nContent-Type: application/x-www-form-urlencoded\n\nusername=admin'--&password=anything",
    response: "HTTP/1.1 200 OK\nContent-Type: application/json\n\n{\"success\":true,\"message\":\"Login successful\"}",
    remediation: "Implement prepared statements or parameterized queries to prevent SQL injection.",
    impact: "An attacker could bypass authentication and gain unauthorized access to user accounts and sensitive data.",
    scanId: 1
  },
  {
    id: 2,
    title: "Cross-Site Scripting (XSS) Vulnerability",
    description: "A stored XSS vulnerability exists in the comment section that allows attackers to inject malicious scripts.",
    severity: "medium",
    status: "open",
    location: "https://example.com/blog/post/1",
    details: "User input from comments is not properly sanitized before being displayed on the page.",
    request: "POST /blog/post/1/comment HTTP/1.1\nHost: example.com\nContent-Type: application/json\n\n{\"comment\":\"<script>alert('XSS')</script>\"}",
    response: "HTTP/1.1 200 OK\nContent-Type: application/json\n\n{\"success\":true,\"message\":\"Comment posted\"}",
    remediation: "Implement proper output encoding and content security policy (CSP).",
    impact: "An attacker could steal session cookies, perform actions on behalf of other users, or deface the website.",
    scanId: 1
  }
];

// Target URL for the test report
const targetUrl = "https://example.com";

// Buffer to store the PDF/DOCX
let pdfBuffer, docxBuffer;

/**
 * Test PDF report generation
 */
async function testPdfReportGeneration() {
  console.log("===== TESTING PDF REPORT GENERATION =====");
  
  try {
    console.log(`Generating PDF report for ${sampleVulnerabilities.length} vulnerabilities on ${targetUrl}`);
    pdfBuffer = await generatePdfReport(sampleVulnerabilities, targetUrl);
    
    console.log(`PDF generation complete. Buffer size: ${pdfBuffer.length} bytes`);
    
    // Save to disk for verification
    const pdfPath = saveReportToDisk(
      pdfBuffer, 
      `test_report_${targetUrl.replace(/[^a-zA-Z0-9]/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`
    );
    
    console.log(`PDF report saved to disk at: ${pdfPath}`);
    return pdfBuffer;
  } catch (error) {
    console.error("Error in PDF report generation:", error);
    if (error.stack) {
      console.error(error.stack);
    }
  }
}

/**
 * Test Word report generation
 */
async function testWordReportGeneration() {
  console.log("===== TESTING WORD REPORT GENERATION =====");
  
  try {
    console.log(`Generating Word report for ${sampleVulnerabilities.length} vulnerabilities on ${targetUrl}`);
    docxBuffer = await generateWordReport(sampleVulnerabilities, targetUrl);
    
    console.log(`Word document generation complete. Buffer size: ${docxBuffer.length} bytes`);
    
    // Save to disk for verification
    const docxPath = saveReportToDisk(
      docxBuffer, 
      `test_report_${targetUrl.replace(/[^a-zA-Z0-9]/g, '_')}_${new Date().toISOString().split('T')[0]}.docx`
    );
    
    console.log(`Word report saved to disk at: ${docxPath}`);
    return docxBuffer;
  } catch (error) {
    console.error("Error in Word report generation:", error);
    if (error.stack) {
      console.error(error.stack);
    }
  }
}

/**
 * Test sending PDF report via email
 */
async function testPdfEmailSending(pdfBuffer) {
  console.log("===== TESTING PDF REPORT EMAIL SENDING =====");
  
  if (!pdfBuffer) {
    console.error("PDF buffer is not available, cannot test email sending");
    return;
  }
  
  try {
    console.log(`Sending PDF report email for ${targetUrl}`);
    const success = await sendPdfReportEmail(sampleVulnerabilities, targetUrl, pdfBuffer);
    
    if (success) {
      console.log("PDF report email sent successfully");
    } else {
      console.error("Failed to send PDF report email");
    }
    
    return success;
  } catch (error) {
    console.error("Error in PDF email sending:", error);
    if (error.stack) {
      console.error(error.stack);
    }
  }
}

/**
 * Test sending Word report via email
 */
async function testWordEmailSending(docxBuffer) {
  console.log("===== TESTING WORD REPORT EMAIL SENDING =====");
  
  if (!docxBuffer) {
    console.error("Word buffer is not available, cannot test email sending");
    return;
  }
  
  try {
    console.log(`Sending Word report email for ${targetUrl}`);
    const success = await sendWordReportEmail(sampleVulnerabilities, targetUrl, docxBuffer);
    
    if (success) {
      console.log("Word report email sent successfully");
    } else {
      console.error("Failed to send Word report email");
    }
    
    return success;
  } catch (error) {
    console.error("Error in Word email sending:", error);
    if (error.stack) {
      console.error(error.stack);
    }
  }
}

// Run tests sequentially
async function runTests() {
  try {
    console.log("Starting PDF report tests...");
    const pdfBuffer = await testPdfReportGeneration();
    if (pdfBuffer) {
      await testPdfEmailSending(pdfBuffer);
    }
    
    console.log("\nStarting Word report tests...");
    const docxBuffer = await testWordReportGeneration();
    if (docxBuffer) {
      await testWordEmailSending(docxBuffer);
    }
    
    console.log("\nAll tests completed.");
  } catch (error) {
    console.error("Error during test execution:", error);
  }
}

// Run the test suite
runTests();