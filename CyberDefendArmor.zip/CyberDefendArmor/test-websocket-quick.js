import axios from 'axios';
import WebSocket from 'ws';

// Test vulnerability for WebSocket notification
const vulnerability = {
  reportId: "test-websocket-" + Date.now(), 
  targetUrl: "https://example.org",
  title: "CSRF Vulnerability in Settings Page",
  severity: "medium",
  description: "A Cross-Site Request Forgery vulnerability allows attackers to change user settings",
  vulnerabilityType: "csrf"
};

// Function to establish WebSocket connection and send test notification
async function testWebSocketNotifications() {
  // Create WebSocket connection
  const ws = new WebSocket('ws://localhost:5000/ws');
  
  ws.on('open', async () => {
    console.log('WebSocket connected!');
    
    try {
      // First wait for connection message
      await new Promise(resolve => {
        ws.once('message', (data) => {
          const message = JSON.parse(data.toString());
          console.log('Connection established:', message);
          resolve();
        });
      });
      
      // Now send the test vulnerability via API
      console.log('Sending test vulnerability notification...');
      const response = await axios.post('http://localhost:5000/api/direct-report/test', vulnerability);
      console.log('Test notification API response:', response.data);
      
      // Wait for notification to come back via WebSocket
      await new Promise(resolve => {
        ws.once('message', (data) => {
          const notification = JSON.parse(data.toString());
          console.log('Received WebSocket notification:', notification);
          
          if (notification.type === 'vulnerability') {
            console.log('SUCCESS: Notification system is working!');
          }
          
          resolve();
        });
      });
    } catch (error) {
      console.error('Error:', error.message);
    } finally {
      ws.close();
      console.log('Test completed.');
    }
  });
  
  ws.on('error', (err) => {
    console.error('WebSocket error:', err);
  });
}

// Run test
testWebSocketNotifications();