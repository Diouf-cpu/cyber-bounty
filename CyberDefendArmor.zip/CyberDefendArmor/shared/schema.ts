import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table for authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

// Scans table to keep track of vulnerability scans
export const scans = pgTable("scans", {
  id: serial("id").primaryKey(),
  targetUrl: text("target_url").notNull(),
  status: text("status").notNull().default("pending"), // pending, in_progress, completed, failed
  startedAt: timestamp("started_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
  scanType: text("scan_type").notNull(), // quick, comprehensive
  vulnerabilityTypes: text("vulnerability_types").array(), // sql_injection, xss, csrf, etc.
  scanIntensity: integer("scan_intensity").notNull().default(3), // 1-5 scale
  hasPermission: boolean("has_permission").notNull(), // Ethical check
});

// Vulnerabilities found during scans
export const vulnerabilities = pgTable("vulnerabilities", {
  id: serial("id").primaryKey(),
  scanId: integer("scan_id").notNull(), // Link to the scan
  title: text("title").notNull(),
  type: text("type").notNull(), // sql_injection, xss, csrf, etc.
  severity: text("severity").notNull(), // critical, high, medium, low
  location: text("location").notNull(), // URL or endpoint where the vulnerability was found
  description: text("description").notNull(),
  stepsToReproduce: text("steps_to_reproduce").notNull(),
  impact: text("impact").notNull(),
  remediation: text("remediation").notNull(),
  proofOfConcept: text("proof_of_concept"),
  cvssScore: text("cvss_score"),
  detectedAt: timestamp("detected_at").notNull().defaultNow(),
  status: text("status").notNull().default("open"), // open, fixed, false_positive, etc.
});

// Reports generated from scan results
export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  scanId: integer("scan_id").notNull(), // Link to the scan
  createdAt: timestamp("created_at").notNull().defaultNow(),
  format: text("format").notNull(), // pdf, docx, html
  vulnerabilityIds: integer("vulnerability_ids").array(), // Specific vulnerabilities included
  sections: text("sections").array(), // executive_summary, technical_details, etc.
  reportPath: text("report_path"), // Path to the generated report file
});

// Bug bounty submissions
export const bountySubmissions = pgTable("bounty_submissions", {
  id: serial("id").primaryKey(),
  vulnerabilityId: integer("vulnerability_id").notNull(), // Link to the vulnerability
  platform: text("platform").notNull(), // hackerone, bugcrowd, etc.
  title: text("title").notNull(),
  description: text("description").notNull(),
  stepsToReproduce: text("steps_to_reproduce").notNull(),
  impact: text("impact").notNull(),
  severity: text("severity").notNull(), // critical, high, medium, low
  suggestedFix: text("suggested_fix"),
  submittedAt: timestamp("submitted_at").notNull().defaultNow(),
  status: text("status").notNull().default("submitted"), // submitted, accepted, rejected, paid
  reward: text("reward"), // Amount received if paid
});

// Create insert schemas using drizzle-zod
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertScanSchema = createInsertSchema(scans).omit({
  id: true,
  completedAt: true,
});

export const insertVulnerabilitySchema = createInsertSchema(vulnerabilities).omit({
  id: true,
});

export const insertReportSchema = createInsertSchema(reports).omit({
  id: true,
  reportPath: true,
});

export const insertBountySubmissionSchema = createInsertSchema(bountySubmissions).omit({
  id: true,
});

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertScan = z.infer<typeof insertScanSchema>;
export type Scan = typeof scans.$inferSelect;

export type InsertVulnerability = z.infer<typeof insertVulnerabilitySchema>;
export type Vulnerability = typeof vulnerabilities.$inferSelect;

export type InsertReport = z.infer<typeof insertReportSchema>;
export type Report = typeof reports.$inferSelect;

export type InsertBountySubmission = z.infer<typeof insertBountySubmissionSchema>;
export type BountySubmission = typeof bountySubmissions.$inferSelect;
