// Common types used throughout the application

// Vulnerability types for scanning
export enum VulnerabilityType {
  SQL_INJECTION = "sql_injection",
  XSS = "xss",
  CSRF = "csrf",
  DIRECTORY_TRAVERSAL = "directory_traversal",
  AUTH_BYPASS = "auth_bypass",
  OPEN_REDIRECT = "open_redirect",
  IDOR = "idor",
  MISCONFIGURATION = "misconfiguration",
  WEAK_CRYPTO = "weak_crypto",
  OTHER = "other"
}

// Severity levels
export enum SeverityLevel {
  CRITICAL = "critical",
  HIGH = "high",
  MEDIUM = "medium",
  LOW = "low",
  INFO = "info"
}

// Scan status types
export enum ScanStatus {
  PENDING = "pending",
  IN_PROGRESS = "in_progress",
  COMPLETED = "completed",
  FAILED = "failed"
}

// Scan types
export enum ScanType {
  QUICK = "quick",
  COMPREHENSIVE = "comprehensive"
}

// Vulnerability status
export enum VulnerabilityStatus {
  OPEN = "open",
  FIXED = "fixed",
  FALSE_POSITIVE = "false_positive",
  WONT_FIX = "wont_fix"
}

// Report formats
export enum ReportFormat {
  PDF = "pdf",
  DOCX = "docx",
  HTML = "html"
}

// Report sections
export enum ReportSection {
  EXECUTIVE_SUMMARY = "executive_summary",
  TECHNICAL_DETAILS = "technical_details",
  REMEDIATION = "remediation",
  SCREENSHOTS = "screenshots",
  RISK_ANALYSIS = "risk_analysis",
  APPENDIX = "appendix"
}

// Bounty platform types
export enum BountyPlatform {
  HACKERONE = "hackerone",
  BUGCROWD = "bugcrowd",
  SYNACK = "synack",
  INTIGRITI = "intigriti",
  YESWEHACK = "yeswehack",
  OTHER = "other"
}

// Bounty submission status
export enum SubmissionStatus {
  SUBMITTED = "submitted",
  ACCEPTED = "accepted",
  REJECTED = "rejected",
  NEEDS_INFO = "needs_info",
  PAID = "paid"
}

// Scan stats for the dashboard
export interface ScanStats {
  activeScans: number;
  totalVulnerabilities: number;
  reportsGenerated: number;
  bountySubmissions: number;
}

// Vulnerability distribution for dashboard
export interface VulnerabilityDistribution {
  critical: number;
  high: number;
  medium: number;
  low: number;
}

// Vulnerability type distribution for dashboard
export interface VulnerabilityTypeDistribution {
  sqlInjection: number;
  xss: number;
  csrf: number;
  directoryTraversal: number;
  other: number;
}

// Real-time reporting configuration
export interface DirectReportConfig {
  enabled: boolean;
  reportEmail: string; // Email to send direct reports to
  includeScreenshots: boolean;
  includePoc: boolean;
}

// Notification methods for real-time alerts
export enum NotificationMethod {
  EMAIL = "email",
  WEBHOOK = "webhook"
}

// Direct vulnerability report structure for sending to requestor
export interface DirectVulnerabilityReport {
  timestamp: string;
  targetUrl: string;
  reportId: string; // Unique identifier for the report
  title: string;
  severity: string;
  description: string;
  location?: string;
  impact?: string;
  details?: string;
  request?: string;
  response?: string | null;
  remediation?: string;
  vulnerabilityType?: string;
  stepsToReproduce?: string;
  proofOfConcept?: string;
  cvssScore?: string;
  scanId?: number;
}
