import WebSocket from 'ws';

// Create a WebSocket connection to the server
const ws = new WebSocket('ws://localhost:5000/ws');

// Connection opened event
ws.on('open', () => {
  console.log('Connected to WebSocket server');
  
  // Send a ping message to test the connection
  ws.send(JSON.stringify({ type: 'ping' }));
});

// Handle messages from the server
ws.on('message', (data) => {
  try {
    const message = JSON.parse(data.toString());
    console.log('Received message:', message);
    
    // If we receive a vulnerability notification, log it in detail
    if (message.type === 'vulnerability') {
      console.log('========================');
      console.log('VULNERABILITY DETECTED!');
      console.log('========================');
      console.log(`Title: ${message.title}`);
      console.log(`Severity: ${message.severity}`);
      console.log(`Target: ${message.targetUrl}`);
      console.log(`Timestamp: ${message.timestamp}`);
      console.log(`Report ID: ${message.reportId}`);
      console.log('========================');
    }
  } catch (error) {
    console.error('Error parsing message:', error);
  }
});

// Handle connection close
ws.on('close', () => {
  console.log('Disconnected from WebSocket server');
});

// Handle errors
ws.on('error', (error) => {
  console.error('WebSocket error:', error);
});

// Keep the script running
console.log('WebSocket client is listening for vulnerability notifications...');
console.log('Press Ctrl+C to exit');