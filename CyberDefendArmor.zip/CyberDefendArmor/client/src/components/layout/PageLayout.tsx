import { useState } from "react";
import Sidebar from "./Sidebar";
import MobileHeader from "./MobileHeader";
import { Sheet, SheetContent } from "@/components/ui/sheet";

type PageLayoutProps = {
  children: React.ReactNode;
};

export default function PageLayout({ children }: PageLayoutProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen flex bg-neutral-950 text-gray-50">
      <Sidebar />
      <MobileHeader onMenuClick={() => setMobileMenuOpen(true)} />
      
      <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
        <SheetContent side="left" className="p-0 w-64 sm:max-w-none">
          <Sidebar />
        </SheetContent>
      </Sheet>
      
      <div className="flex-1 min-w-0 overflow-auto pb-16 pt-16 md:pt-0 h-screen">
        {children}
      </div>
    </div>
  );
}
