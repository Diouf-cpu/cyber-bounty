import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  ShieldAlert,
  Search,
  Bug,
  FileText,
  Trophy,
  Code,
  MonitorSmartphone,
  RefreshCcw,
  FolderOpen,
  User,
  Settings
} from "lucide-react";

type SidebarItemProps = {
  href: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  active?: boolean;
};

const SidebarItem = ({ href, icon, children, active = false }: SidebarItemProps) => {
  return (
    <Link href={href}>
      <div
        className={cn(
          "flex items-center space-x-3 p-2 mb-1 rounded-md cursor-pointer",
          active
            ? "bg-primary bg-opacity-20 text-primary border-l-4 border-primary"
            : "hover:bg-neutral-800 hover:bg-opacity-40 text-gray-300"
        )}
      >
        <span className="w-5 text-center">{icon}</span>
        <span>{children}</span>
      </div>
    </Link>
  );
};

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="w-64 bg-neutral-900 shadow-lg flex-shrink-0 hidden md:flex md:flex-col">
      <div className="p-4 border-b border-gray-700">
        <div className="flex items-center space-x-2">
          <ShieldAlert className="text-primary text-2xl" />
          <h1 className="text-xl font-bold">SecurityBounty</h1>
        </div>
        <div className="text-xs text-gray-400 mt-1">Ethical Penetration Testing</div>
      </div>

      <div className="p-4 flex-grow">
        <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">
          Main Menu
        </div>
        <nav>
          <SidebarItem href="/" icon={<ShieldAlert size={18} />} active={location === "/"}>
            Dashboard
          </SidebarItem>
          <SidebarItem href="/new-scan" icon={<Search size={18} />} active={location === "/new-scan"}>
            New Scan
          </SidebarItem>
          <SidebarItem href="/vulnerabilities" icon={<Bug size={18} />} active={location === "/vulnerabilities"}>
            Vulnerabilities
          </SidebarItem>
          <SidebarItem href="/reports" icon={<FileText size={18} />} active={location === "/reports"}>
            Reports
          </SidebarItem>
          <SidebarItem
            href="/bounty-submissions"
            icon={<Trophy size={18} />}
            active={location === "/bounty-submissions"}
          >
            Bounty Submissions
          </SidebarItem>
        </nav>

        <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mt-6 mb-3">
          Tools
        </div>
        <nav>
          <SidebarItem href="#" icon={<Code size={18} />} active={false}>
            SQL Injection
          </SidebarItem>
          <SidebarItem href="#" icon={<MonitorSmartphone size={18} />} active={false}>
            XSS Scanner
          </SidebarItem>
          <SidebarItem href="#" icon={<RefreshCcw size={18} />} active={false}>
            CSRF Tester
          </SidebarItem>
          <SidebarItem href="#" icon={<FolderOpen size={18} />} active={false}>
            Directory Scanner
          </SidebarItem>
        </nav>
      </div>

      <div className="p-4 border-t border-gray-700">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center">
            <User size={16} />
          </div>
          <div>
            <div className="text-sm font-medium">Security Researcher</div>
            <div className="text-xs text-gray-400">Ethical Hacker</div>
          </div>
          <div className="ml-auto">
            <button className="text-gray-400 hover:text-gray-200">
              <Settings size={16} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
