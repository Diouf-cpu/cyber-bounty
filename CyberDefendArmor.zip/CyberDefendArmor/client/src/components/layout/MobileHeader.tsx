import { ShieldAlert, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";

type MobileHeaderProps = {
  onMenuClick: () => void;
};

export default function MobileHeader({ onMenuClick }: MobileHeaderProps) {
  return (
    <div className="md:hidden bg-neutral-900 fixed top-0 left-0 w-full z-10 border-b border-gray-700">
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center space-x-2">
          <ShieldAlert className="text-primary text-2xl" />
          <h1 className="text-xl font-bold">SecurityBounty</h1>
        </div>
        <Button variant="ghost" size="icon" onClick={onMenuClick} className="text-gray-300 hover:text-white">
          <Menu size={20} />
        </Button>
      </div>
    </div>
  );
}
