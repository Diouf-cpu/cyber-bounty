import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertBountySubmissionSchema } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormDescription } from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Upload } from "lucide-react";

type BountySubmissionModalProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  vulnerabilityId?: number;
};

const formSchema = insertBountySubmissionSchema.extend({
  platform: z.string().min(1, "Please select a platform"),
  vulnerabilityId: z.number().min(1, "Please select a vulnerability"),
  title: z.string().min(1, "Title is required"),
  description: z.string().min(10, "Please provide a detailed description"),
  stepsToReproduce: z.string().min(10, "Please provide clear steps to reproduce"),
  impact: z.string().min(10, "Please describe the potential impact"),
  severity: z.string().min(1, "Please select a severity level"),
});

export default function BountySubmissionModal({ 
  open, 
  onOpenChange,
  vulnerabilityId 
}: BountySubmissionModalProps) {
  const { toast } = useToast();
  
  // Get vulnerabilities for the select dropdown
  const { data: vulnerabilities } = useQuery({
    queryKey: ["/api/vulnerabilities"],
    enabled: open,
  });
  
  // If we have a vulnerabilityId prop, get that specific vulnerability
  const { data: specificVulnerability } = useQuery({
    queryKey: [`/api/vulnerabilities/${vulnerabilityId}`],
    enabled: open && !!vulnerabilityId,
  });
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      platform: "",
      vulnerabilityId: vulnerabilityId || 0,
      title: "",
      description: "",
      stepsToReproduce: "",
      impact: "",
      severity: "critical",
      suggestedFix: "",
      status: "submitted",
      submittedAt: new Date(),
    },
  });
  
  // When a specific vulnerability is selected, pre-fill the form with its data
  const onVulnerabilitySelect = (vulnerabilityId: string) => {
    const id = parseInt(vulnerabilityId);
    form.setValue("vulnerabilityId", id);
    
    const selectedVuln = vulnerabilities?.find((v: any) => v.id === id);
    if (selectedVuln) {
      form.setValue("title", selectedVuln.title);
      form.setValue("description", selectedVuln.description);
      form.setValue("stepsToReproduce", selectedVuln.stepsToReproduce);
      form.setValue("impact", selectedVuln.impact);
      form.setValue("severity", selectedVuln.severity);
      form.setValue("suggestedFix", selectedVuln.remediation || "");
    }
  };
  
  // Pre-fill the form when a specific vulnerability is loaded
  useState(() => {
    if (specificVulnerability) {
      form.setValue("title", specificVulnerability.title);
      form.setValue("description", specificVulnerability.description);
      form.setValue("stepsToReproduce", specificVulnerability.stepsToReproduce);
      form.setValue("impact", specificVulnerability.impact);
      form.setValue("severity", specificVulnerability.severity);
      form.setValue("suggestedFix", specificVulnerability.remediation || "");
    }
  });
  
  const mutation = useMutation({
    mutationFn: (data: z.infer<typeof formSchema>) => {
      return apiRequest("POST", "/api/bounty-submissions", data);
    },
    onSuccess: () => {
      toast({
        title: "Bounty submission created",
        description: "Your submission has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/bounty-submissions"] });
      onOpenChange(false);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error creating submission",
        description: (error as Error).message,
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (values: z.infer<typeof formSchema>) => {
    mutation.mutate(values);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl bg-neutral-900 text-white border-gray-700 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-lg">Create Bug Bounty Submission</DialogTitle>
          <DialogDescription className="text-gray-400">
            Prepare your vulnerability for submission to bug bounty platforms.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="platform"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Bounty Platform</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="bg-neutral-950 border-gray-700 text-white">
                        <SelectValue placeholder="Select a platform" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent className="bg-neutral-900 border-gray-700 text-white">
                      <SelectItem value="hackerone">HackerOne</SelectItem>
                      <SelectItem value="bugcrowd">Bugcrowd</SelectItem>
                      <SelectItem value="synack">Synack</SelectItem>
                      <SelectItem value="intigriti">Intigriti</SelectItem>
                      <SelectItem value="yeswehack">YesWeHack</SelectItem>
                      <SelectItem value="other">Other/Direct</SelectItem>
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />

            {!vulnerabilityId && (
              <FormField
                control={form.control}
                name="vulnerabilityId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Vulnerability</FormLabel>
                    <Select 
                      onValueChange={(value) => onVulnerabilitySelect(value)}
                      defaultValue={field.value ? field.value.toString() : undefined}
                    >
                      <FormControl>
                        <SelectTrigger className="bg-neutral-950 border-gray-700 text-white">
                          <SelectValue placeholder="Select a vulnerability" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="bg-neutral-900 border-gray-700 text-white">
                        {vulnerabilities?.map((vuln: any) => (
                          <SelectItem key={vuln.id} value={vuln.id.toString()}>
                            {vuln.title} ({vuln.severity})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
            )}

            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Submission Title</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="SQL Injection in Search Feature" 
                      {...field} 
                      className="bg-neutral-950 border-gray-700 text-white"
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Detailed description of the vulnerability..." 
                      {...field} 
                      rows={4}
                      className="bg-neutral-950 border-gray-700 text-white resize-none"
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="stepsToReproduce"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Steps to Reproduce</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="1. Navigate to example.com/search&#10;2. Enter payload: ' OR '1'='1&#10;3. Observe all records returned" 
                      {...field} 
                      rows={4}
                      className="bg-neutral-950 border-gray-700 text-white resize-none"
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="impact"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Impact</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Explain what an attacker could accomplish by exploiting this vulnerability..." 
                      {...field} 
                      rows={3}
                      className="bg-neutral-950 border-gray-700 text-white resize-none"
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="severity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Severity</FormLabel>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                    <RadioGroup 
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="flex flex-col space-y-1 md:flex-row md:space-y-0 md:space-x-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="critical" id="severityCritical" />
                        <label htmlFor="severityCritical" className="text-sm text-red-500 cursor-pointer">Critical</label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="high" id="severityHigh" />
                        <label htmlFor="severityHigh" className="text-sm text-amber-500 cursor-pointer">High</label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="medium" id="severityMedium" />
                        <label htmlFor="severityMedium" className="text-sm text-blue-500 cursor-pointer">Medium</label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="low" id="severityLow" />
                        <label htmlFor="severityLow" className="text-sm text-emerald-500 cursor-pointer">Low</label>
                      </div>
                    </RadioGroup>
                  </div>
                </FormItem>
              )}
            />

            <FormItem>
              <FormLabel>Proof of Concept</FormLabel>
              <div className="border border-dashed border-gray-700 rounded-lg p-4 text-center">
                <div className="cursor-pointer flex flex-col items-center">
                  <Upload className="h-6 w-6 text-gray-400 mb-2" />
                  <span className="text-sm text-gray-300">Upload screenshots, videos, or code files</span>
                  <span className="text-xs text-gray-400 mt-1">Drag and drop or click to select files</span>
                </div>
              </div>
              <FormDescription className="text-gray-500 text-xs mt-1">
                Note: Proof of concept uploads are not functional in this demo.
              </FormDescription>
            </FormItem>

            <FormField
              control={form.control}
              name="suggestedFix"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Suggested Fix</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Suggestions for how to fix this vulnerability..." 
                      {...field} 
                      rows={3}
                      className="bg-neutral-950 border-gray-700 text-white resize-none"
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            <DialogFooter className="gap-2 sm:gap-0">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                className="border-gray-700 text-white hover:bg-neutral-800"
              >
                Cancel
              </Button>
              <Button 
                type="button" 
                variant="outline"
                className="border-gray-700 text-white hover:bg-neutral-800"
              >
                Save Draft
              </Button>
              <Button 
                type="submit" 
                disabled={mutation.isPending}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                {mutation.isPending ? "Submitting..." : "Submit Bounty"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
