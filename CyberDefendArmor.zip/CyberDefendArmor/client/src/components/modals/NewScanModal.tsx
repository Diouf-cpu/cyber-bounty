import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertScanSchema } from "@shared/schema";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { AlertTriangle } from "lucide-react";
import { Slider } from "@/components/ui/slider";

type NewScanModalProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

// Extend the schema with validation rules
const formSchema = insertScanSchema.extend({
  targetUrl: z.string().url("Please enter a valid URL").min(1, "Target URL is required"),
  hasPermission: z.boolean().refine(val => val === true, {
    message: "You must confirm you have permission to scan this target",
  }),
});

// Interface for the scan request including the real scanner flag
interface ScanRequest extends z.infer<typeof formSchema> {
  useRealScanner?: boolean;
}

export default function NewScanModal({ open, onOpenChange }: NewScanModalProps) {
  const { toast } = useToast();
  const [intensity, setIntensity] = useState(3);
  const [useRealScan, setUseRealScan] = useState(false);
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      targetUrl: "",
      scanType: "quick",
      vulnerabilityTypes: ["sql_injection", "xss", "csrf", "directory_traversal", "auth_bypass", "misconfiguration"],
      scanIntensity: 3,
      hasPermission: false,
      status: "pending"
    },
  });

  const mutation = useMutation({
    mutationFn: (data: ScanRequest) => {
      return apiRequest("POST", "/api/scans", data);
    },
    onSuccess: async () => {
      toast({
        title: "Scan started successfully",
        description: "Your security scan is now in progress.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/scans"] });
      onOpenChange(false);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error starting scan",
        description: (error as Error).message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    // Apply the current intensity value and real scan flag
    values.scanIntensity = intensity;
    
    // Create a ScanRequest object with our additional property
    const scanRequest: ScanRequest = {
      ...values,
      useRealScanner: useRealScan
    };
    
    // Send the request
    mutation.mutate(scanRequest);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl bg-neutral-900 text-white border-gray-700">
        <DialogHeader>
          <DialogTitle className="text-lg">Start New Scan</DialogTitle>
          <DialogDescription className="text-gray-400">
            Begin a vulnerability scan on your target. Only scan targets you have explicit permission to test.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="targetUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Target URL</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="https://example.com" 
                      {...field} 
                      className="bg-neutral-950 border-gray-700 text-white"
                    />
                  </FormControl>
                  <FormDescription className="text-gray-400">
                    Only scan targets you have explicit permission to test
                  </FormDescription>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="scanType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Scan Type</FormLabel>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <RadioGroup 
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="flex flex-col space-y-3"
                    >
                      <div className="flex items-center rounded-lg border border-gray-700 p-3">
                        <RadioGroupItem value="quick" id="scanTypeQuick" className="mr-2"/>
                        <Label htmlFor="scanTypeQuick" className="flex flex-col cursor-pointer">
                          <span className="font-medium">Quick Scan</span>
                          <span className="text-xs text-gray-400">Basic check for common vulnerabilities (~15 min)</span>
                        </Label>
                      </div>
                      
                      <div className="flex items-center rounded-lg border border-gray-700 p-3">
                        <RadioGroupItem value="comprehensive" id="scanTypeComprehensive" className="mr-2"/>
                        <Label htmlFor="scanTypeComprehensive" className="flex flex-col cursor-pointer">
                          <span className="font-medium">Comprehensive</span>
                          <span className="text-xs text-gray-400">In-depth analysis of all vulnerability types (1-3 hrs)</span>
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="vulnerabilityTypes"
              render={() => (
                <FormItem>
                  <FormLabel>Vulnerability Types</FormLabel>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    <FormField
                      control={form.control}
                      name="vulnerabilityTypes"
                      render={({ field }) => (
                        <FormItem className="flex items-center space-x-2">
                          <FormControl>
                            <Checkbox
                              checked={field.value?.includes("sql_injection")}
                              onCheckedChange={(checked) => {
                                const current = field.value || [];
                                if (checked) {
                                  field.onChange([...current, "sql_injection"]);
                                } else {
                                  field.onChange(current.filter(value => value !== "sql_injection"));
                                }
                              }}
                            />
                          </FormControl>
                          <FormLabel className="text-sm">SQL Injection</FormLabel>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="vulnerabilityTypes"
                      render={({ field }) => (
                        <FormItem className="flex items-center space-x-2">
                          <FormControl>
                            <Checkbox
                              checked={field.value?.includes("xss")}
                              onCheckedChange={(checked) => {
                                const current = field.value || [];
                                if (checked) {
                                  field.onChange([...current, "xss"]);
                                } else {
                                  field.onChange(current.filter(value => value !== "xss"));
                                }
                              }}
                            />
                          </FormControl>
                          <FormLabel className="text-sm">Cross-Site Scripting (XSS)</FormLabel>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="vulnerabilityTypes"
                      render={({ field }) => (
                        <FormItem className="flex items-center space-x-2">
                          <FormControl>
                            <Checkbox
                              checked={field.value?.includes("csrf")}
                              onCheckedChange={(checked) => {
                                const current = field.value || [];
                                if (checked) {
                                  field.onChange([...current, "csrf"]);
                                } else {
                                  field.onChange(current.filter(value => value !== "csrf"));
                                }
                              }}
                            />
                          </FormControl>
                          <FormLabel className="text-sm">Cross-Site Request Forgery</FormLabel>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="vulnerabilityTypes"
                      render={({ field }) => (
                        <FormItem className="flex items-center space-x-2">
                          <FormControl>
                            <Checkbox
                              checked={field.value?.includes("directory_traversal")}
                              onCheckedChange={(checked) => {
                                const current = field.value || [];
                                if (checked) {
                                  field.onChange([...current, "directory_traversal"]);
                                } else {
                                  field.onChange(current.filter(value => value !== "directory_traversal"));
                                }
                              }}
                            />
                          </FormControl>
                          <FormLabel className="text-sm">Directory Traversal</FormLabel>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="vulnerabilityTypes"
                      render={({ field }) => (
                        <FormItem className="flex items-center space-x-2">
                          <FormControl>
                            <Checkbox
                              checked={field.value?.includes("auth_bypass")}
                              onCheckedChange={(checked) => {
                                const current = field.value || [];
                                if (checked) {
                                  field.onChange([...current, "auth_bypass"]);
                                } else {
                                  field.onChange(current.filter(value => value !== "auth_bypass"));
                                }
                              }}
                            />
                          </FormControl>
                          <FormLabel className="text-sm">Authentication Issues</FormLabel>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="vulnerabilityTypes"
                      render={({ field }) => (
                        <FormItem className="flex items-center space-x-2">
                          <FormControl>
                            <Checkbox
                              checked={field.value?.includes("misconfiguration")}
                              onCheckedChange={(checked) => {
                                const current = field.value || [];
                                if (checked) {
                                  field.onChange([...current, "misconfiguration"]);
                                } else {
                                  field.onChange(current.filter(value => value !== "misconfiguration"));
                                }
                              }}
                            />
                          </FormControl>
                          <FormLabel className="text-sm">Misconfigured Services</FormLabel>
                        </FormItem>
                      )}
                    />
                  </div>
                </FormItem>
              )}
            />

            <FormItem>
              <FormLabel>Scan Intensity</FormLabel>
              <div className="pt-2">
                <Slider
                  defaultValue={[3]}
                  max={5}
                  min={1}
                  step={1}
                  value={[intensity]}
                  onValueChange={(vals) => setIntensity(vals[0])}
                />
              </div>
              <div className="flex justify-between text-xs text-gray-400 mt-1">
                <span>Gentle</span>
                <span>Moderate</span>
                <span>Aggressive</span>
              </div>
            </FormItem>

            <div className="bg-amber-950 bg-opacity-20 border border-amber-800 text-amber-500 rounded-lg p-3">
              <div className="flex">
                <AlertTriangle className="h-5 w-5 mr-2 flex-shrink-0 mt-0.5" />
                <div>
                  <div className="font-medium mb-1">Ethical Warning</div>
                  <p className="text-sm">
                    I confirm that I have explicit permission to perform security testing on this target.
                    I understand that unauthorized scanning may be illegal and against terms of service.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-3">
              <FormField
                control={form.control}
                name="hasPermission"
                render={({ field }) => (
                  <FormItem className="flex items-center space-x-2">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        className="border-green-500 data-[state=checked]:bg-green-500 data-[state=checked]:text-green-50"
                      />
                    </FormControl>
                    <FormLabel className="text-sm font-medium">
                      I confirm I have explicit permission to test this target
                    </FormLabel>
                  </FormItem>
                )}
              />
              
              <div className="flex items-center space-x-2 mt-2">
                <Checkbox
                  id="useRealScanner"
                  checked={useRealScan}
                  onCheckedChange={() => setUseRealScan(!useRealScan)}
                  className="border-green-500 data-[state=checked]:bg-green-500 data-[state=checked]:text-green-50"
                />
                <Label htmlFor="useRealScanner" className="text-sm font-medium cursor-pointer">
                  Use real scanner (actually tests for vulnerabilities)
                </Label>
              </div>
              {useRealScan && (
                <p className="text-amber-500 text-xs ml-6">
                  Warning: Real scanning will make actual requests to the target and may trigger security alerts.
                </p>
              )}
            </div>

            <DialogFooter className="gap-2 sm:gap-0">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                className="border-gray-700 text-white hover:bg-neutral-800"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={mutation.isPending}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                {mutation.isPending ? "Starting..." : "Start Scan"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
