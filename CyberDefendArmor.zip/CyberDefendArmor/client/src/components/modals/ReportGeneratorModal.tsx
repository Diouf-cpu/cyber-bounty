import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
} from '@/components/ui/form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Scan, Vulnerability } from '@shared/types';

const formSchema = z.object({
  title: z.string().min(1, 'Title is required'),
  scanId: z.coerce.number().min(1, 'Target is required'),
  vulnerabilityIds: z.array(z.number()).min(1, 'Select at least one vulnerability'),
  format: z.enum(['pdf', 'docx', 'html']),
  sections: z.array(z.string()).min(1, 'Select at least one section'),
});

type ReportGeneratorModalProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  includeVulnerabilityIds?: number[];
};

export default function ReportGeneratorModal({ 
  open, 
  onOpenChange,
  includeVulnerabilityIds = []
}: ReportGeneratorModalProps) {
  const [selectedScanId, setSelectedScanId] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch scans and vulnerabilities
  const { data: scans = [] } = useQuery<Scan[]>({
    queryKey: ['/api/scans'],
    enabled: open,
  });
  
  const { data: allVulnerabilities = [] } = useQuery<Vulnerability[]>({
    queryKey: ['/api/vulnerabilities'],
    enabled: open,
  });
  
  // Filter vulnerabilities based on selected scan ID
  const filteredVulnerabilities = selectedScanId
    ? allVulnerabilities.filter((vuln) => vuln.scanId === selectedScanId)
    : [];
  
  // Form setup with default values
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: 'Security Assessment Report',
      scanId: 0,
      vulnerabilityIds: includeVulnerabilityIds,
      format: 'pdf',
      sections: ['executive_summary', 'technical_details', 'remediation'],
    },
  });
  
  // Generate report mutation
  const mutation = useMutation({
    mutationFn: async (data: z.infer<typeof formSchema>) => {
      return apiRequest('/api/reports', {
        method: 'POST',
        data,
      });
    },
    onSuccess: () => {
      toast({
        title: 'Report Generated',
        description: 'Your vulnerability report has been generated and sent to the designated email address.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/reports'] });
      onOpenChange(false);
    },
    onError: (error: any) => {
      toast({
        title: 'Error Generating Report',
        description: error.message || 'Failed to generate the report. Please try again.',
        variant: 'destructive',
      });
    },
  });
  
  // Handle scan selection change
  const onScanChange = (scanId: string) => {
    const id = parseInt(scanId, 10);
    setSelectedScanId(id);
    form.setValue('scanId', id);
    
    // Reset vulnerability selection when scan changes
    if (!includeVulnerabilityIds.length) {
      form.setValue('vulnerabilityIds', []);
    }
  };
  
  // Form submission handler
  const onSubmit = (data: z.infer<typeof formSchema>) => {
    mutation.mutate(data);
  };
  
  // Select all vulnerabilities
  const selectAllVulnerabilities = () => {
    const ids = filteredVulnerabilities.map(v => v.id);
    form.setValue('vulnerabilityIds', ids);
  };
  
  // Deselect all vulnerabilities
  const deselectAllVulnerabilities = () => {
    form.setValue('vulnerabilityIds', []);
  };
  
  // Set up initial scan ID if we have pre-selected vulnerabilities
  useEffect(() => {
    if (includeVulnerabilityIds.length > 0 && allVulnerabilities.length > 0) {
      const firstVuln = allVulnerabilities.find(v => includeVulnerabilityIds.includes(v.id));
      if (firstVuln) {
        const scanId = firstVuln.scanId;
        setSelectedScanId(scanId);
        form.setValue('scanId', scanId);
        form.setValue('vulnerabilityIds', includeVulnerabilityIds);
      }
    }
  }, [includeVulnerabilityIds, allVulnerabilities, form]);
  
  // Severity class mapping for visual indication
  const getSeverityClass = (severity: string) => {
    switch (severity.toLowerCase()) {
      case 'critical': return "bg-red-900 bg-opacity-50 text-red-300";
      case 'high': return "bg-orange-900 bg-opacity-50 text-orange-300";
      case 'medium': return "bg-yellow-900 bg-opacity-50 text-yellow-300";
      case 'low': return "bg-blue-900 bg-opacity-50 text-blue-300";
      case 'info': return "bg-gray-900 bg-opacity-50 text-gray-300";
      default: return "bg-gray-600 bg-opacity-20 text-gray-400";
    }
  };

  // Get styles for selected items (green highlight)
  const getSelectedItemClass = (isSelected: boolean) => {
    return isSelected ? "border-green-500 bg-green-900 bg-opacity-20" : "";
  };

  // Get styles for selected radio items
  const getSelectedRadioClass = (value: string, currentValue: string) => {
    return value === currentValue ? "text-green-500 font-medium" : "";
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl h-[90vh] flex flex-col bg-neutral-900 text-white border-gray-700">
        <DialogHeader>
          <DialogTitle className="text-lg">Generate Vulnerability Report</DialogTitle>
          <DialogDescription className="text-gray-400">
            Create a detailed report of the vulnerabilities found in your scan.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="flex flex-col h-full">
            {/* Action Buttons at the top */}
            <div className="flex justify-end mb-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                className="mr-2 border-gray-700 text-white hover:bg-neutral-800"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={mutation.isPending}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                {mutation.isPending ? "Generating..." : "Generate Report"}
              </Button>
            </div>
            
            {/* Scrollable form content */}
            <ScrollArea className="flex-grow pr-4">
              <div className="space-y-6 pb-4">
                {/* Report Title */}
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Report Title</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Security Assessment - example.com" 
                          {...field} 
                          className="bg-neutral-950 border-gray-700 text-white"
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />

                {/* Target Scope */}
                <FormField
                  control={form.control}
                  name="scanId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Target Scope</FormLabel>
                      <Select 
                        onValueChange={(value) => onScanChange(value)}
                        defaultValue={field.value.toString()}
                      >
                        <FormControl>
                          <SelectTrigger className="bg-neutral-950 border-gray-700 text-white">
                            <SelectValue placeholder="Select a target" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-neutral-900 border-gray-700 text-white">
                          {scans.map((scan) => (
                            <SelectItem 
                              key={scan.id} 
                              value={scan.id.toString()}
                              className={scan.id === selectedScanId ? "text-green-500 font-medium" : ""}
                            >
                              {scan.targetUrl} ({filteredVulnerabilities.filter(v => v.scanId === scan.id).length || 0} vulnerabilities)
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormItem>
                  )}
                />

                {/* Vulnerabilities Selection */}
                <FormField
                  control={form.control}
                  name="vulnerabilityIds"
                  render={({ field }) => (
                    <FormItem>
                      <div className="flex items-center justify-between mb-1">
                        <FormLabel>Include Vulnerabilities</FormLabel>
                        <div className="flex items-center space-x-2 text-xs">
                          <Button 
                            type="button" 
                            variant="link" 
                            className="text-green-500 h-auto p-0"
                            onClick={selectAllVulnerabilities}
                          >
                            Select All
                          </Button>
                          <Button 
                            type="button" 
                            variant="link" 
                            className="text-blue-500 h-auto p-0"
                            onClick={deselectAllVulnerabilities}
                          >
                            Deselect All
                          </Button>
                        </div>
                      </div>
                      
                      <FormControl>
                        <div className="bg-neutral-950 border border-gray-700 rounded-lg">
                          <ScrollArea className="h-48">
                            {filteredVulnerabilities.length > 0 ? (
                              filteredVulnerabilities.map((vuln) => {
                                const isSelected = field.value?.includes(vuln.id);
                                return (
                                  <div 
                                    key={vuln.id} 
                                    className={`p-2 border-b border-gray-700 flex items-center ${getSelectedItemClass(isSelected)}`}
                                  >
                                    <Checkbox
                                      id={`vuln-${vuln.id}`}
                                      checked={isSelected}
                                      onCheckedChange={(checked) => {
                                        const current = field.value || [];
                                        if (checked) {
                                          field.onChange([...current, vuln.id]);
                                        } else {
                                          field.onChange(current.filter(id => id !== vuln.id));
                                        }
                                      }}
                                      className={`mr-2 ${isSelected ? 'border-green-500 bg-green-500' : ''}`}
                                    />
                                    <label 
                                      htmlFor={`vuln-${vuln.id}`} 
                                      className={`text-sm flex items-center justify-between w-full cursor-pointer ${isSelected ? 'text-green-400' : ''}`}
                                    >
                                      <span>{vuln.title} - {vuln.location.split('/').pop()}</span>
                                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${getSeverityClass(vuln.severity)}`}>
                                        {vuln.severity.charAt(0).toUpperCase() + vuln.severity.slice(1)}
                                      </span>
                                    </label>
                                  </div>
                                );
                              })
                            ) : (
                              <div className="p-4 text-center text-gray-500">
                                {selectedScanId ? "No vulnerabilities found for this scan." : "Please select a target first."}
                              </div>
                            )}
                          </ScrollArea>
                        </div>
                      </FormControl>
                    </FormItem>
                  )}
                />

                {/* Report Format */}
                <FormField
                  control={form.control}
                  name="format"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Report Format</FormLabel>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <RadioGroup 
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex flex-col space-y-2"
                        >
                          <div className={`flex items-center space-x-2 p-2 rounded ${field.value === 'pdf' ? 'bg-green-900 bg-opacity-20' : ''}`}>
                            <RadioGroupItem value="pdf" id="formatPdf" className={field.value === 'pdf' ? 'border-green-500 text-green-500' : ''} />
                            <label htmlFor="formatPdf" className={`text-sm cursor-pointer ${getSelectedRadioClass('pdf', field.value)}`}>PDF</label>
                          </div>
                          <div className={`flex items-center space-x-2 p-2 rounded ${field.value === 'docx' ? 'bg-green-900 bg-opacity-20' : ''}`}>
                            <RadioGroupItem value="docx" id="formatWord" className={field.value === 'docx' ? 'border-green-500 text-green-500' : ''} />
                            <label htmlFor="formatWord" className={`text-sm cursor-pointer ${getSelectedRadioClass('docx', field.value)}`}>Word Document</label>
                          </div>
                          <div className={`flex items-center space-x-2 p-2 rounded ${field.value === 'html' ? 'bg-green-900 bg-opacity-20' : ''}`}>
                            <RadioGroupItem value="html" id="formatHtml" className={field.value === 'html' ? 'border-green-500 text-green-500' : ''} />
                            <label htmlFor="formatHtml" className={`text-sm cursor-pointer ${getSelectedRadioClass('html', field.value)}`}>HTML</label>
                          </div>
                        </RadioGroup>
                      </div>
                    </FormItem>
                  )}
                />

                {/* Report Sections */}
                <FormField
                  control={form.control}
                  name="sections"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Report Sections</FormLabel>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {[
                          { id: "executive_summary", label: "Executive Summary" },
                          { id: "technical_details", label: "Technical Details" },
                          { id: "remediation", label: "Remediation Steps" },
                          { id: "screenshots", label: "Screenshots/Evidence" },
                          { id: "risk_analysis", label: "Risk Analysis" },
                          { id: "appendix", label: "Appendix/References" }
                        ].map(section => {
                          const isSelected = field.value?.includes(section.id);
                          return (
                            <div 
                              key={section.id}
                              className={`flex items-center space-x-2 p-2 rounded ${isSelected ? 'bg-green-900 bg-opacity-20' : ''}`}
                            >
                              <Checkbox
                                id={`section-${section.id}`}
                                checked={isSelected}
                                onCheckedChange={(checked) => {
                                  const current = field.value || [];
                                  if (checked) {
                                    field.onChange([...current, section.id]);
                                  } else {
                                    field.onChange(current.filter(s => s !== section.id));
                                  }
                                }}
                                className={isSelected ? 'border-green-500 bg-green-500' : ''}
                              />
                              <label 
                                htmlFor={`section-${section.id}`} 
                                className={`text-sm cursor-pointer ${isSelected ? 'text-green-400 font-medium' : ''}`}
                              >
                                {section.label}
                              </label>
                            </div>
                          );
                        })}
                      </div>
                    </FormItem>
                  )}
                />
              </div>
            </ScrollArea>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}