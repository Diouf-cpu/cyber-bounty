import { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { ArrowUp, ArrowDown, ArrowRight } from "lucide-react";

type StatsCardProps = {
  title: string;
  value: number;
  icon: ReactNode;
  iconClassName?: string;
  change?: {
    value: number;
    isPositive?: boolean;
    isNeutral?: boolean;
    suffix?: string;
  };
};

export default function StatsCard({
  title,
  value,
  icon,
  iconClassName,
  change,
}: StatsCardProps) {
  return (
    <div className="bg-neutral-900 rounded-lg p-4 shadow-lg">
      <div className="flex items-center">
        <div className={cn("flex-shrink-0 mr-3 p-3 rounded-lg", iconClassName)}>
          {icon}
        </div>
        <div>
          <div className="text-xs text-gray-400 uppercase font-semibold">{title}</div>
          <div className="text-2xl font-bold">{value}</div>
        </div>
      </div>
      {change && (
        <div className="mt-4 text-xs text-gray-400">
          <span
            className={cn(
              "inline-flex items-center",
              change.isPositive ? "text-emerald-500" : change.isNeutral ? "text-amber-500" : "text-red-500"
            )}
          >
            {change.isPositive ? (
              <ArrowUp className="mr-1" size={14} />
            ) : change.isNeutral ? (
              <ArrowRight className="mr-1" size={14} />
            ) : (
              <ArrowDown className="mr-1" size={14} />
            )}
            {change.value}%
          </span>
          {change.suffix && ` ${change.suffix}`}
        </div>
      )}
    </div>
  );
}
