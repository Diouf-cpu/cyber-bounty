import { useQuery } from "@tanstack/react-query";
import { Scan } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { cn } from "@/lib/utils";
import { Bug, Clock } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useState } from "react";
import { Link } from "wouter";
import VulnerabilityDetailModal from "../modals/VulnerabilityDetailModal";

function ScanStatus({ status }: { status: string }) {
  let bgColor = "bg-blue-600 bg-opacity-20 text-blue-500";
  
  if (status === "completed") {
    bgColor = "bg-emerald-600 bg-opacity-20 text-emerald-500";
  } else if (status === "failed") {
    bgColor = "bg-red-600 bg-opacity-20 text-red-500";
  } else if (status === "pending") {
    bgColor = "bg-amber-600 bg-opacity-20 text-amber-500";
  }
  
  return (
    <span className={cn("text-xs px-2 py-1 rounded-full", bgColor)}>
      {status.charAt(0).toUpperCase() + status.slice(1).replace(/_/g, ' ')}
    </span>
  );
}

export default function RecentScans() {
  const [selectedVulnId, setSelectedVulnId] = useState<number | null>(null);
  
  const { data: scans, isLoading } = useQuery<Scan[]>({
    queryKey: ["/api/scans"],
  });
  
  // To get vulnerability count for each scan
  const { data: vulnerabilities = [] } = useQuery<any[]>({
    queryKey: ["/api/vulnerabilities"],
  });
  
  const openVulnerabilityModal = (scanId: number) => {
    // In a real app, we'd fetch the first vulnerability for this scan
    // For now, just simulating with a hardcoded value
    setSelectedVulnId(1);
  };
  
  return (
    <>
      <div className="bg-neutral-900 rounded-lg shadow-lg overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-700">
          <h2 className="text-lg font-semibold">Recent Scans</h2>
          <Link to="/scans" className="text-blue-500 text-sm hover:underline">
            View All
          </Link>
        </div>
        
        <div className="divide-y divide-gray-700">
          {isLoading ? (
            // Loading skeleton
            Array(3).fill(null).map((_, i) => (
              <div key={i} className="px-4 py-3">
                <div className="flex items-center justify-between mb-1">
                  <Skeleton className="h-5 w-40" />
                  <Skeleton className="h-5 w-20" />
                </div>
                <Skeleton className="h-4 w-32 mb-2" />
                <div className="flex items-center text-xs text-gray-400">
                  <Skeleton className="h-4 w-24 mr-3" />
                  <Skeleton className="h-4 w-24" />
                </div>
              </div>
            ))
          ) : scans && scans.length > 0 ? (
            scans.slice(0, 3).map((scan) => {
              // Count vulnerabilities for this scan
              const vulnCount = vulnerabilities.filter((v: any) => v.scanId === scan.id).length;
              
              return (
                <div 
                  key={scan.id} 
                  className="px-4 py-3 hover:bg-neutral-800 cursor-pointer transition-colors"
                  onClick={() => openVulnerabilityModal(scan.id)}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="font-medium">{scan.targetUrl}</div>
                    <ScanStatus status={scan.status} />
                  </div>
                  <div className="text-sm text-gray-400 mb-2">
                    {scan.startedAt && formatDistanceToNow(new Date(scan.startedAt), { addSuffix: true })}
                  </div>
                  <div className="flex items-center text-xs text-gray-400">
                    <div className="flex items-center mr-3">
                      <Bug size={14} className="mr-1" />
                      <span>{vulnCount} vulnerabilities</span>
                    </div>
                    <div className="flex items-center">
                      <Clock size={14} className="mr-1" />
                      <span>
                        {scan.completedAt 
                          ? `${Math.round((new Date(scan.completedAt).getTime() - new Date(scan.startedAt).getTime()) / 60000)} minutes` 
                          : scan.status === "in_progress" 
                            ? "Running" 
                            : "Pending"}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="px-4 py-6 text-center text-gray-500">
              No scans found. Start your first scan!
            </div>
          )}
        </div>
      </div>
      
      {selectedVulnId && (
        <VulnerabilityDetailModal 
          vulnerabilityId={selectedVulnId} 
          open={!!selectedVulnId} 
          onOpenChange={() => setSelectedVulnId(null)}
        />
      )}
    </>
  );
}
