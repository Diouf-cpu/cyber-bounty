import { useState } from "react";
import { Link } from "wouter";
import { Search, FileText, Send } from "lucide-react";
import NewScanModal from "../modals/NewScanModal";
import ReportGeneratorModal from "../modals/ReportGeneratorModal";
import BountySubmissionModal from "../modals/BountySubmissionModal";

export default function QuickActions() {
  const [newScanModalOpen, setNewScanModalOpen] = useState(false);
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [bountyModalOpen, setBountyModalOpen] = useState(false);

  return (
    <>
      <div className="bg-neutral-900 rounded-lg shadow-lg p-4 mb-6">
        <h2 className="text-lg font-semibold mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <button
            onClick={() => setNewScanModalOpen(true)}
            className="flex items-center justify-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded-lg transition duration-150"
          >
            <Search size={18} />
            <span>New Scan</span>
          </button>
          
          <button
            onClick={() => setReportModalOpen(true)}
            className="flex items-center justify-center space-x-2 bg-neutral-800 hover:bg-neutral-700 text-white py-3 px-4 rounded-lg transition duration-150"
          >
            <FileText size={18} />
            <span>Generate Report</span>
          </button>
          
          <button
            onClick={() => setBountyModalOpen(true)}
            className="flex items-center justify-center space-x-2 bg-neutral-800 hover:bg-neutral-700 text-white py-3 px-4 rounded-lg transition duration-150"
          >
            <Send size={18} />
            <span>Submit Bounty</span>
          </button>
        </div>
      </div>
      
      <NewScanModal open={newScanModalOpen} onOpenChange={setNewScanModalOpen} />
      <ReportGeneratorModal open={reportModalOpen} onOpenChange={setReportModalOpen} />
      <BountySubmissionModal open={bountyModalOpen} onOpenChange={setBountyModalOpen} />
    </>
  );
}
