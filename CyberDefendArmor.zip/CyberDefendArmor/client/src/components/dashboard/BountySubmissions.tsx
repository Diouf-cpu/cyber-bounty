import { useQuery } from "@tanstack/react-query";
import { BountySubmission } from "@shared/schema";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";

// Helper component for status badges
function SubmissionStatus({ status }: { status: string }) {
  let className = "";
  
  switch (status) {
    case "accepted":
      className = "bg-emerald-600 bg-opacity-20 text-emerald-500";
      break;
    case "rejected":
      className = "bg-gray-500 bg-opacity-20 text-gray-400";
      break;
    case "in_review":
    case "submitted":
      className = "bg-blue-600 bg-opacity-20 text-blue-500";
      break;
    case "needs_info":
      className = "bg-amber-600 bg-opacity-20 text-amber-500";
      break;
    case "paid":
      className = "bg-green-600 bg-opacity-20 text-green-500";
      break;
    default:
      className = "bg-gray-600 bg-opacity-20 text-gray-400";
  }
  
  return (
    <span className={cn("inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium", className)}>
      {status.charAt(0).toUpperCase() + status.slice(1).replace(/_/g, ' ')}
    </span>
  );
}

// Helper component for vulnerability type badges
function VulnerabilityType({ type }: { type: string }) {
  let className = "";
  
  switch (type) {
    case "sql_injection":
      className = "bg-red-600 bg-opacity-20 text-red-500";
      break;
    case "xss":
      className = "bg-amber-600 bg-opacity-20 text-amber-500";
      break;
    case "csrf":
      className = "bg-red-600 bg-opacity-20 text-red-500";
      break;
    case "directory_traversal":
      className = "bg-amber-600 bg-opacity-20 text-amber-500";
      break;
    case "auth_bypass":
      className = "bg-blue-600 bg-opacity-20 text-blue-500";
      break;
    default:
      className = "bg-gray-600 bg-opacity-20 text-gray-400";
  }
  
  return (
    <span className={cn("inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium", className)}>
      {type.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
    </span>
  );
}

export default function BountySubmissions() {
  const { data: submissions, isLoading } = useQuery<BountySubmission[]>({
    queryKey: ["/api/bounty-submissions"],
  });
  
  const { data: vulnerabilities } = useQuery({
    queryKey: ["/api/vulnerabilities"],
  });
  
  return (
    <div className="bg-neutral-900 rounded-lg shadow-lg overflow-hidden mb-6">
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-700">
        <h2 className="text-lg font-semibold">Recent Bounty Submissions</h2>
        <Link to="/bounty-submissions" className="text-blue-500 text-sm hover:underline">
          View All
        </Link>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-700">
          <thead>
            <tr className="bg-neutral-800 bg-opacity-40">
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Target</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Vulnerability</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Submitted</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Platform</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Status</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Reward</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-700 bg-neutral-800 bg-opacity-20">
            {isLoading ? (
              Array(4).fill(null).map((_, i) => (
                <tr key={i}>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <Skeleton className="h-4 w-20" />
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <Skeleton className="h-4 w-24" />
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <Skeleton className="h-4 w-24" />
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <Skeleton className="h-4 w-20" />
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <Skeleton className="h-4 w-16" />
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <Skeleton className="h-4 w-12" />
                  </td>
                </tr>
              ))
            ) : submissions && submissions.length > 0 ? (
              submissions.map((submission) => {
                // Find corresponding vulnerability to get target URL
                const vulnerability = vulnerabilities?.find((v: any) => v.id === submission.vulnerabilityId);
                const vulnType = vulnerability?.type || "unknown";
                const targetUrl = vulnerability?.location?.split('/')[2] || "unknown";
                
                return (
                  <tr key={submission.id} className="hover:bg-neutral-800 hover:bg-opacity-40">
                    <td className="px-4 py-3 whitespace-nowrap text-sm font-medium">{targetUrl}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm">
                      <VulnerabilityType type={vulnType} />
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-400">
                      {format(new Date(submission.submittedAt), "yyyy-MM-dd")}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm">
                      {submission.platform.charAt(0).toUpperCase() + submission.platform.slice(1)}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm">
                      <SubmissionStatus status={submission.status} />
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-emerald-500">
                      {submission.reward || "Pending"}
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={6} className="px-4 py-6 text-center text-gray-500">
                  No bounty submissions found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
