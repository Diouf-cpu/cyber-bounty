import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import PageLayout from "@/components/layout/PageLayout";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Bug, Search, Filter, Clock } from "lucide-react";
import { format } from "date-fns";
import VulnerabilityDetailModal from "@/components/modals/VulnerabilityDetailModal";
import { cn } from "@/lib/utils";

// Helper component for severity badges
function SeverityBadge({ severity }: { severity: string }) {
  const getSeverityClass = (severity: string) => {
    switch (severity) {
      case "critical": return "bg-red-600 text-red-200";
      case "high": return "bg-amber-600 text-amber-200";
      case "medium": return "bg-blue-600 text-blue-200";
      case "low": return "bg-emerald-600 text-emerald-200";
      default: return "bg-gray-600 text-gray-200";
    }
  };
  
  return (
    <Badge className={cn("capitalize", getSeverityClass(severity))}>
      {severity}
    </Badge>
  );
}

// Helper component for status badges
function StatusBadge({ status }: { status: string }) {
  const getStatusClass = (status: string) => {
    switch (status) {
      case "open": return "bg-blue-600 text-blue-200";
      case "fixed": return "bg-emerald-600 text-emerald-200";
      case "false_positive": return "bg-amber-600 text-amber-200";
      case "wont_fix": return "bg-gray-600 text-gray-200";
      default: return "bg-gray-600 text-gray-200";
    }
  };
  
  return (
    <Badge className={cn("capitalize", getStatusClass(status))}>
      {status.replace('_', ' ')}
    </Badge>
  );
}

export default function Vulnerabilities() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedStatus, setSelectedStatus] = useState<string>("all");
  const [selectedSeverity, setSelectedSeverity] = useState<string>("all");
  const [selectedVulnId, setSelectedVulnId] = useState<number | null>(null);
  
  const { data: vulnerabilities, isLoading } = useQuery({
    queryKey: ["/api/vulnerabilities"],
  });
  
  // Filter vulnerabilities based on search and filters
  const filteredVulnerabilities = vulnerabilities
    ? vulnerabilities.filter((vuln: any) => {
        const matchesSearch = searchTerm === "" || 
          vuln.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
          vuln.location.toLowerCase().includes(searchTerm.toLowerCase());
        
        const matchesStatus = selectedStatus === "all" || vuln.status === selectedStatus;
        const matchesSeverity = selectedSeverity === "all" || vuln.severity === selectedSeverity;
        
        return matchesSearch && matchesStatus && matchesSeverity;
      })
    : [];
  
  // Tabs based filtering
  const openVulnerabilities = filteredVulnerabilities.filter((vuln: any) => vuln.status === "open");
  const fixedVulnerabilities = filteredVulnerabilities.filter((vuln: any) => vuln.status === "fixed");
  const falsePositives = filteredVulnerabilities.filter((vuln: any) => vuln.status === "false_positive");
  
  return (
    <PageLayout>
      <div className="p-6 pb-24 overflow-y-auto max-h-screen">
        <header className="mb-6">
          <h1 className="text-2xl font-bold flex items-center">
            <Bug className="mr-2 text-red-500" size={28} />
            Vulnerabilities
          </h1>
          <p className="text-gray-400 mt-1">Manage and analyze detected security vulnerabilities</p>
        </header>
        
        <Card className="bg-neutral-900 border-gray-700 mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-3">
              <div className="flex-1 relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  placeholder="Search vulnerabilities..."
                  className="pl-8 bg-neutral-950 border-gray-700 text-white"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <div className="flex gap-3">
                <Select
                  value={selectedStatus}
                  onValueChange={setSelectedStatus}
                >
                  <SelectTrigger className="w-[150px] bg-neutral-950 border-gray-700 text-white">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent className="bg-neutral-900 border-gray-700 text-white">
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="open">Open</SelectItem>
                    <SelectItem value="fixed">Fixed</SelectItem>
                    <SelectItem value="false_positive">False Positive</SelectItem>
                    <SelectItem value="wont_fix">Won't Fix</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select
                  value={selectedSeverity}
                  onValueChange={setSelectedSeverity}
                >
                  <SelectTrigger className="w-[150px] bg-neutral-950 border-gray-700 text-white">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Severity" />
                  </SelectTrigger>
                  <SelectContent className="bg-neutral-900 border-gray-700 text-white">
                    <SelectItem value="all">All Severity</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="bg-neutral-900 border-gray-700 mb-4">
            <TabsTrigger value="all">
              All ({filteredVulnerabilities.length})
            </TabsTrigger>
            <TabsTrigger value="open">
              Open ({openVulnerabilities.length})
            </TabsTrigger>
            <TabsTrigger value="fixed">
              Fixed ({fixedVulnerabilities.length})
            </TabsTrigger>
            <TabsTrigger value="false_positive">
              False Positive ({falsePositives.length})
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="all">
            <VulnerabilitiesTable 
              vulnerabilities={filteredVulnerabilities} 
              isLoading={isLoading} 
              onSelect={setSelectedVulnId}
            />
          </TabsContent>
          
          <TabsContent value="open">
            <VulnerabilitiesTable 
              vulnerabilities={openVulnerabilities} 
              isLoading={isLoading}
              onSelect={setSelectedVulnId} 
            />
          </TabsContent>
          
          <TabsContent value="fixed">
            <VulnerabilitiesTable 
              vulnerabilities={fixedVulnerabilities} 
              isLoading={isLoading}
              onSelect={setSelectedVulnId} 
            />
          </TabsContent>
          
          <TabsContent value="false_positive">
            <VulnerabilitiesTable 
              vulnerabilities={falsePositives} 
              isLoading={isLoading}
              onSelect={setSelectedVulnId} 
            />
          </TabsContent>
        </Tabs>
        
        {selectedVulnId && (
          <VulnerabilityDetailModal 
            vulnerabilityId={selectedVulnId}
            open={!!selectedVulnId}
            onOpenChange={(open) => !open && setSelectedVulnId(null)}
          />
        )}
      </div>
    </PageLayout>
  );
}

type VulnerabilitiesTableProps = {
  vulnerabilities: any[];
  isLoading: boolean;
  onSelect: (id: number) => void;
};

function VulnerabilitiesTable({ vulnerabilities, isLoading, onSelect }: VulnerabilitiesTableProps) {
  if (isLoading) {
    return (
      <Card className="bg-neutral-900 border-gray-700">
        <CardContent className="p-4">
          {Array(5).fill(null).map((_, i) => (
            <div key={i} className="py-4 border-b border-gray-700 last:border-0">
              <div className="flex items-center justify-between mb-2">
                <Skeleton className="h-5 w-64" />
                <div className="flex space-x-2">
                  <Skeleton className="h-5 w-16" />
                  <Skeleton className="h-5 w-16" />
                </div>
              </div>
              <Skeleton className="h-4 w-full mb-2" />
              <div className="flex items-center text-xs text-gray-400 mt-2">
                <Skeleton className="h-4 w-32 mr-3" />
                <Skeleton className="h-4 w-32" />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }
  
  if (vulnerabilities.length === 0) {
    return (
      <Card className="bg-neutral-900 border-gray-700">
        <CardContent className="py-12 flex flex-col items-center justify-center text-center">
          <Bug className="h-12 w-12 text-gray-600 mb-4" />
          <h3 className="text-xl font-medium text-gray-400 mb-1">No vulnerabilities found</h3>
          <p className="text-gray-500 max-w-md">
            Try adjusting your filters or run a new scan to find security vulnerabilities.
          </p>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="bg-neutral-900 border-gray-700">
      <CardContent className="p-0 divide-y divide-gray-700">
        {vulnerabilities.map((vuln) => (
          <div 
            key={vuln.id} 
            className="p-4 hover:bg-neutral-800 cursor-pointer transition-colors"
            onClick={() => onSelect(vuln.id)}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-2 gap-2">
              <h3 className="font-medium text-lg">{vuln.title}</h3>
              <div className="flex items-center space-x-2 shrink-0">
                <SeverityBadge severity={vuln.severity} />
                <StatusBadge status={vuln.status} />
              </div>
            </div>
            <p className="text-sm text-gray-400 mb-2 line-clamp-2">
              {vuln.description}
            </p>
            <div className="flex flex-wrap gap-4 items-center text-xs text-gray-500 mt-2">
              <div className="flex items-center">
                <Clock className="h-3.5 w-3.5 mr-1" />
                <span>
                  {format(new Date(vuln.detectedAt), "MMM dd, yyyy 'at' h:mm a")}
                </span>
              </div>
              <div>
                <span className="text-gray-400 mr-1">Location:</span>
                <span className="text-blue-500">{vuln.location}</span>
              </div>
              <div>
                <span className="text-gray-400 mr-1">Type:</span>
                <span>{vuln.type.replace(/_/g, ' ')}</span>
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
