import PageLayout from "@/components/layout/PageLayout";
import StatsCard from "@/components/dashboard/StatsCard";
import QuickActions from "@/components/dashboard/QuickActions";
import RecentScans from "@/components/dashboard/RecentScans";
import VulnerabilitySummary from "@/components/dashboard/VulnerabilitySummary";
import BountySubmissions from "@/components/dashboard/BountySubmissions";
import { VulnerabilityNotifications } from "@/components/notifications/VulnerabilityNotifications";
import { useQuery } from "@tanstack/react-query";
import { Search, Bug, FileText, Trophy } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

// Define interface for stats data
interface ScanStats {
  activeScans: number;
  totalVulnerabilities: number;
  reportsGenerated: number;
  bountySubmissions: number;
}

export default function Dashboard() {
  // Fetch statistics for dashboard
  const { data: statsData, isLoading } = useQuery<unknown, Error, ScanStats>({
    queryKey: ["/api/stats"],
    select: (data: any) => data?.scanStats,
  });

  return (
    <PageLayout>
      <div className="p-6 pb-24 overflow-y-auto max-h-screen">
        <header className="mb-6">
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-gray-400">Overview of your security testing and bug bounty activities</p>
        </header>
        
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {isLoading ? (
            // Loading skeletons for stats cards
            Array(4).fill(null).map((_, i) => (
              <div key={i} className="bg-neutral-900 rounded-lg p-4 shadow-lg">
                <div className="flex items-center">
                  <Skeleton className="h-12 w-12 rounded-lg mr-3" />
                  <div>
                    <Skeleton className="h-4 w-24 mb-1" />
                    <Skeleton className="h-6 w-12" />
                  </div>
                </div>
                <Skeleton className="h-4 w-32 mt-4" />
              </div>
            ))
          ) : (
            <>
              <StatsCard
                title="Active Scans"
                value={statsData?.activeScans || 0}
                icon={<Search className="text-blue-500" size={18} />}
                iconClassName="bg-blue-600 bg-opacity-20"
                change={{
                  value: 25,
                  isPositive: true,
                  suffix: "from last week"
                }}
              />
              
              <StatsCard
                title="Vulnerabilities"
                value={statsData?.totalVulnerabilities || 0}
                icon={<Bug className="text-red-500" size={18} />}
                iconClassName="bg-red-600 bg-opacity-20"
                change={{
                  value: 12,
                  isPositive: false,
                  suffix: "from last week"
                }}
              />
              
              <StatsCard
                title="Reports Generated"
                value={statsData?.reportsGenerated || 0}
                icon={<FileText className="text-emerald-500" size={18} />}
                iconClassName="bg-emerald-600 bg-opacity-20"
                change={{
                  value: 18,
                  isPositive: true,
                  suffix: "from last week"
                }}
              />
              
              <StatsCard
                title="Bounty Submissions"
                value={statsData?.bountySubmissions || 0}
                icon={<Trophy className="text-amber-500" size={18} />}
                iconClassName="bg-amber-600 bg-opacity-20"
                change={{
                  value: 0,
                  isNeutral: true,
                  suffix: "from last week"
                }}
              />
            </>
          )}
        </div>
        
        {/* Quick Actions */}
        <QuickActions />
        
        {/* Recent Scans and Vulnerability Summary */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <RecentScans />
          <VulnerabilitySummary />
        </div>
        
        {/* Real-time Notifications and Bounty Submissions */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <VulnerabilityNotifications />
          <BountySubmissions />
        </div>
      </div>
    </PageLayout>
  );
}
