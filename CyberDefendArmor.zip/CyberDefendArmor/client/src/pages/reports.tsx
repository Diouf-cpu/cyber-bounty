import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import PageLayout from "@/components/layout/PageLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { FileText, Download, Plus, ChevronRight } from "lucide-react";
import { format } from "date-fns";
import ReportGeneratorModal from "@/components/modals/ReportGeneratorModal";

export default function Reports() {
  const [reportModalOpen, setReportModalOpen] = useState(false);
  
  const { data: reports, isLoading } = useQuery({
    queryKey: ["/api/reports"],
  });

  // Format helper for report sections
  const formatSections = (sections: string[]) => {
    return sections.map(s => s.replace(/_/g, ' ')).join(', ');
  };
  
  // Format helper for report file types
  const getFormatIcon = (format: string) => {
    switch (format) {
      case "pdf": return "📄";
      case "docx": return "📝";
      case "html": return "🌐";
      default: return "📄";
    }
  };

  return (
    <PageLayout>
      <div className="p-6 pb-24 overflow-y-auto max-h-screen">
        <header className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold flex items-center">
              <FileText className="mr-2 text-blue-500" size={28} />
              Vulnerability Reports
            </h1>
            <p className="text-gray-400 mt-1">Generate and manage detailed security reports</p>
          </div>
          
          <Button 
            onClick={() => setReportModalOpen(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white md:self-start w-full md:w-auto sticky top-0"
          >
            <Plus className="mr-2 h-4 w-4" />
            Generate New Report
          </Button>
        </header>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {isLoading ? (
            // Loading skeletons
            Array(6).fill(null).map((_, i) => (
              <Card key={i} className="bg-neutral-900 border-gray-700">
                <CardHeader className="pb-2">
                  <CardTitle><Skeleton className="h-6 w-40" /></CardTitle>
                  <CardDescription><Skeleton className="h-4 w-32" /></CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-3/4" />
                  </div>
                </CardContent>
                <CardFooter className="border-t border-gray-700 pt-4 flex justify-between">
                  <Skeleton className="h-6 w-20" />
                  <Skeleton className="h-9 w-24" />
                </CardFooter>
              </Card>
            ))
          ) : (reports && Array.isArray(reports) && reports.length > 0) ? (
            reports.map((report: any) => (
              <Card key={report.id} className="bg-neutral-900 border-gray-700 flex flex-col">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <Badge variant="outline" className="px-2 py-0 h-6 bg-neutral-800">
                      {getFormatIcon(report.format)} {report.format.toUpperCase()}
                    </Badge>
                    <span className="text-sm text-gray-400">
                      {format(new Date(report.createdAt), "MMM dd, yyyy")}
                    </span>
                  </div>
                  <CardTitle className="mt-2 text-lg">{report.title}</CardTitle>
                  <CardDescription className="text-gray-400">
                    {report.vulnerabilityIds?.length} vulnerabilities included
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-grow">
                  <div className="text-sm text-gray-500">
                    <div className="mb-1">
                      <span className="text-gray-400 mr-1">Sections:</span>
                      <span>{formatSections(report.sections)}</span>
                    </div>
                    <div>
                      <span className="text-gray-400 mr-1">Scan ID:</span>
                      <span>{report.scanId}</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="border-t border-gray-700 pt-4 flex justify-between">
                  <div className="text-gray-400 text-sm">
                    ID: {report.id}
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="border-gray-700 text-white hover:bg-neutral-800"
                  >
                    <Download className="mr-1 h-4 w-4" />
                    Download
                  </Button>
                </CardFooter>
              </Card>
            ))
          ) : (
            <div className="col-span-full">
              <Card className="bg-neutral-900 border-gray-700">
                <CardContent className="flex flex-col items-center justify-center text-center p-8">
                  <FileText className="h-16 w-16 text-gray-600 mb-4" />
                  <h3 className="text-xl font-medium text-gray-400 mb-2">No reports generated yet</h3>
                  <p className="text-gray-500 mb-6 max-w-md">
                    Generate your first vulnerability report to document and share your findings.
                  </p>
                  <Button 
                    onClick={() => setReportModalOpen(true)}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Generate Report
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
        
        {reports && Array.isArray(reports) && reports.length > 0 && (
          <div className="mt-8">
            <Card className="bg-neutral-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-lg">Report Generation Tips</CardTitle>
                <CardDescription className="text-gray-400">
                  Guidelines for creating effective security reports
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="bg-blue-900 bg-opacity-20 p-2 rounded-lg mr-3">
                      <ChevronRight className="h-5 w-5 text-blue-500" />
                    </div>
                    <div>
                      <h3 className="font-medium mb-1">Be Clear and Concise</h3>
                      <p className="text-sm text-gray-400">
                        Ensure your reports are easy to understand, especially for non-technical stakeholders. Use clear language and avoid unnecessary jargon.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-blue-900 bg-opacity-20 p-2 rounded-lg mr-3">
                      <ChevronRight className="h-5 w-5 text-blue-500" />
                    </div>
                    <div>
                      <h3 className="font-medium mb-1">Prioritize by Severity</h3>
                      <p className="text-sm text-gray-400">
                        Organize vulnerabilities based on their severity to help clients focus on the most critical issues first.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-blue-900 bg-opacity-20 p-2 rounded-lg mr-3">
                      <ChevronRight className="h-5 w-5 text-blue-500" />
                    </div>
                    <div>
                      <h3 className="font-medium mb-1">Include Remediation Steps</h3>
                      <p className="text-sm text-gray-400">
                        Always provide actionable remediation guidance for each vulnerability to help clients fix the issues.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-blue-900 bg-opacity-20 p-2 rounded-lg mr-3">
                      <ChevronRight className="h-5 w-5 text-blue-500" />
                    </div>
                    <div>
                      <h3 className="font-medium mb-1">Include Visual Evidence</h3>
                      <p className="text-sm text-gray-400">
                        Screenshots, diagrams, and other visual elements make reports more compelling and help demonstrate impact.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
        
        <ReportGeneratorModal 
          open={reportModalOpen}
          onOpenChange={setReportModalOpen}
        />
      </div>
    </PageLayout>
  );
}
