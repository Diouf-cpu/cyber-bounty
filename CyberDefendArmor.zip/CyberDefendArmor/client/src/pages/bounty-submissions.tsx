import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import PageLayout from "@/components/layout/PageLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Trophy, CheckCircle, XCircle, Clock, DollarSign, AlertCircle, Plus } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import BountySubmissionModal from "@/components/modals/BountySubmissionModal";

export default function BountySubmissions() {
  const [bountyModalOpen, setBountyModalOpen] = useState(false);
  
  const { data: submissions, isLoading } = useQuery({
    queryKey: ["/api/bounty-submissions"],
  });
  
  // Categorize submissions by status for tabs
  const allSubmissions = submissions || [];
  const pendingSubmissions = allSubmissions.filter((s: any) => s.status === "submitted" || s.status === "in_review");
  const acceptedSubmissions = allSubmissions.filter((s: any) => s.status === "accepted" || s.status === "paid");
  const rejectedSubmissions = allSubmissions.filter((s: any) => s.status === "rejected");
  const needsInfoSubmissions = allSubmissions.filter((s: any) => s.status === "needs_info");
  
  // Helper for platform icons
  const getPlatformIcon = (platform: string) => {
    // Simple text icons for platforms
    switch (platform) {
      case "hackerone": return "🅷";
      case "bugcrowd": return "🅱";
      case "synack": return "🆂";
      case "intigriti": return "🅸";
      case "yeswehack": return "🆈";
      default: return "🔒";
    }
  };
  
  // Helper for status icons and colors
  const getStatusInfo = (status: string) => {
    switch (status) {
      case "submitted":
        return { icon: <Clock className="h-4 w-4" />, color: "bg-blue-600 text-blue-200" };
      case "in_review":
        return { icon: <Clock className="h-4 w-4" />, color: "bg-blue-600 text-blue-200" };
      case "accepted":
        return { icon: <CheckCircle className="h-4 w-4" />, color: "bg-emerald-600 text-emerald-200" };
      case "paid":
        return { icon: <DollarSign className="h-4 w-4" />, color: "bg-emerald-600 text-emerald-200" };
      case "rejected":
        return { icon: <XCircle className="h-4 w-4" />, color: "bg-red-600 text-red-200" };
      case "needs_info":
        return { icon: <AlertCircle className="h-4 w-4" />, color: "bg-amber-600 text-amber-200" };
      default:
        return { icon: <Clock className="h-4 w-4" />, color: "bg-gray-600 text-gray-200" };
    }
  };

  return (
    <PageLayout>
      <div className="p-6 pb-24 overflow-y-auto max-h-screen">
        <header className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold flex items-center">
              <Trophy className="mr-2 text-amber-500" size={28} />
              Bug Bounty Submissions
            </h1>
            <p className="text-gray-400 mt-1">Track and manage your vulnerability submissions to bounty programs</p>
          </div>
          
          <Button 
            onClick={() => setBountyModalOpen(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white md:self-start w-full md:w-auto"
          >
            <Plus className="mr-2 h-4 w-4" />
            New Submission
          </Button>
        </header>
        
        <Tabs defaultValue="all" className="w-full mb-6">
          <TabsList className="bg-neutral-900 border-gray-700 mb-4">
            <TabsTrigger value="all">
              All ({allSubmissions.length})
            </TabsTrigger>
            <TabsTrigger value="pending">
              Pending ({pendingSubmissions.length})
            </TabsTrigger>
            <TabsTrigger value="accepted">
              Accepted ({acceptedSubmissions.length})
            </TabsTrigger>
            <TabsTrigger value="rejected">
              Rejected ({rejectedSubmissions.length})
            </TabsTrigger>
            <TabsTrigger value="needs_info">
              Needs Info ({needsInfoSubmissions.length})
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="all">
            <SubmissionsList submissions={allSubmissions} isLoading={isLoading} />
          </TabsContent>
          
          <TabsContent value="pending">
            <SubmissionsList submissions={pendingSubmissions} isLoading={isLoading} />
          </TabsContent>
          
          <TabsContent value="accepted">
            <SubmissionsList submissions={acceptedSubmissions} isLoading={isLoading} />
          </TabsContent>
          
          <TabsContent value="rejected">
            <SubmissionsList submissions={rejectedSubmissions} isLoading={isLoading} />
          </TabsContent>
          
          <TabsContent value="needs_info">
            <SubmissionsList submissions={needsInfoSubmissions} isLoading={isLoading} />
          </TabsContent>
        </Tabs>
        
        <Card className="bg-neutral-900 border-gray-700">
          <CardHeader>
            <CardTitle className="text-lg">Bounty Program Tips</CardTitle>
            <CardDescription className="text-gray-400">
              Maximize your chances of acceptance and rewards
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="border border-gray-700 rounded-lg p-4">
                <h3 className="font-medium text-blue-500 mb-2">Quality over Quantity</h3>
                <p className="text-sm text-gray-400">
                  Focus on finding and thoroughly documenting high-impact vulnerabilities rather than submitting many low-value reports.
                </p>
              </div>
              
              <div className="border border-gray-700 rounded-lg p-4">
                <h3 className="font-medium text-blue-500 mb-2">Clear Documentation</h3>
                <p className="text-sm text-gray-400">
                  Provide detailed steps to reproduce, clear impact statements, and proof of concept examples to make it easy for teams to verify.
                </p>
              </div>
              
              <div className="border border-gray-700 rounded-lg p-4">
                <h3 className="font-medium text-blue-500 mb-2">Be Professional</h3>
                <p className="text-sm text-gray-400">
                  Maintain a professional tone in all communications. Be patient with triaging teams and respond promptly to questions.
                </p>
              </div>
              
              <div className="border border-gray-700 rounded-lg p-4">
                <h3 className="font-medium text-blue-500 mb-2">Stay Updated</h3>
                <p className="text-sm text-gray-400">
                  Keep track of your submissions and follow up appropriately if you haven't received a response within the program's specified timeframe.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <BountySubmissionModal 
          open={bountyModalOpen}
          onOpenChange={setBountyModalOpen}
        />
      </div>
    </PageLayout>
  );
}

type SubmissionsListProps = {
  submissions: any[];
  isLoading: boolean;
};

function SubmissionsList({ submissions, isLoading }: SubmissionsListProps) {
  // Helper for platform icons
  const getPlatformIcon = (platform: string) => {
    // Simple text icons for platforms
    switch (platform) {
      case "hackerone": return "🅷";
      case "bugcrowd": return "🅱";
      case "synack": return "🆂";
      case "intigriti": return "🅸";
      case "yeswehack": return "🆈";
      default: return "🔒";
    }
  };
  
  // Helper for status icons and colors
  const getStatusInfo = (status: string) => {
    switch (status) {
      case "submitted":
        return { icon: <Clock className="h-4 w-4" />, color: "bg-blue-600 text-blue-200" };
      case "in_review":
        return { icon: <Clock className="h-4 w-4" />, color: "bg-blue-600 text-blue-200" };
      case "accepted":
        return { icon: <CheckCircle className="h-4 w-4" />, color: "bg-emerald-600 text-emerald-200" };
      case "paid":
        return { icon: <DollarSign className="h-4 w-4" />, color: "bg-emerald-600 text-emerald-200" };
      case "rejected":
        return { icon: <XCircle className="h-4 w-4" />, color: "bg-red-600 text-red-200" };
      case "needs_info":
        return { icon: <AlertCircle className="h-4 w-4" />, color: "bg-amber-600 text-amber-200" };
      default:
        return { icon: <Clock className="h-4 w-4" />, color: "bg-gray-600 text-gray-200" };
    }
  };
  
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {Array(4).fill(null).map((_, i) => (
          <Card key={i} className="bg-neutral-900 border-gray-700">
            <CardHeader className="pb-2">
              <div className="flex justify-between">
                <Skeleton className="h-6 w-24" />
                <Skeleton className="h-6 w-24" />
              </div>
              <div className="mt-2">
                <Skeleton className="h-6 w-48" />
              </div>
            </CardHeader>
            <CardContent className="pb-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4 mt-2" />
            </CardContent>
            <CardFooter className="border-t border-gray-700 pt-4 flex justify-between">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-6 w-16" />
            </CardFooter>
          </Card>
        ))}
      </div>
    );
  }
  
  if (submissions.length === 0) {
    return (
      <Card className="bg-neutral-900 border-gray-700">
        <CardContent className="flex flex-col items-center justify-center text-center py-12">
          <Trophy className="h-16 w-16 text-gray-600 mb-4" />
          <h3 className="text-xl font-medium text-gray-400 mb-2">No submissions found</h3>
          <p className="text-gray-500 max-w-md mb-6">
            You haven't submitted any vulnerabilities to bug bounty programs yet.
          </p>
          <Button 
            onClick={() => setBountyModalOpen(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Plus className="mr-2 h-4 w-4" />
            Create Your First Submission
          </Button>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {submissions.map((submission: any) => {
        const statusInfo = getStatusInfo(submission.status);
        
        return (
          <Card key={submission.id} className="bg-neutral-900 border-gray-700">
            <CardHeader className="pb-2">
              <div className="flex justify-between">
                <Badge variant="outline" className="bg-neutral-800 text-white">
                  {getPlatformIcon(submission.platform)} {submission.platform.charAt(0).toUpperCase() + submission.platform.slice(1)}
                </Badge>
                <Badge className={cn("flex items-center gap-1", statusInfo.color)}>
                  {statusInfo.icon}
                  <span>{submission.status.replace('_', ' ')}</span>
                </Badge>
              </div>
              
              <CardTitle className="mt-2 text-lg">{submission.title}</CardTitle>
              <CardDescription className="flex items-center mt-1">
                <span className="capitalize mr-1">{submission.severity}</span> severity
              </CardDescription>
            </CardHeader>
            <CardContent className="pb-2">
              <p className="text-sm text-gray-400 line-clamp-2">
                {submission.description}
              </p>
            </CardContent>
            <CardFooter className="border-t border-gray-700 pt-4 flex justify-between">
              <div className="text-sm text-gray-500">
                {format(new Date(submission.submittedAt), "MMM dd, yyyy")}
              </div>
              <div className="font-medium text-emerald-500">
                {submission.reward || "Pending"}
              </div>
            </CardFooter>
          </Card>
        );
      })}
    </div>
  );
}
