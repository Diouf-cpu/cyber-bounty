import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertScanSchema } from "@shared/schema";
import PageLayout from "@/components/layout/PageLayout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { AlertTriangle, ShieldCheck } from "lucide-react";
import { useLocation } from "wouter";

// Extend the schema with validation rules
const formSchema = insertScanSchema.extend({
  targetUrl: z.string().url("Please enter a valid URL").min(1, "Target URL is required"),
  hasPermission: z.boolean().refine(val => val === true, {
    message: "You must confirm you have permission to scan this target",
  }),
});

export default function NewScan() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [intensity, setIntensity] = useState(3);
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      targetUrl: "",
      scanType: "quick",
      vulnerabilityTypes: ["sql_injection", "xss", "csrf", "directory_traversal", "auth_bypass", "misconfiguration"],
      scanIntensity: 3,
      hasPermission: false,
      status: "pending"
    },
  });

  const mutation = useMutation({
    mutationFn: (data: z.infer<typeof formSchema>) => {
      return apiRequest("POST", "/api/scans", data);
    },
    onSuccess: async () => {
      toast({
        title: "Scan started successfully",
        description: "Your security scan is now in progress.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/scans"] });
      navigate("/");
    },
    onError: (error) => {
      toast({
        title: "Error starting scan",
        description: (error as Error).message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    // Apply the current intensity value
    values.scanIntensity = intensity;
    // Use real scanner instead of simulation
    const scanData = {
      ...values,
      useRealScanner: true
    };
    mutation.mutate(scanData);
  };

  return (
    <PageLayout>
      <div className="p-6 pb-24 overflow-y-auto max-h-screen">
        <header className="mb-6">
          <h1 className="text-2xl font-bold flex items-center">
            <ShieldCheck className="mr-2 text-blue-500" size={28} />
            New Security Scan
          </h1>
          <p className="text-gray-400 mt-1">Configure and start a new vulnerability scan on your target.</p>
        </header>
        
        <Card className="bg-neutral-900 border-gray-700 mb-6">
          <CardHeader>
            <CardTitle>Scan Configuration</CardTitle>
            <CardDescription className="text-gray-400">
              Set up the parameters for your vulnerability scan. Remember to only scan targets you have permission to test.
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="flex justify-end mb-4">
                  <Button 
                    type="submit" 
                    disabled={mutation.isPending}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    {mutation.isPending ? "Starting Scan..." : "Start Scan"}
                  </Button>
                </div>
                <FormField
                  control={form.control}
                  name="targetUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-base">Target URL</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="https://example.com" 
                          {...field} 
                          className="bg-neutral-950 border-gray-700 text-white"
                        />
                      </FormControl>
                      <FormDescription className="text-gray-400">
                        The website or application you want to scan for vulnerabilities
                      </FormDescription>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="scanType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-base">Scan Type</FormLabel>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <RadioGroup 
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex flex-col space-y-3"
                        >
                          <div className={`flex items-center rounded-lg border p-4 transition-colors ${field.value === "quick" ? "border-green-500 bg-green-950 bg-opacity-20" : "border-gray-700 hover:bg-neutral-800"}`}>
                            <RadioGroupItem value="quick" id="scanTypeQuick" className={`mr-2 ${field.value === "quick" ? "text-green-500" : ""}`}/>
                            <Label htmlFor="scanTypeQuick" className="flex flex-col cursor-pointer w-full">
                              <span className={`font-medium text-base ${field.value === "quick" ? "text-green-400" : ""}`}>Quick Scan</span>
                              <span className="text-sm text-gray-400">Basic check for common vulnerabilities (~15 min)</span>
                            </Label>
                          </div>
                          
                          <div className={`flex items-center rounded-lg border p-4 transition-colors ${field.value === "comprehensive" ? "border-green-500 bg-green-950 bg-opacity-20" : "border-gray-700 hover:bg-neutral-800"}`}>
                            <RadioGroupItem value="comprehensive" id="scanTypeComprehensive" className={`mr-2 ${field.value === "comprehensive" ? "text-green-500" : ""}`}/>
                            <Label htmlFor="scanTypeComprehensive" className="flex flex-col cursor-pointer w-full">
                              <span className={`font-medium text-base ${field.value === "comprehensive" ? "text-green-400" : ""}`}>Comprehensive</span>
                              <span className="text-sm text-gray-400">In-depth analysis of all vulnerability types (1-3 hrs)</span>
                            </Label>
                          </div>
                        </RadioGroup>
                      </div>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="vulnerabilityTypes"
                  render={() => (
                    <FormItem>
                      <FormLabel className="text-base">Vulnerability Types</FormLabel>
                      <div className="bg-neutral-950 border border-gray-700 rounded-lg p-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                          <FormField
                            control={form.control}
                            name="vulnerabilityTypes"
                            render={({ field }) => (
                              <FormItem className="flex items-center space-x-2">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes("sql_injection")}
                                    onCheckedChange={(checked) => {
                                      const current = field.value || [];
                                      if (checked) {
                                        field.onChange([...current, "sql_injection"]);
                                      } else {
                                        field.onChange(current.filter(value => value !== "sql_injection"));
                                      }
                                    }}
                                    className={field.value?.includes("sql_injection") ? "border-green-500 data-[state=checked]:bg-green-500 data-[state=checked]:text-green-50" : ""}
                                  />
                                </FormControl>
                                <FormLabel className={`text-sm ${field.value?.includes("sql_injection") ? "text-green-400 font-medium" : ""}`}>SQL Injection</FormLabel>
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="vulnerabilityTypes"
                            render={({ field }) => (
                              <FormItem className="flex items-center space-x-2">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes("xss")}
                                    onCheckedChange={(checked) => {
                                      const current = field.value || [];
                                      if (checked) {
                                        field.onChange([...current, "xss"]);
                                      } else {
                                        field.onChange(current.filter(value => value !== "xss"));
                                      }
                                    }}
                                    className={field.value?.includes("xss") ? "border-green-500 data-[state=checked]:bg-green-500 data-[state=checked]:text-green-50" : ""}
                                  />
                                </FormControl>
                                <FormLabel className={`text-sm ${field.value?.includes("xss") ? "text-green-400 font-medium" : ""}`}>Cross-Site Scripting (XSS)</FormLabel>
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="vulnerabilityTypes"
                            render={({ field }) => (
                              <FormItem className="flex items-center space-x-2">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes("csrf")}
                                    onCheckedChange={(checked) => {
                                      const current = field.value || [];
                                      if (checked) {
                                        field.onChange([...current, "csrf"]);
                                      } else {
                                        field.onChange(current.filter(value => value !== "csrf"));
                                      }
                                    }}
                                    className={field.value?.includes("csrf") ? "border-green-500 data-[state=checked]:bg-green-500 data-[state=checked]:text-green-50" : ""}
                                  />
                                </FormControl>
                                <FormLabel className={`text-sm ${field.value?.includes("csrf") ? "text-green-400 font-medium" : ""}`}>Cross-Site Request Forgery</FormLabel>
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="vulnerabilityTypes"
                            render={({ field }) => (
                              <FormItem className="flex items-center space-x-2">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes("directory_traversal")}
                                    onCheckedChange={(checked) => {
                                      const current = field.value || [];
                                      if (checked) {
                                        field.onChange([...current, "directory_traversal"]);
                                      } else {
                                        field.onChange(current.filter(value => value !== "directory_traversal"));
                                      }
                                    }}
                                    className={field.value?.includes("directory_traversal") ? "border-green-500 data-[state=checked]:bg-green-500 data-[state=checked]:text-green-50" : ""}
                                  />
                                </FormControl>
                                <FormLabel className={`text-sm ${field.value?.includes("directory_traversal") ? "text-green-400 font-medium" : ""}`}>Directory Traversal</FormLabel>
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="vulnerabilityTypes"
                            render={({ field }) => (
                              <FormItem className="flex items-center space-x-2">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes("auth_bypass")}
                                    onCheckedChange={(checked) => {
                                      const current = field.value || [];
                                      if (checked) {
                                        field.onChange([...current, "auth_bypass"]);
                                      } else {
                                        field.onChange(current.filter(value => value !== "auth_bypass"));
                                      }
                                    }}
                                    className={field.value?.includes("auth_bypass") ? "border-green-500 data-[state=checked]:bg-green-500 data-[state=checked]:text-green-50" : ""}
                                  />
                                </FormControl>
                                <FormLabel className={`text-sm ${field.value?.includes("auth_bypass") ? "text-green-400 font-medium" : ""}`}>Authentication Issues</FormLabel>
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="vulnerabilityTypes"
                            render={({ field }) => (
                              <FormItem className="flex items-center space-x-2">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes("misconfiguration")}
                                    onCheckedChange={(checked) => {
                                      const current = field.value || [];
                                      if (checked) {
                                        field.onChange([...current, "misconfiguration"]);
                                      } else {
                                        field.onChange(current.filter(value => value !== "misconfiguration"));
                                      }
                                    }}
                                    className={field.value?.includes("misconfiguration") ? "border-green-500 data-[state=checked]:bg-green-500 data-[state=checked]:text-green-50" : ""}
                                  />
                                </FormControl>
                                <FormLabel className={`text-sm ${field.value?.includes("misconfiguration") ? "text-green-400 font-medium" : ""}`}>Misconfigured Services</FormLabel>
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>
                    </FormItem>
                  )}
                />

                <FormItem>
                  <FormLabel className="text-base">Scan Intensity</FormLabel>
                  <div className="bg-neutral-950 border border-gray-700 rounded-lg p-4">
                    <div className="pt-2 px-2">
                      <Slider
                        defaultValue={[3]}
                        max={5}
                        min={1}
                        step={1}
                        value={[intensity]}
                        onValueChange={(vals) => setIntensity(vals[0])}
                      />
                    </div>
                    <div className="flex justify-between text-sm text-gray-400 mt-2 px-2">
                      <span>Gentle</span>
                      <span>Moderate</span>
                      <span>Aggressive</span>
                    </div>
                    
                    <div className="mt-3 text-xs text-gray-500">
                      Higher intensity may find more vulnerabilities but increases the risk of causing performance issues on the target.
                    </div>
                  </div>
                </FormItem>

                <div className="bg-amber-950 bg-opacity-20 border border-amber-800 text-amber-500 rounded-lg p-4">
                  <div className="flex">
                    <AlertTriangle className="h-5 w-5 mr-3 flex-shrink-0 mt-0.5" />
                    <div>
                      <div className="font-medium mb-1">Ethical Warning</div>
                      <p className="text-sm">
                        I confirm that I have explicit permission to perform security testing on this target.
                        I understand that unauthorized scanning may be illegal and against terms of service.
                      </p>
                    </div>
                  </div>
                </div>

                <FormField
                  control={form.control}
                  name="hasPermission"
                  render={({ field }) => (
                    <FormItem className="flex items-center space-x-2">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          className={field.value ? "border-green-500 data-[state=checked]:bg-green-500 data-[state=checked]:text-green-50" : ""}
                        />
                      </FormControl>
                      <FormLabel className={`text-sm font-medium ${field.value ? "text-green-400" : ""}`}>
                        I confirm I have explicit permission to test this target
                      </FormLabel>
                    </FormItem>
                  )}
                />
              </form>
            </Form>
          </CardContent>
        </Card>
        
        <Card className="bg-neutral-900 border-gray-700">
          <CardHeader>
            <CardTitle>Ethical Scanning Guidelines</CardTitle>
            <CardDescription className="text-gray-400">
              Important rules to follow when performing security testing
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="border border-gray-700 rounded-lg p-4">
                  <h3 className="text-lg font-medium mb-2 text-blue-500">Do's</h3>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start">
                      <span className="text-emerald-500 mr-2">✓</span>
                      <span>Obtain explicit permission before testing</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-emerald-500 mr-2">✓</span>
                      <span>Respect the scope of the testing agreement</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-emerald-500 mr-2">✓</span>
                      <span>Report vulnerabilities responsibly</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-emerald-500 mr-2">✓</span>
                      <span>Be mindful of the impact on the target system</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-emerald-500 mr-2">✓</span>
                      <span>Follow platform-specific guidelines for bug bounties</span>
                    </li>
                  </ul>
                </div>
                
                <div className="border border-gray-700 rounded-lg p-4">
                  <h3 className="text-lg font-medium mb-2 text-red-500">Don'ts</h3>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start">
                      <span className="text-red-500 mr-2">✗</span>
                      <span>Test without authorization</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-red-500 mr-2">✗</span>
                      <span>Attempt to access, modify, or delete user data</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-red-500 mr-2">✗</span>
                      <span>Use excessive scanning that may cause denial of service</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-red-500 mr-2">✗</span>
                      <span>Share vulnerabilities publicly before disclosure</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-red-500 mr-2">✗</span>
                      <span>Use findings for malicious purposes</span>
                    </li>
                  </ul>
                </div>
              </div>
              
              <div className="text-sm text-gray-400 mt-4">
                <strong className="text-blue-500">Remember:</strong> Ethical hacking and bug bounty hunting are about helping organizations improve their security, not exploiting vulnerabilities for personal gain.
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  );
}
