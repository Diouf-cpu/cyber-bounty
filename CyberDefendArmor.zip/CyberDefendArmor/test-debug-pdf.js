/**
 * Simple test script to debug PDF generation
 */
import PDFDocument from 'pdfkit';
import * as fs from 'fs';
import * as path from 'path';

// Function to generate a simple PDF
function generateSimplePdf() {
  console.log('Starting simple PDF generation test...');
  
  try {
    // Create PDF document
    const doc = new PDFDocument({
      margin: 50,
      size: 'A4',
      info: {
        Title: 'Test PDF Document',
        Author: 'Debug Script'
      }
    });
    
    console.log('PDF Document created');
    
    // Set up buffering
    const buffers = [];
    doc.on('data', data => buffers.push(data));
    
    console.log('Buffer capturing set up');
    
    // Add content to the PDF
    doc.font('Helvetica-Bold')
       .fontSize(24)
       .text('Test PDF Document', { align: 'center' })
       .moveDown(1);
       
    doc.font('Helvetica')
       .fontSize(14)
       .text('This is a test PDF document', { align: 'center' })
       .moveDown(0.5)
       .text(`Generated on: ${new Date().toLocaleString()}`, { align: 'center' })
       .moveDown(2);
       
    doc.font('Helvetica-Bold')
       .fontSize(18)
       .text('Sample Heading', { underline: true })
       .moveDown(1);
       
    doc.font('Helvetica')
       .fontSize(12)
       .text('This is sample text for testing PDF generation.')
       .moveDown(1);
       
    // Finalize PDF
    doc.end();
    
    console.log('PDF content added and document finalized');
    
    // Create a promise for when the document is fully generated
    return new Promise((resolve, reject) => {
      doc.on('end', () => {
        const pdfBuffer = Buffer.concat(buffers);
        console.log(`PDF generated successfully. Buffer size: ${pdfBuffer.length} bytes`);
        
        // Save PDF to disk
        try {
          const reportsDir = path.join(process.cwd(), 'reports');
          console.log(`Reports directory path: ${reportsDir}`);
          
          // Create directory if it doesn't exist
          if (!fs.existsSync(reportsDir)) {
            console.log(`Creating reports directory at ${reportsDir}`);
            fs.mkdirSync(reportsDir, { recursive: true });
          }
          
          const filename = `test_debug_${new Date().toISOString().split('T')[0]}.pdf`;
          const filePath = path.join(reportsDir, filename);
          console.log(`Writing file to: ${filePath}`);
          
          fs.writeFileSync(filePath, pdfBuffer);
          
          if (fs.existsSync(filePath)) {
            const stats = fs.statSync(filePath);
            console.log(`File successfully saved: ${filePath}, size: ${stats.size} bytes`);
          } else {
            console.error(`Failed to save file: ${filePath}`);
          }
          
          resolve({ success: true, pdfBuffer, filePath });
        } catch (error) {
          console.error('Error saving PDF to disk:', error);
          reject(error);
        }
      });
      
      // Handle errors
      doc.on('error', (error) => {
        console.error('Error generating PDF:', error);
        reject(error);
      });
    });
  } catch (error) {
    console.error('Error setting up PDF generation:', error);
    if (error.stack) {
      console.error(error.stack);
    }
    throw error;
  }
}

// Execute the test
async function runTest() {
  try {
    console.log('Starting PDF debug test');
    const result = await generateSimplePdf();
    
    console.log('PDF test completed successfully');
    console.log(`PDF file available at: ${result.filePath}`);
  } catch (error) {
    console.error('Test failed with error:', error);
  }
}

// Run the test
runTest();