import { InsertVulnerability } from '../shared/schema';
import axios from 'axios';
import * as fs from 'fs';
import * as path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

// ZAP API configuration - these would be set when ZAP is running
interface ZapConfig {
  apiKey: string;
  zapUrl: string;
  isRunning: boolean;
}

// Default configuration
const zapConfig: ZapConfig = {
  apiKey: process.env.ZAP_API_KEY || 'change-me-9001',
  zapUrl: process.env.ZAP_URL || 'http://localhost:8080',
  isRunning: false
};

/**
 * Check if ZAP is running and accessible
 */
export async function checkZapStatus(): Promise<boolean> {
  try {
    const response = await axios.get(`${zapConfig.zapUrl}/JSON/core/view/version/?apikey=${zapConfig.apiKey}`, {
      timeout: 2000 // 2 second timeout
    });
    zapConfig.isRunning = response.status === 200;
    return zapConfig.isRunning;
  } catch (error) {
    console.log('ZAP is not running or not accessible');
    zapConfig.isRunning = false;
    return false;
  }
}

/**
 * Start ZAP daemon process (if it's installed locally)
 */
export async function startZapDaemon(): Promise<boolean> {
  try {
    // Check if ZAP is already running
    if (await checkZapStatus()) {
      console.log('ZAP is already running');
      return true;
    }

    // Try to start ZAP daemon using Docker (if Docker is available)
    console.log('Attempting to start ZAP daemon...');
    await execAsync('docker run -d -p 8080:8080 -p 8090:8090 --name zapdaemon owasp/zap2docker-stable zap.sh -daemon -host 0.0.0.0 -port 8080 -config api.disablekey=false -config api.key=change-me-9001');
    
    // Wait for ZAP to start up
    let attempts = 0;
    const maxAttempts = 10;
    while (attempts < maxAttempts) {
      await new Promise(resolve => setTimeout(resolve, 2000)); // Wait 2 seconds
      if (await checkZapStatus()) {
        console.log('ZAP daemon started successfully');
        return true;
      }
      attempts++;
    }
    
    console.log('Failed to start ZAP daemon after multiple attempts');
    return false;
  } catch (error) {
    console.error('Error starting ZAP daemon:', error);
    return false;
  }
}

/**
 * Perform an active scan using OWASP ZAP
 */
export async function performZapScan(targetUrl: string): Promise<InsertVulnerability[]> {
  const vulnerabilities: InsertVulnerability[] = [];
  
  try {
    // Ensure ZAP is running
    if (!zapConfig.isRunning && !await startZapDaemon()) {
      console.log('ZAP is not running and could not be started');
      return vulnerabilities;
    }
    
    // Step 1: Access the target URL (Spider)
    console.log(`Starting ZAP spider for target: ${targetUrl}`);
    const spiderResponse = await axios.get(
      `${zapConfig.zapUrl}/JSON/spider/action/scan/?apikey=${zapConfig.apiKey}&url=${encodeURIComponent(targetUrl)}&recurse=true&maxChildren=10`
    );
    
    const spiderId = spiderResponse.data.scan;
    
    // Step 2: Wait for spider to complete
    let spiderProgress = 0;
    while (spiderProgress < 100) {
      await new Promise(resolve => setTimeout(resolve, 2000)); // Wait 2 seconds
      const progressResponse = await axios.get(
        `${zapConfig.zapUrl}/JSON/spider/view/status/?apikey=${zapConfig.apiKey}&scanId=${spiderId}`
      );
      spiderProgress = parseInt(progressResponse.data.status);
      console.log(`Spider progress: ${spiderProgress}%`);
    }
    
    // Step 3: Start active scan
    console.log(`Starting ZAP active scan for target: ${targetUrl}`);
    const scanResponse = await axios.get(
      `${zapConfig.zapUrl}/JSON/ascan/action/scan/?apikey=${zapConfig.apiKey}&url=${encodeURIComponent(targetUrl)}&recurse=true&inScopeOnly=false&scanPolicyName=&method=&postData=&contextId=`
    );
    
    const scanId = scanResponse.data.scan;
    
    // Step 4: Wait for active scan to complete
    let scanProgress = 0;
    while (scanProgress < 100) {
      await new Promise(resolve => setTimeout(resolve, 5000)); // Wait 5 seconds
      const progressResponse = await axios.get(
        `${zapConfig.zapUrl}/JSON/ascan/view/status/?apikey=${zapConfig.apiKey}&scanId=${scanId}`
      );
      scanProgress = parseInt(progressResponse.data.status);
      console.log(`Active scan progress: ${scanProgress}%`);
    }
    
    // Step 5: Retrieve alerts (vulnerabilities)
    console.log('Retrieving ZAP scan results...');
    const alertsResponse = await axios.get(
      `${zapConfig.zapUrl}/JSON/core/view/alerts/?apikey=${zapConfig.apiKey}&baseurl=${encodeURIComponent(targetUrl)}`
    );
    
    const alerts = alertsResponse.data.alerts;
    
    // Step 6: Convert ZAP alerts to vulnerabilities
    alerts.forEach((alert: any) => {
      // Map ZAP risk levels to our severity levels
      const severityMap: { [key: string]: string } = {
        'High': 'critical',
        'Medium': 'high',
        'Low': 'medium',
        'Informational': 'low'
      };
      
      const vulnerability: InsertVulnerability = {
        scanId: 0, // This will be set when inserting
        name: alert.name,
        description: alert.description,
        location: alert.url,
        severity: severityMap[alert.risk] || 'low',
        status: 'open',
        details: `CWE ID: ${alert.cweid || 'Not specified'}\nWASPID: ${alert.wascid || 'Not specified'}\nSource: OWASP ZAP Scanner`,
        remediation: alert.solution || 'No specific remediation provided by ZAP',
        impact: alert.risk,
        request: alert.messageId ? `${alert.method} ${alert.url}\n${alert.evidence || ''}` : undefined,
        response: alert.otherInfo || undefined,
        references: alert.reference || undefined
      };
      
      vulnerabilities.push(vulnerability);
    });
    
    console.log(`ZAP scan completed. Found ${vulnerabilities.length} vulnerabilities.`);
    return vulnerabilities;
  } catch (error) {
    console.error('Error performing ZAP scan:', error);
    return vulnerabilities;
  }
}

/**
 * Generate a ZAP HTML report 
 */
export async function generateZapReport(targetUrl: string): Promise<string | null> {
  try {
    if (!zapConfig.isRunning) {
      console.log('ZAP is not running');
      return null;
    }
    
    // Generate HTML report
    const reportResponse = await axios.get(
      `${zapConfig.zapUrl}/OTHER/core/other/htmlreport/?apikey=${zapConfig.apiKey}`
    );
    
    const htmlReport = reportResponse.data;
    
    // Save report to disk
    const reportsDir = path.join(process.cwd(), 'reports');
    if (!fs.existsSync(reportsDir)) {
      fs.mkdirSync(reportsDir, { recursive: true });
    }
    
    const filename = `zap_report_${new Date().toISOString().replace(/:/g, '-')}.html`;
    const filePath = path.join(reportsDir, filename);
    
    fs.writeFileSync(filePath, htmlReport);
    console.log(`ZAP HTML report saved to: ${filePath}`);
    
    return filePath;
  } catch (error) {
    console.error('Error generating ZAP report:', error);
    return null;
  }
}

/**
 * Stop the ZAP daemon
 */
export async function stopZapDaemon(): Promise<boolean> {
  try {
    // Try to stop ZAP daemon (if it was started using Docker)
    await execAsync('docker stop zapdaemon && docker rm zapdaemon');
    console.log('ZAP daemon stopped');
    zapConfig.isRunning = false;
    return true;
  } catch (error) {
    console.error('Error stopping ZAP daemon:', error);
    return false;
  }
}