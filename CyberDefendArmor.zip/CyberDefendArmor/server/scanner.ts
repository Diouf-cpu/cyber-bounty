import { ScanType, VulnerabilityType } from "@shared/types";
import { InsertVulnerability, Vulnerability } from "@shared/schema";
import { storage } from "./storage";

// Basic vulnerability scanner module
// In a real-world application, this would use actual security scanning libraries
// This is a simplified version for demonstration purposes

export interface ScanOptions {
  targetUrl: string;
  scanType: string;
  vulnerabilityTypes: string[] | null; // Can be null in the database
  scanIntensity: number;
}

export class Scanner {
  private targetUrl: string;
  private scanType: string;
  private vulnerabilityTypes: string[];
  private scanIntensity: number;
  private scanId: number;

  constructor(options: ScanOptions, scanId: number) {
    this.targetUrl = options.targetUrl;
    this.scanType = options.scanType;
    this.vulnerabilityTypes = options.vulnerabilityTypes || [];
    this.scanIntensity = options.scanIntensity;
    this.scanId = scanId;
  }

  async scan(): Promise<{ success: boolean; message?: string }> {
    try {
      // Update scan status to in_progress
      await storage.updateScanStatus(this.scanId, "in_progress");
      
      console.log(`Starting ${this.scanType} scan on ${this.targetUrl} with intensity ${this.scanIntensity}`);
      console.log(`Scanning for vulnerability types: ${this.vulnerabilityTypes.join(', ')}`);

      // Simulate a scan running - different duration based on scan type and intensity
      const baseDuration = this.scanType === ScanType.QUICK ? 3000 : 8000;
      const scanDuration = baseDuration * (this.scanIntensity / 3);
      
      // Simulate a port scan phase
      console.log(`[Scan ${this.scanId}] Starting port scan on target...`);
      await this.simulateScan(scanDuration * 0.2);
      console.log(`[Scan ${this.scanId}] Port scan complete. Discovered open ports: 80, 443, 22`);
      
      // Simulate a service enumeration phase
      console.log(`[Scan ${this.scanId}] Enumerating services on target...`);
      await this.simulateScan(scanDuration * 0.3);
      console.log(`[Scan ${this.scanId}] Service enumeration complete. Found: HTTP, HTTPS, SSH`);
      
      // Simulate a vulnerability detection phase
      console.log(`[Scan ${this.scanId}] Probing for vulnerabilities...`);
      await this.simulateScan(scanDuration * 0.5);
      
      // Generate simulated vulnerabilities
      const vulnerabilities = await this.generateSimulatedVulnerabilities();
      console.log(`[Scan ${this.scanId}] Vulnerability probing complete. Found ${vulnerabilities.length} vulnerabilities.`);

      // Complete the scan
      await storage.updateScanCompletion(this.scanId);
      
      console.log(`[Scan ${this.scanId}] Scan completed successfully for ${this.targetUrl}`);

      return {
        success: true,
        message: `Scan completed successfully for ${this.targetUrl}. Found ${vulnerabilities.length} vulnerabilities.`
      };
    } catch (error) {
      console.error(`[Scan ${this.scanId}] Scan failed: ${(error as Error).message}`);
      await storage.updateScanStatus(this.scanId, "failed");
      return {
        success: false,
        message: `Scan failed: ${(error as Error).message}`
      };
    }
  }

  private async simulateScan(duration: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, duration));
  }

  private async generateSimulatedVulnerabilities(): Promise<Vulnerability[]> {
    const vulnCount = this.calculateVulnerabilityCount();
    
    const possibleVulnerabilities = this.getPossibleVulnerabilities();
    
    // Randomly select vulnerabilities from the possibilities based on the scan options
    const selectedVulnerabilities = this.selectRandomVulnerabilities(possibleVulnerabilities, vulnCount);
    
    // Create the vulnerabilities in storage
    const createdVulns = [];
    for (const vuln of selectedVulnerabilities) {
      const createdVuln = await storage.createVulnerability(vuln);
      createdVulns.push(createdVuln);
    }
    
    return createdVulns;
  }

  private calculateVulnerabilityCount(): number {
    // Calculate number of vulnerabilities based on scan type and intensity
    const baseCount = this.scanType === ScanType.QUICK ? 2 : 5;
    const intensityMultiplier = this.scanIntensity / 3;
    const randomVariance = Math.floor(Math.random() * 3); // Add some randomness
    
    return Math.max(1, Math.floor(baseCount * intensityMultiplier) + randomVariance);
  }

  private getPossibleVulnerabilities(): InsertVulnerability[] {
    const vulnerabilities: InsertVulnerability[] = [];
    
    // Only add vulnerabilities that were requested in the scan
    if (this.vulnerabilityTypes.includes(VulnerabilityType.SQL_INJECTION)) {
      vulnerabilities.push({
        scanId: this.scanId,
        title: "SQL Injection in Search Function",
        type: VulnerabilityType.SQL_INJECTION,
        severity: "critical",
        location: `https://${this.targetUrl}/search?q=test`,
        description: "The search functionality is vulnerable to SQL injection attacks due to improper handling of user input.",
        stepsToReproduce: "1. Navigate to the search page\n2. Enter the payload: ' OR '1'='1\n3. Observe that all records are returned",
        impact: "An attacker can extract sensitive data, modify database contents, or potentially gain administrative access to the database.",
        remediation: "Use parameterized queries or prepared statements instead of string concatenation. Implement proper input validation.",
        proofOfConcept: `GET /search?q=test%27%20OR%20%271%27%3D%271 HTTP/1.1\nHost: ${this.targetUrl}`,
        cvssScore: "9.8",
        status: "open"
      });
    }
    
    if (this.vulnerabilityTypes.includes(VulnerabilityType.XSS)) {
      vulnerabilities.push({
        scanId: this.scanId,
        title: "Stored XSS in Comment System",
        type: VulnerabilityType.XSS,
        severity: "high",
        location: `https://${this.targetUrl}/comments`,
        description: "The comment system fails to properly sanitize user input, allowing stored XSS attacks.",
        stepsToReproduce: "1. Add a comment containing: <script>alert('XSS')</script>\n2. When any user views the page, the script executes",
        impact: "Attackers can steal cookies, redirect users to malicious sites, or perform actions on behalf of victims.",
        remediation: "Implement proper output encoding. Use a content security policy (CSP) and sanitize user inputs.",
        proofOfConcept: `POST /comments HTTP/1.1\nHost: ${this.targetUrl}\nContent-Type: application/x-www-form-urlencoded\n\ncomment=<script>alert('XSS')</script>`,
        cvssScore: "7.5",
        status: "open"
      });

      vulnerabilities.push({
        scanId: this.scanId,
        title: "Reflected XSS in Search Results",
        type: VulnerabilityType.XSS,
        severity: "medium",
        location: `https://${this.targetUrl}/search?q=test`,
        description: "Search results page reflects user input without proper encoding, leading to XSS vulnerabilities.",
        stepsToReproduce: "1. Navigate to the search page\n2. Enter the payload: <img src=x onerror=alert('XSS')>\n3. The script executes when the results load",
        impact: "Attackers can craft malicious links that execute scripts in victims' browsers when clicked.",
        remediation: "Implement proper output encoding for all user-supplied data displayed on the page.",
        proofOfConcept: `GET /search?q=%3Cimg%20src%3Dx%20onerror%3Dalert%28%27XSS%27%29%3E HTTP/1.1\nHost: ${this.targetUrl}`,
        cvssScore: "6.1",
        status: "open"
      });
    }
    
    if (this.vulnerabilityTypes.includes(VulnerabilityType.CSRF)) {
      vulnerabilities.push({
        scanId: this.scanId,
        title: "CSRF in Account Settings",
        type: VulnerabilityType.CSRF,
        severity: "medium",
        location: `https://${this.targetUrl}/account/settings`,
        description: "The account settings page lacks CSRF protection, allowing attackers to perform actions on behalf of authenticated users.",
        stepsToReproduce: "1. Create a malicious page with a form that submits to the account settings endpoint\n2. When a logged-in user visits the page, their settings are changed",
        impact: "Attackers can change user email, password, or other settings without user consent.",
        remediation: "Implement anti-CSRF tokens in all forms. Validate the origin and referrer headers.",
        proofOfConcept: `<form action="https://${this.targetUrl}/account/settings" method="POST">\n  <input type="hidden" name="email" value="attacker@evil.com">\n  <input type="submit" value="Click me">\n</form>`,
        cvssScore: "6.5",
        status: "open"
      });
    }
    
    if (this.vulnerabilityTypes.includes(VulnerabilityType.DIRECTORY_TRAVERSAL)) {
      vulnerabilities.push({
        scanId: this.scanId,
        title: "Directory Traversal in File Download",
        type: VulnerabilityType.DIRECTORY_TRAVERSAL,
        severity: "high",
        location: `https://${this.targetUrl}/download?file=document.pdf`,
        description: "The file download functionality is vulnerable to path traversal attacks, allowing access to files outside the intended directory.",
        stepsToReproduce: "1. Navigate to the download page\n2. Modify the file parameter to: ../../../etc/passwd\n3. Observe server files being exposed",
        impact: "Attackers can access sensitive configuration files, credentials, and other restricted files on the server.",
        remediation: "Validate and sanitize file path inputs. Use a whitelist of allowed files or file patterns.",
        proofOfConcept: `GET /download?file=..%2F..%2F..%2Fetc%2Fpasswd HTTP/1.1\nHost: ${this.targetUrl}`,
        cvssScore: "7.8",
        status: "open"
      });
    }

    // Add more vulnerability types as needed
    
    return vulnerabilities;
  }

  private selectRandomVulnerabilities(possibilities: InsertVulnerability[], count: number): InsertVulnerability[] {
    // If we have fewer possibilities than requested count, return them all
    if (possibilities.length <= count) {
      return possibilities;
    }
    
    // Shuffle the array and take the first 'count' elements
    const shuffled = [...possibilities].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
  }
}

export const startScan = async (scanId: number): Promise<{ success: boolean; message?: string }> => {
  const scan = await storage.getScan(scanId);
  
  if (!scan) {
    return { success: false, message: "Scan not found" };
  }
  
  // Ensure we have valid vulnerability types
  const vulnerabilityTypes = scan.vulnerabilityTypes || [];
  
  const scanner = new Scanner(
    {
      targetUrl: scan.targetUrl,
      scanType: scan.scanType,
      vulnerabilityTypes: vulnerabilityTypes,
      scanIntensity: scan.scanIntensity
    },
    scanId
  );
  
  return scanner.scan();
};
