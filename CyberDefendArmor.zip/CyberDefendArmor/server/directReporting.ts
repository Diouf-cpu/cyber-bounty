import { Vulnerability } from '@shared/schema';
import { DirectVulnerabilityReport, NotificationMethod, ReportFormat } from '@shared/types';
import axios from 'axios';
import * as crypto from 'crypto';
import * as fs from 'fs';
import * as path from 'path';
import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { generatePdfReport, generateWordReport, saveReportToDisk } from './reportGenerator';
// Import the new Brevo email service
import { 
  sendVulnerabilityReportEmail, 
  sendPdfReportEmail, 
  sendTestEmail, 
  sendWordReportEmail 
} from './brevoEmailService';

// Default configuration
const defaultConfig = {
  enabled: true,
  reportEmail: 'capitalcopycraft@gmail.com', // Direct reporting to the requestor's email
  includeScreenshots: true,
  includePoc: true,
  notificationMethod: NotificationMethod.EMAIL,
  webhookUrl: process.env.WEBHOOK_URL ? process.env.WEBHOOK_URL : ''
};

// In-memory store for reports (temporary, not persisted)
// This allows the requestor to retrieve reports via API
export const reportStore: Map<string, DirectVulnerabilityReport> = new Map();

/**
 * Convert a vulnerability to a direct report format
 */
export function convertToDirectReport(vulnerability: Vulnerability, targetUrl: string): DirectVulnerabilityReport {
  const reportId = generateReportId();
  
  const report: DirectVulnerabilityReport = {
    timestamp: new Date().toISOString(),
    targetUrl,
    vulnerabilityType: vulnerability.type || 'unknown',
    severity: vulnerability.severity || 'unknown',
    title: vulnerability.title || 'Unknown Vulnerability',
    description: vulnerability.description || 'No description available',
    stepsToReproduce: vulnerability.stepsToReproduce || 'No steps provided',
    impact: vulnerability.impact || 'Unknown impact',
    proofOfConcept: vulnerability.proofOfConcept || 'No proof of concept available',
    cvssScore: vulnerability.cvssScore || '0.0',
    scanId: vulnerability.scanId,
    reportId
  };
  
  // Store the report temporarily for retrieval
  reportStore.set(reportId, report);
  
  return report;
}

/**
 * Generate a unique report ID
 */
function generateReportId(): string {
  return crypto.randomUUID();
}

// Store the HTTP server for WebSocket broadcasting
let httpServer: Server | null = null;

/**
 * Set the HTTP server instance for WebSocket broadcasting
 */
export function setHttpServer(server: Server): void {
  httpServer = server;
}

/**
 * Send a report directly to the requestor instead of storing in database
 */
export async function sendDirectReport(report: DirectVulnerabilityReport): Promise<boolean> {
  console.log(`Sending direct report for vulnerability: ${report.title} to ${defaultConfig.reportEmail}`);
  
  try {
    // Implementation based on preferred notification method
    if (defaultConfig.notificationMethod === NotificationMethod.WEBHOOK && defaultConfig.webhookUrl) {
      // Send via webhook
      await axios.post(defaultConfig.webhookUrl, report);
      console.log(`Report ${report.reportId} sent via webhook`);
    } else {
      // Send via email using our SendGrid email service
      const success = await sendVulnerabilityReportEmail(report, report.targetUrl);
      
      if (success) {
        console.log(`Report ${report.reportId} sent via email to ${defaultConfig.reportEmail}`);
      } else {
        console.error(`Failed to send email report ${report.reportId}`);
      }
    }
    
    // Broadcast the vulnerability via WebSocket for real-time updates
    if (httpServer) {
      broadcastVulnerability(httpServer, report);
    }
    
    return true;
  } catch (error) {
    console.error('Error sending direct report:', error);
    return false;
  }
}

/**
 * Save a screenshot or evidence file for a report
 */
export function saveReportEvidence(reportId: string, evidenceData: Buffer, filename: string): string {
  // Create evidence directory if it doesn't exist
  const evidenceDir = path.join(process.cwd(), 'evidence', reportId);
  if (!fs.existsSync(evidenceDir)) {
    fs.mkdirSync(evidenceDir, { recursive: true });
  }
  
  const filePath = path.join(evidenceDir, filename);
  fs.writeFileSync(filePath, evidenceData);
  
  return filePath;
}

/**
 * Get a report by ID - this allows the requestor to get reports via API
 */
export function getReportById(reportId: string): DirectVulnerabilityReport | undefined {
  return reportStore.get(reportId);
}

/**
 * Get all reports - this allows the requestor to get reports via API
 */
export function getAllReports(): DirectVulnerabilityReport[] {
  return Array.from(reportStore.values());
}

/**
 * Delete a report by ID - requestor can delete reports after processing
 */
export function deleteReport(reportId: string): boolean {
  return reportStore.delete(reportId);
}

/**
 * Delete all reports - requestor can clear all reports
 */
export function clearAllReports(): void {
  reportStore.clear();
}

/**
 * Configure the direct reporting system
 */
export function configureDirectReporting(config: any): void {
  Object.assign(defaultConfig, config);
}

/**
 * Generate a PDF report from a list of vulnerabilities and send it via email
 */
export async function generateAndSendPdfReport(vulnerabilities: Vulnerability[] | DirectVulnerabilityReport[], targetUrl: string): Promise<boolean> {
  try {
    console.log(`Generating PDF report for ${vulnerabilities.length} vulnerabilities on ${targetUrl}`);
    
    // Generate the PDF buffer
    console.log('Starting PDF generation...');
    const pdfBuffer = await generatePdfReport(vulnerabilities, targetUrl);
    console.log(`PDF generation complete. Buffer size: ${pdfBuffer.length} bytes`);
    
    // Ensure the target URL is safe for filenames
    const safeTargetUrl = targetUrl.replace(/[^a-zA-Z0-9]/g, '_');
    
    // Optionally save a copy of the report
    const filename = `security_report_${safeTargetUrl}_${new Date().toISOString().split('T')[0]}.pdf`;
    console.log(`Saving report to disk with filename: ${filename}`);
    const filePath = saveReportToDisk(pdfBuffer, filename);
    console.log(`Report saved locally at: ${filePath}`);
    
    // Send the PDF via email
    console.log('Sending PDF report via email...');
    const success = await sendPdfReportEmail(vulnerabilities, targetUrl, pdfBuffer);
    
    if (success) {
      console.log(`PDF report for ${targetUrl} sent successfully`);
    } else {
      console.error(`Failed to send PDF report for ${targetUrl}`);
    }
    
    return success;
  } catch (error) {
    console.error('Error generating and sending PDF report:', error);
    if (error instanceof Error) {
      console.error('Error details:', error.message);
      console.error('Error stack:', error.stack);
    }
    return false;
  }
}

/**
 * Generate a Word document report from a list of vulnerabilities and send it via email
 */
export async function generateAndSendWordReport(vulnerabilities: Vulnerability[] | DirectVulnerabilityReport[], targetUrl: string): Promise<boolean> {
  try {
    console.log(`Generating Word report for ${vulnerabilities.length} vulnerabilities on ${targetUrl}`);
    
    // Generate the Word document buffer
    console.log('Starting Word document generation...');
    const docBuffer = await generateWordReport(vulnerabilities, targetUrl);
    console.log(`Word document generation complete. Buffer size: ${docBuffer.length} bytes`);
    
    // Ensure the target URL is safe for filenames
    const safeTargetUrl = targetUrl.replace(/[^a-zA-Z0-9]/g, '_');
    
    // Optionally save a copy of the report
    const filename = `security_report_${safeTargetUrl}_${new Date().toISOString().split('T')[0]}.docx`;
    console.log(`Saving Word report to disk with filename: ${filename}`);
    const filePath = saveReportToDisk(docBuffer, filename);
    console.log(`Word report saved locally at: ${filePath}`);
    
    // Send the document via email using the Brevo email service
    console.log('Sending Word report via email...');
    const success = await sendWordReportEmail(vulnerabilities, targetUrl, docBuffer);
    
    if (success) {
      console.log(`Word report for ${targetUrl} sent successfully`);
    } else {
      console.error(`Failed to send Word report for ${targetUrl}`);
    }
    
    return success;
  } catch (error) {
    console.error('Error generating and sending Word report:', error);
    if (error instanceof Error) {
      console.error('Error details:', error.message);
      console.error('Error stack:', error.stack);
    }
    return false;
  }
}

/**
 * Send a test email to verify SendGrid integration
 */
export async function sendTestDirectEmail(): Promise<boolean> {
  return await sendTestEmail();
}

/**
 * Send a real-time notification about a vulnerability via WebSocket
 */
export function broadcastVulnerability(server: Server, vulnerability: DirectVulnerabilityReport): void {
  try {
    // Get the WebSocket server instance from the HTTP server
    const wss = (server as any).wss as WebSocketServer;
    
    if (!wss) {
      console.error('WebSocket server not found. Make sure it has been properly initialized.');
      return;
    }
    
    const notification = {
      type: 'vulnerability',
      severity: vulnerability.severity,
      title: vulnerability.title,
      timestamp: new Date().toISOString(),
      targetUrl: vulnerability.targetUrl,
      reportId: vulnerability.reportId
    };
    
    // Count connected clients
    let connectedClients = 0;
    
    // Broadcast to all connected clients
    wss.clients.forEach((client: WebSocket) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(notification));
        connectedClients++;
      }
    });
    
    console.log(`Real-time notification broadcast to ${connectedClients} connected clients`);
  } catch (error) {
    console.error('Error broadcasting vulnerability via WebSocket:', error);
  }
}