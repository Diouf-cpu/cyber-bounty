import PDFDocument from 'pdfkit';
import { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType } from 'docx';
import { Vulnerability } from '../shared/schema';
import { DirectVulnerabilityReport } from '../shared/types';

// Add pdfkit module declaration to fix TypeScript error
declare module 'pdfkit';

// Helper function to get property value regardless of object type
function getVulnerabilityName(vulnerability: Vulnerability | DirectVulnerabilityReport): string {
  return 'title' in vulnerability ? vulnerability.title : (vulnerability as any).name || 'Unknown Vulnerability';
}

function getVulnerabilityLocation(vulnerability: Vulnerability | DirectVulnerabilityReport): string {
  return 'location' in vulnerability ? vulnerability.location : 
         ('targetUrl' in vulnerability ? vulnerability.targetUrl : 'Unknown location');
}

function getVulnerabilityDetails(vulnerability: Vulnerability | DirectVulnerabilityReport): string {
  return 'details' in vulnerability ? vulnerability.details || '' : 
         ('proofOfConcept' in vulnerability ? vulnerability.proofOfConcept || '' : '');
}

function getVulnerabilityRequest(vulnerability: Vulnerability | DirectVulnerabilityReport): string | undefined {
  return 'request' in vulnerability ? vulnerability.request : 
         ('stepsToReproduce' in vulnerability ? vulnerability.stepsToReproduce : undefined);
}

function getVulnerabilityResponse(vulnerability: Vulnerability | DirectVulnerabilityReport): string | undefined {
  return 'response' in vulnerability ? vulnerability.response : undefined;
}

async function attachScreenshot(vulnId: number): Promise<Buffer | undefined> {
  try {
    // Replace with your actual screenshot retrieval logic
    // This is a placeholder, replace with your actual storage mechanism
    const storage = {
        getScreenshot: async (vulnId: number) => {
            // Simulate fetching a screenshot - replace with your actual implementation
            if (vulnId === 1) {
                return Buffer.from('This is a sample screenshot', 'utf8');
            } else {
              return undefined;
            }
        }
    };
    return await storage.getScreenshot(vulnId);
  } catch (error) {
    console.error('Error fetching screenshot:', error);
    return undefined;
  }
}

async function saveVulnerabilityScreenshot(vulnId: number, screenshotData: Buffer): Promise<string> {
  try {
    // Replace with your actual screenshot saving logic
    return 'screenshot_path';
  } catch (error) {
    console.error('Error saving screenshot:', error);
    throw error;
  }
}

function getVulnerabilityRemediation(vulnerability: Vulnerability | DirectVulnerabilityReport): string | undefined {
  return 'remediation' in vulnerability ? vulnerability.remediation : undefined;
}
import * as fs from 'fs';
import * as path from 'path';

/**
 * Generate a PDF report for vulnerabilities
 */
export async function generatePdfReport(
  vulnerabilities: Vulnerability[] | DirectVulnerabilityReport[],
  targetUrl: string
): Promise<Buffer> {
  console.log(`Starting PDF report generation for ${targetUrl} with ${vulnerabilities.length} vulnerabilities`);
  return new Promise(async (resolve, reject) => {
    try {
      console.log('Initializing PDFDocument...');
      // Create a document
      const doc = new PDFDocument({ 
        margin: 50,
        size: 'A4',
        info: {
          Title: `Security Scan Report - ${targetUrl}`,
          Author: 'Ethical Penetration Testing Platform',
          Subject: 'Security Vulnerability Report',
          Keywords: 'security, vulnerability, penetration testing',
          CreationDate: new Date()
        }
      });

      // Buffer to store PDF data
      const chunks: Buffer[] = [];
      doc.on('data', (chunk: Buffer) => chunks.push(chunk));
      doc.on('end', () => {
        const result = Buffer.concat(chunks);
        console.log('PDF report generated successfully, size:', result.length);
        resolve(result);
      });
      doc.on('error', (err) => {
        console.error('Error generating PDF:', err);
        reject(err);
      });

      // Add title and metadata
      doc.font('Helvetica-Bold')
         .fontSize(24)
         .text('Security Vulnerability Report', { align: 'center' })
         .moveDown(1);

      doc.font('Helvetica')
         .fontSize(14)
         .text(`Target: ${targetUrl}`, { align: 'center' })
         .moveDown(0.5)
         .text(`Date: ${new Date().toLocaleDateString()}`, { align: 'center' })
         .moveDown(0.5)
         .text(`Vulnerabilities Found: ${vulnerabilities.length}`, { align: 'center' })
         .moveDown(2);

      // Executive Summary
      doc.font('Helvetica-Bold')
         .fontSize(18)
         .text('Executive Summary', { underline: true })
         .moveDown(1);

      doc.font('Helvetica')
         .fontSize(12)
         .text('This report presents the findings of a security assessment conducted on the specified target. The assessment was performed using the Ethical Penetration Testing Platform, which employs automated scanning techniques to identify potential security vulnerabilities.')
         .moveDown(1);

      // Add severity distribution
      const severityCounts = {
        critical: 0,
        high: 0,
        medium: 0,
        low: 0,
        info: 0
      };

      vulnerabilities.forEach(vuln => {
        const severity = vuln.severity.toLowerCase();
        if (severity in severityCounts) {
          severityCounts[severity as keyof typeof severityCounts]++;
        }
      });

      doc.font('Helvetica-Bold')
         .fontSize(14)
         .text('Vulnerability Severity Distribution:')
         .moveDown(0.5);

      doc.font('Helvetica')
         .fontSize(12);

      for (const [severity, count] of Object.entries(severityCounts)) {
        if (count > 0) {
          doc.text(`${severity.charAt(0).toUpperCase() + severity.slice(1)}: ${count}`);
        }
      }

      doc.moveDown(2);

      // Detailed findings
      doc.font('Helvetica-Bold')
         .fontSize(18)
         .text('Detailed Findings', { underline: true })
         .moveDown(1);

      // Add each vulnerability
      for (const vulnerability of vulnerabilities) {
        const colorForSeverity = (severity: string): string => {
          switch (severity.toLowerCase()) {
            case 'critical': return '#d9534f';
            case 'high': return '#f0ad4e';
            case 'medium': return '#5bc0de';
            case 'low': return '#5cb85c';
            default: return '#777777';
          }
        };

        const vulnName = getVulnerabilityName(vulnerability);
        const vulnLocation = getVulnerabilityLocation(vulnerability);
        const vulnDetails = getVulnerabilityDetails(vulnerability);
        const vulnRequest = getVulnerabilityRequest(vulnerability);
        const vulnResponse = getVulnerabilityResponse(vulnerability);
        const vulnRemediation = getVulnerabilityRemediation(vulnerability);
        const detectionDate = new Date().toUTCString();

        // Vulnerability Title
        // Using a background fill for better contrast
        doc.rect(50, doc.y, 500, 30)
           .fill('#f0f0f0');

        doc.font('Helvetica-Bold')
           .fontSize(16)
           .fillColor('#000000')
           .text(`${vulnerabilities.indexOf(vulnerability) + 1}. ${vulnName}`, 50, doc.y - 25)
           .moveDown(0.5);

        // Ensure severity colors have good contrast
        const severityColors = {
          critical: '#dc2626', // Red with good contrast
          high: '#b45309',    // Dark orange
          medium: '#047857',  // Dark teal
          low: '#1d4ed8',     // Dark blue
          info: '#4b5563'     // Dark gray
        };

        doc.font('Helvetica-Bold')
           .fontSize(12)
           .fillColor(severityColors[vulnerability.severity.toLowerCase()] || '#000000')
           .text(`Severity: ${vulnerability.severity}`)
           .text(`CVSS Score: ${vulnerability.cvssScore || 'N/A'}`)
           .fillColor('#000000')
           .moveDown(0.5);

        // Affected Endpoint
        doc.font('Helvetica-Bold')
           .text('Affected Endpoint:')
           .font('Helvetica')
           .text(vulnLocation)
           .moveDown(0.5);

        // Date Detected
        doc.font('Helvetica-Bold')
           .text('Date Detected:')
           .font('Helvetica')
           .text(detectionDate)
           .moveDown(0.5);

        // Description
        doc.font('Helvetica-Bold')
           .text('Description:')
           .font('Helvetica')
           .text(vulnerability.description)
           .moveDown(0.5);

        // Steps to Reproduce
        doc.font('Helvetica-Bold')
           .text('Steps to Reproduce:')
           .font('Helvetica')
           .text(vulnerability.stepsToReproduce || 'Not provided')
           .moveDown(0.5);

        // Proof of Concept
        doc.font('Helvetica-Bold')
           .text('Proof of Concept (PoC):')
           .font('Courier')
           .fontSize(10);

        if (vulnRequest) {
          doc.text('Request:')
             .text(vulnRequest, { width: 500 })
             .moveDown(0.25);
        }

        if (vulnResponse) {
          doc.text('Response:')
             .text(vulnResponse, { width: 500 });
        }
        doc.moveDown(0.5);

        // Impact
        doc.font('Helvetica-Bold')
           .fontSize(12)
           .text('Impact:')
           .font('Helvetica')
           .text(vulnerability.impact || 'Impact analysis not provided')
           .moveDown(0.5);

        // Remediation Steps
        doc.font('Helvetica-Bold')
           .text('Remediation Steps:')
           .font('Helvetica')
           .text(vulnRemediation || 'No remediation steps provided')
           .moveDown(0.5);

        // Additional Notes
        if (vulnDetails) {
          doc.font('Helvetica-Bold')
             .text('Additional Notes:')
             .font('Helvetica')
             .text(vulnDetails)
             .moveDown(0.5);
        }

        // Add request/response if available
        if (vulnRequest) {
          doc.font('Helvetica-Bold')
             .text('Request:')
             .font('Courier')
             .fontSize(10)
             .text(vulnRequest, { 
               width: 500,
               align: 'left'
             })
             .moveDown(0.5);
        }

        if (vulnResponse) {
          doc.font('Helvetica-Bold')
             .fontSize(12)
             .text('Response:')
             .font('Courier')
             .fontSize(10)
             .text(vulnResponse, { 
               width: 500,
               align: 'left'
             })
             .moveDown(0.5);
        }

        // Add remediation if available
        if (vulnRemediation) {
          doc.font('Helvetica-Bold')
             .fontSize(12)
             .text('Remediation:')
             .font('Helvetica')
             .text(vulnRemediation)
             .moveDown(0.5);
        }

        // Add screenshot if available
        const screenshot = await attachScreenshot(vulnerability.id);
        if (screenshot) {
          doc.image(screenshot, {
            fit: [200, 200], // Adjust size as needed
            align: 'center',
            valign: 'center'
          }).moveDown(1);
        }

        doc.moveDown(1);
        doc.strokeColor('#dddddd').lineWidth(1).moveTo(50, doc.y).lineTo(550, doc.y).stroke();
        doc.moveDown(1);
      }

      // Conclusion
      doc.font('Helvetica-Bold')
         .fontSize(18)
         .text('Conclusion and Recommendations', { underline: true })
         .moveDown(1);

      doc.font('Helvetica')
         .fontSize(12)
         .text('This security assessment has identified several vulnerabilities that should be addressed to improve the security posture of the target system. It is recommended to prioritize remediation based on severity level and potential impact.')
         .moveDown(1)
         .text('All findings should be verified in the target environment before implementing fixes to ensure that they are not false positives and that the recommended remediations are appropriate.')
         .moveDown(2);

      // Disclaimer
      doc.font('Helvetica-Bold')
         .fontSize(14)
         .text('Disclaimer', { underline: true })
         .moveDown(0.5);

      doc.font('Helvetica')
         .fontSize(10)
         .text('This report is provided for informational purposes only. The Ethical Penetration Testing Platform makes no warranties about the accuracy or completeness of the findings. All security testing was performed with proper authorization. The platform and its creators are not responsible for any damages resulting from the use of this information or the implementation of any recommendations.')
         .moveDown(0.5);

      // Finalize the PDF
      doc.end();
    } catch (error) {
      console.error('Error generating PDF report:', error);
      reject(error);
    }
  });
}

/**
 * Generate a Word document report for vulnerabilities
 */
export async function generateWordReport(
  vulnerabilities: Vulnerability[] | DirectVulnerabilityReport[],
  targetUrl: string
): Promise<Buffer> {
  console.log(`Starting Word document report generation for ${targetUrl} with ${vulnerabilities.length} vulnerabilities`);
  try {
    console.log('Initializing Document...');
    // Create document
    const doc = new Document({
      title: `Security Scan Report - ${targetUrl}`,
      description: 'Security Vulnerability Report',
      creator: 'Ethical Penetration Testing Platform'
    });

    // Title
    const title = new Paragraph({
      text: 'Security Vulnerability Report',
      heading: HeadingLevel.TITLE,
      alignment: AlignmentType.CENTER
    });

    // Metadata
    const target = new Paragraph({
      text: `Target: ${targetUrl}`,
      alignment: AlignmentType.CENTER
    });

    const date = new Paragraph({
      text: `Date: ${new Date().toLocaleDateString()}`,
      alignment: AlignmentType.CENTER
    });

    const vulnCount = new Paragraph({
      text: `Vulnerabilities Found: ${vulnerabilities.length}`,
      alignment: AlignmentType.CENTER,
      spacing: { after: 400 }
    });

    // Executive Summary
    const summaryTitle = new Paragraph({
      text: 'Executive Summary',
      heading: HeadingLevel.HEADING_1
    });

    const summary = new Paragraph({
      text: 'This report presents the findings of a security assessment conducted on the specified target. The assessment was performed using the Ethical Penetration Testing Platform, which employs automated scanning techniques to identify potential security vulnerabilities.',
      spacing: { after: 200 }
    });

    // Severity distribution
    const severityCounts = {
      critical: 0,
      high: 0,
      medium: 0,
      low: 0,
      info: 0
    };

    vulnerabilities.forEach(vuln => {
      const severity = vuln.severity.toLowerCase();
      if (severity in severityCounts) {
        severityCounts[severity as keyof typeof severityCounts]++;
      }
    });

    const distributionTitle = new Paragraph({
      text: 'Vulnerability Severity Distribution:',
      heading: HeadingLevel.HEADING_2
    });

    const distributionParagraphs = Object.entries(severityCounts)
      .filter(([_, count]) => count > 0)
      .map(([severity, count]) => {
        return new Paragraph({
          text: `${severity.charAt(0).toUpperCase() + severity.slice(1)}: ${count}`
        });
      });

    // Detailed findings
    const findingsTitle = new Paragraph({
      text: 'Detailed Findings',
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400 }
    });

    const findingsSections = vulnerabilities.flatMap((vulnerability, index) => {
      const sections = [];

      const vulnName = getVulnerabilityName(vulnerability);
      const vulnLocation = getVulnerabilityLocation(vulnerability);
      const vulnDetails = getVulnerabilityDetails(vulnerability);
      const vulnRequest = getVulnerabilityRequest(vulnerability);
      const vulnResponse = getVulnerabilityResponse(vulnerability);
      const vulnRemediation = getVulnerabilityRemediation(vulnerability);

      // Vulnerability title
      sections.push(
        new Paragraph({
          text: `${index + 1}. ${vulnName}`,
          heading: HeadingLevel.HEADING_2
        })
      );

      // Severity
      sections.push(
        new Paragraph({
          children: [
            new TextRun({
              text: 'Severity: ',
              bold: true
            }),
            new TextRun(vulnerability.severity)
          ]
        })
      );

      // Description
      sections.push(
        new Paragraph({
          children: [
            new TextRun({
              text: 'Description: ',
              bold: true
            }),
            new TextRun(vulnerability.description)
          ]
        })
      );

      // Location
      sections.push(
        new Paragraph({
          children: [
            new TextRun({
              text: 'Location: ',
              bold: true
            }),
            new TextRun(vulnLocation)
          ]
        })
      );

      // Impact (if available)
      if (vulnerability.impact) {
        sections.push(
          new Paragraph({
            children: [
              new TextRun({
                text: 'Impact: ',
                bold: true
              }),
              new TextRun(vulnerability.impact)
            ]
          })
        );
      }

      // Technical details (if available)
      if (vulnDetails) {
        sections.push(
          new Paragraph({
            children: [
              new TextRun({
                text: 'Technical Details: ',
                bold: true
              }),
              new TextRun(vulnDetails)
            ]
          })
        );
      }

      // Request (if available)
      if (vulnRequest) {
        sections.push(
          new Paragraph({
            children: [
              new TextRun({
                text: 'Request: ',
                bold: true
              })
            ]
          })
        );
        sections.push(
          new Paragraph({
            text: vulnRequest,
            style: 'Code'
          })
        );
      }

      // Response (if available)
      if (vulnResponse) {
        sections.push(
          new Paragraph({
            children: [
              new TextRun({
                text: 'Response: ',
                bold: true
              })
            ]
          })
        );
        sections.push(
          new Paragraph({
            text: vulnResponse,
            style: 'Code'
          })
        );
      }

      // Remediation (if available)
      if (vulnRemediation) {
        sections.push(
          new Paragraph({
            children: [
              new TextRun({
                text: 'Remediation: ',
                bold: true
              }),
              new TextRun(vulnRemediation)
            ]
          })
        );
      }

      // Separator
      sections.push(
        new Paragraph({
          text: '',
          spacing: { after: 200 }
        })
      );

      return sections;
    });

    // Conclusion
    const conclusionTitle = new Paragraph({
      text: 'Conclusion and Recommendations',
      heading: HeadingLevel.HEADING_1
    });

    const conclusion = new Paragraph({
      text: 'This security assessment has identified several vulnerabilities that should be addressed to improve the security posture of the target system. It is recommended to prioritize remediation based on severity level and potential impact.'
    });

    const verification = new Paragraph({
      text: 'All findings should be verified in the target environment before implementing fixes to ensure that they are not false positives and that the recommended remediations are appropriate.',
      spacing: { after: 200 }
    });

    // Disclaimer
    const disclaimerTitle = new Paragraph({
      text: 'Disclaimer',
      heading: HeadingLevel.HEADING_2
    });

    const disclaimer = new Paragraph({
      text: 'This report is provided for informational purposes only. The Ethical Penetration Testing Platform makes no warranties about the accuracy or completeness of the findings. All security testing was performed with proper authorization. The platform and its creators are not responsible for any damages resulting from the use of this information or the implementation of any recommendations.'
    });

    // Add all sections to the document
    doc.addSection({
      children: [
        title,
        target,
        date,
        vulnCount,
        summaryTitle,
        summary,
        distributionTitle,
        ...distributionParagraphs,
        findingsTitle,
        ...findingsSections,
        conclusionTitle,
        conclusion,
        verification,
        disclaimerTitle,
        disclaimer
      ]
    });

    // Generate the document
    const buffer = await Packer.toBuffer(doc);
    return buffer;
  } catch (error) {
    console.error('Error generating Word report:', error);
    throw error;
  }
}

/**
 * Save a report to disk (for testing purposes)
 */
export function saveReportToDisk(buffer: Buffer, filename: string): string {
  try {
    console.log(`Saving report to disk, buffer size: ${buffer.length} bytes`);

    const reportsDir = path.join(process.cwd(), 'reports');
    console.log(`Reports directory path: ${reportsDir}`);

    // Create reports directory if it doesn't exist
    if (!fs.existsSync(reportsDir)) {
      console.log(`Creating reports directory at ${reportsDir}`);
      fs.mkdirSync(reportsDir, { recursive: true });
    }

    const filePath = path.join(reportsDir, filename);
    console.log(`Writing file to: ${filePath}`);
    fs.writeFileSync(filePath, buffer);

    // Verify the file was written
    if (fs.existsSync(filePath)) {
      const stats = fs.statSync(filePath);
      console.log(`File successfully saved: ${filePath}, size: ${stats.size} bytes`);
    } else {
      console.error(`Failed to save file: ${filePath}`);
    }

    return filePath;
  } catch (error) {
    console.error('Error saving report to disk:', error);
    if (error instanceof Error) {
      console.error('Error details:', error.message);
      console.error('Error stack:', error.stack);
    }
    throw error;
  }
}