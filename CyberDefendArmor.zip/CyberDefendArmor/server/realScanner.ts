import axios from 'axios';
import * as cheerio from 'cheerio';
import * as nmap from 'node-nmap';
import { exec } from 'child_process';
import { promisify } from 'util';
import { InsertVulnerability, Vulnerability } from '@shared/schema';
import { storage } from './storage';
import { VulnerabilityType, SeverityLevel, DirectVulnerabilityReport } from '@shared/types';
import { convertToDirectReport, sendDirectReport } from './directReporting';

const execAsync = promisify(exec);

export interface RealScanOptions {
  targetUrl: string;
  scanType: string;
  vulnerabilityTypes: string[] | null;
  scanIntensity: number;
  hasPermission: boolean; // Important for ethical reasons
}

export class RealScanner {
  private targetUrl: string;
  private scanType: string;
  private vulnerabilityTypes: string[];
  private scanIntensity: number;
  private scanId: number;
  private hasPermission: boolean;
  private vulnerabilities: InsertVulnerability[] = [];
  private targetDomain: string;
  private falsePositiveRate: number = 0; // Reduced from default value
  private verificationSteps: number = 3; // Increase verification steps to reduce false positives
  private validVulnerabilities: Map<string, boolean> = new Map(); // Track verified vulnerabilities

  constructor(options: RealScanOptions, scanId: number) {
    this.targetUrl = options.targetUrl;
    this.scanType = options.scanType;
    this.vulnerabilityTypes = options.vulnerabilityTypes || [];
    this.scanIntensity = options.scanIntensity;
    this.scanId = scanId;
    this.hasPermission = options.hasPermission;
    
    // Adjust false positive rate and verification steps based on scan intensity
    // Higher intensity = more thorough verification = fewer false positives
    this.falsePositiveRate = Math.max(0, 0.15 - (this.scanIntensity * 0.03)); 
    this.verificationSteps = Math.min(5, 2 + Math.floor(this.scanIntensity / 2));
    
    // Extract domain for later use
    try {
      this.targetDomain = new URL(this.ensureUrlHasProtocol(this.targetUrl)).hostname;
    } catch (error) {
      // If not a valid URL, use as is (could be a domain name)
      this.targetDomain = this.targetUrl;
    }
  }

  private ensureUrlHasProtocol(url: string): string {
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      return `https://${url}`;
    }
    return url;
  }

  /**
   * Verify a vulnerability is real with multiple confirmation steps
   * This reduces false positives by requiring multiple checks to confirm a vulnerability
   */
  private async captureScreenshot(url: string, vulnId?: number): Promise<Buffer | null> {
    const maxRetries = 3;
    let attempt = 0;
    
    while (attempt < maxRetries) {
      try {
        const puppeteer = require('puppeteer');
        const browser = await puppeteer.launch({ 
          args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'],
          headless: 'new'
        });
        
        const page = await browser.newPage();
        await page.setViewport({ width: 1280, height: 800 });
        await page.goto(url, { waitUntil: 'networkidle0', timeout: 30000 });
        
        // Highlight vulnerability elements if possible
        if (vulnId) {
          await page.evaluate(() => {
            const elements = document.querySelectorAll('input, form, a');
            elements.forEach(el => {
              (el as HTMLElement).style.border = '2px solid red';
            });
          });
        }
        
        const screenshot = await page.screenshot({
          fullPage: true,
          type: 'png',
          encoding: 'binary'
        });
        
        await browser.close();
        console.log(`[Scan] Successfully captured screenshot for ${url}`);
        return screenshot;
      } catch (error) {
        attempt++;
        console.error(`[Scan] Screenshot attempt ${attempt} failed: ${error}`);
        if (attempt === maxRetries) {
          return null;
        }
        // Wait before retrying
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    }
    return null;
  }

  private async verifyVulnerability(type: string, payload: string, location: string): Promise<boolean> {
    // Skip verification for simulated scans in CTF challenges
    if (location.includes('ctf-challenge')) {
      return true;
    }

    console.log(`[Scan ${this.scanId}] Verifying ${type} vulnerability at ${location}`);
    let confirmationCount = 0;
    
    // Run multiple verification tests depending on vulnerability type
    for (let i = 0; i < this.verificationSteps; i++) {
      try {
        // Different verification approach for each attempt
        switch (type) {
          case VulnerabilityType.XSS:
            // Verify XSS with different payloads and detection methods
            const xssPayloads = [
              `"><script>var verified=true;</script>`,
              `'><img src=x onerror=console.log('XSS${i}')>`,
              `javascript:alert('XSS${i}')`,
              `<svg/onload=console.log('XSS${i}')>`
            ];
            
            const xssResponse = await axios.get(`${location}${xssPayloads[i % xssPayloads.length]}`, {
              validateStatus: () => true,
              timeout: 5000
            });
            
            // Check if payload reflection occurs without encoding
            if (xssResponse.data && typeof xssResponse.data === 'string') {
              if (xssResponse.data.includes(xssPayloads[i % xssPayloads.length]) && 
                  !xssResponse.data.includes(`&lt;script`) && 
                  !xssResponse.data.includes(`&quot;`)) {
                confirmationCount++;
              }
            }
            break;
            
          case VulnerabilityType.SQL_INJECTION:
            // Verify SQL injection using timing and error-based techniques
            const sqlPayloads = [
              `' OR SLEEP(1)--`,
              `" OR 1=1--`,
              `' UNION SELECT NULL--`,
              `'; WAITFOR DELAY '0:0:1'--`
            ];
            
            const startTime = Date.now();
            const sqlResponse = await axios.get(`${location}${sqlPayloads[i % sqlPayloads.length]}`, {
              validateStatus: () => true,
              timeout: 10000
            });
            const responseTime = Date.now() - startTime;
            
            // Check for SQL errors or timing differences
            if (sqlResponse.data && typeof sqlResponse.data === 'string') {
              if (sqlResponse.data.includes('SQL syntax') || 
                  sqlResponse.data.includes('ORA-') ||
                  sqlResponse.data.includes('MySQL') ||
                  responseTime > 1000) { // Sleep payload worked
                confirmationCount++;
              }
            }
            break;
            
          // Additional verification methods for other vulnerability types
          default:
            // Generic verification
            const genericResponse = await axios.get(`${location}${payload}`, {
              validateStatus: () => true,
              timeout: 5000
            });
            
            // Consider it verified if we get unusual response or status
            if (genericResponse.status !== 404 && genericResponse.status !== 403) {
              confirmationCount++;
            }
        }
      } catch (error) {
        // Some errors might actually confirm the vulnerability
        // For example, a timeout when testing SQL injection time delays
        console.log(`[Scan ${this.scanId}] Verification attempt ${i+1} error: ${(error as Error).message}`);
      }
    }
    
    // Calculate confirmation percentage
    const confirmationRate = confirmationCount / this.verificationSteps;
    const verified = confirmationRate > 0.5; // Over half of tests confirm it
    
    console.log(`[Scan ${this.scanId}] Vulnerability ${type} verification: ${confirmationCount}/${this.verificationSteps} tests passed. Verified: ${verified}`);
    
    // Store result for future reference
    this.validVulnerabilities.set(`${type}-${location}-${payload}`, verified);
    
    return verified;
  }

  async scan(): Promise<{ success: boolean; message?: string }> {
    try {
      // Ethical check - abort if no permission
      if (!this.hasPermission) {
        throw new Error("No permission to scan this target. Please ensure you have explicit permission.");
      }

      await storage.updateScanStatus(this.scanId, "in_progress");
      
      console.log(`[Scan ${this.scanId}] Starting real security scan of ${this.targetUrl} with intensity ${this.scanIntensity}`);
      console.log(`[Scan ${this.scanId}] False positive reduction: Using ${this.verificationSteps} verification steps with target rate of ${(this.falsePositiveRate * 100).toFixed(1)}%`);
      
      // 1. Verify the URL is reachable
      await this.verifyTargetReachable();
      
      // 2. Perform initial reconnaissance to gather information
      await this.performInitialRecon();
      
      // 3. Create an array of scan promises for parallel execution
      const scanPromises = [];
      const targetWithProtocol = this.ensureUrlHasProtocol(this.targetUrl);
      
      // Add vulnerability checks based on requested types
      if (this.vulnerabilityTypes.includes(VulnerabilityType.XSS)) {
        scanPromises.push(this.checkForXssVulnerabilities(targetWithProtocol));
      }
      
      if (this.vulnerabilityTypes.includes(VulnerabilityType.SQL_INJECTION)) {
        scanPromises.push(this.checkForSqlInjectionVulnerabilities(targetWithProtocol));
      }
      
      if (this.vulnerabilityTypes.includes(VulnerabilityType.DIRECTORY_TRAVERSAL)) {
        scanPromises.push(this.checkForDirectoryTraversal(targetWithProtocol));
      }
      
      if (this.vulnerabilityTypes.includes(VulnerabilityType.CSRF)) {
        scanPromises.push(this.checkForCsrfVulnerabilities(targetWithProtocol));
      }
      
      // Add new vulnerability checks
      if (this.vulnerabilityTypes.includes(VulnerabilityType.AUTH_BYPASS)) {
        scanPromises.push(this.checkForAuthBypass(targetWithProtocol));
      }
      
      if (this.vulnerabilityTypes.includes(VulnerabilityType.OPEN_REDIRECT)) {
        scanPromises.push(this.checkForOpenRedirect(targetWithProtocol));
      }
      
      if (this.vulnerabilityTypes.includes(VulnerabilityType.IDOR)) {
        scanPromises.push(this.checkForIdor(targetWithProtocol));
      }
      
      // For more comprehensive scans, add additional checks
      if (this.scanType === 'comprehensive') {
        // Port scanning for comprehensive scans
        if (this.scanIntensity >= 2) {
          scanPromises.push(this.performPortScan());
        }
        
        // Additional checks for comprehensive scans
        scanPromises.push(this.checkForWeakCrypto(targetWithProtocol));
        scanPromises.push(this.checkForMisconfiguration(targetWithProtocol));
        
        // Look for subdomains if intensity is high enough
        if (this.scanIntensity >= 4) {
          scanPromises.push(this.scanSubdomains());
        }
      }
      
      // Run scans in parallel for efficiency
      await Promise.all(scanPromises);
      
      // For high intensity comprehensive scans, perform deeper testing
      if (this.scanType === 'comprehensive' && this.scanIntensity > 3) {
        // API endpoint discovery and testing
        await this.discoverAndTestApiEndpoints();
        
        // Attempt exploitation of found vulnerabilities (only with explicit permission)
        if (this.hasPermission) {
          await this.attemptExploitation();
        }
      }
      
      // 4. Send vulnerabilities directly to requestor in real-time
      const reportedVulns = [];
      
      for (const vuln of this.vulnerabilities) {
        // Store in platform for tracking purposes only (minimal info)
        const trackedVuln = await storage.createVulnerability({
          ...vuln,
          description: "Vulnerability details sent directly to requestor", // Don't store sensitive details
          stepsToReproduce: "Details sent directly to requestor",
          proofOfConcept: "Details sent directly to requestor"
        });
        
        // Capture and attach screenshot
        const screenshot = await this.captureScreenshot(vuln.location, vuln.id);
        if (screenshot) {
          await storage.saveScreenshot(vuln.id, screenshot);
          console.log(`[Scan ${this.scanId}] Screenshot saved for vulnerability ${vuln.id}`);
        }

        // Convert to direct report format and send to requestor
        const directReport = convertToDirectReport(vuln as Vulnerability, this.targetUrl);
        if (screenshot) {
          directReport.screenshot = screenshot.toString('base64');
          directReport.proofOfConcept += `\n\nVisual proof attached as screenshot.`;
        }
        await sendDirectReport(directReport);
        
        reportedVulns.push(directReport);
        
        // Log that we sent the report directly (but don't log sensitive details)
        console.log(`[Scan ${this.scanId}] Sent direct report for ${vuln.title} to requestor. ReportID: ${directReport.reportId}`);
      }
      
      // 5. Complete the scan
      await storage.updateScanCompletion(this.scanId);
      
      return {
        success: true,
        message: `Scan completed successfully for ${this.targetUrl}. Found ${reportedVulns.length} potential vulnerabilities. All findings sent directly to requestor.`
      };
    } catch (error) {
      console.error(`[Scan ${this.scanId}] Scan failed: ${(error as Error).message}`);
      await storage.updateScanStatus(this.scanId, "failed");
      return {
        success: false,
        message: `Scan failed: ${(error as Error).message}`
      };
    }
  }

  private async verifyTargetReachable(): Promise<void> {
    console.log(`[Scan ${this.scanId}] Verifying target is reachable...`);
    
    try {
      const targetWithProtocol = this.ensureUrlHasProtocol(this.targetUrl);
      const response = await axios.get(targetWithProtocol, { 
        timeout: 5000,
        maxRedirects: 5,
        validateStatus: () => true // Accept any status code
      });
      
      console.log(`[Scan ${this.scanId}] Target is reachable. Status code: ${response.status}`);
      
      // If we get 4xx or 5xx, log but continue (site might be partially functional)
      if (response.status >= 400) {
        console.log(`[Scan ${this.scanId}] Warning: Target returned error status ${response.status}`);
      }
    } catch (error) {
      throw new Error(`Target is unreachable: ${(error as Error).message}`);
    }
  }

  private async performPortScan(): Promise<void> {
    console.log(`[Scan ${this.scanId}] Starting port scan on target...`);
    
    return new Promise((resolve, reject) => {
      try {
        // Define which ports to scan based on intensity
        let portRange = '80,443'; // Default: just check web ports
        
        if (this.scanIntensity >= 3) {
          portRange = '80,443,22,21,25,53';  // Add common service ports
        }
        if (this.scanIntensity >= 4) {
          portRange = '1-1000'; // Scan first 1000 ports
        }
        if (this.scanIntensity >= 5) {
          portRange = '1-65535'; // Full port scan (very aggressive, only use with explicit permission)
        }
        
        // Configure Nmap scan based on scan intensity
        const nmapArgs = [];
        if (this.scanIntensity <= 2) {
          nmapArgs.push('-T2'); // Slower timing for less aggressive scan
        } else if (this.scanIntensity <= 4) {
          nmapArgs.push('-T3'); // Default timing
        } else {
          nmapArgs.push('-T4'); // Faster scan (more aggressive)
        }
        
        // Create the scan
        const scan = new nmap.NmapScan(this.targetDomain, `-p ${portRange} ${nmapArgs.join(' ')}`);
        
        scan.on('complete', (data: any) => {
          console.log(`[Scan ${this.scanId}] Port scan complete.`);
          
          // No hosts found
          if (!data || data.length === 0) {
            console.log(`[Scan ${this.scanId}] No host information was returned from the port scan.`);
            resolve();
            return;
          }
          
          // Get the open ports
          const host = data[0];
          const openPorts: any[] = host.openPorts || [];
          
          if (openPorts.length > 0) {
            console.log(`[Scan ${this.scanId}] Found ${openPorts.length} open ports.`);
            
            // Check for potential vulnerabilities based on open ports
            const unusualPorts = openPorts.filter((port: any) => {
              // Filter for unusual or risky open ports
              const portNumber = parseInt(port.port);
              const service = port.service || '';
              
              // Common secure services on standard ports are not suspicious
              if ((portNumber === 80 && service === 'http') ||
                  (portNumber === 443 && service === 'https') ||
                  (portNumber === 22 && service === 'ssh')) {
                return false;
              }
              
              return true;
            });
            
            // Record vulnerability if unusual ports are found
            if (unusualPorts.length > 0) {
              // List of detected ports
              const portList = unusualPorts.map((p: any) => 
                `${p.port}/${p.service || 'unknown'}`
              ).join(', ');
              
              this.vulnerabilities.push({
                scanId: this.scanId,
                title: "Potentially Risky Open Ports",
                type: VulnerabilityType.MISCONFIGURATION,
                severity: unusualPorts.length > 3 ? SeverityLevel.HIGH : SeverityLevel.MEDIUM,
                location: `${this.targetDomain}`,
                description: `The server has potentially risky ports exposed to the internet. This could increase the attack surface.`,
                stepsToReproduce: `1. Run a port scan: nmap -p- ${this.targetDomain}\n2. Observe the following unusual open ports: ${portList}`,
                impact: "Exposing unnecessary services could allow attackers to gain access to the system through vulnerable services or protocols.",
                remediation: "Close unnecessary ports and implement proper firewall rules. Only expose services that are required for the application to function.",
                proofOfConcept: `nmap -p- ${this.targetDomain}`,
                cvssScore: unusualPorts.length > 3 ? "7.5" : "5.5",
                status: "open"
              });
            }
          }
          
          resolve();
        });
        
        scan.on('error', (error: any) => {
          console.error(`[Scan ${this.scanId}] Port scan error: ${error}`);
          // Don't fail the entire scan if port scanning fails
          resolve();
        });
        
        scan.startScan();
      } catch (error) {
        console.error(`[Scan ${this.scanId}] Error in port scan: ${(error as Error).message}`);
        // Don't fail the entire scan if port scanning fails
        resolve();
      }
    });
  }

  private async checkForXssVulnerabilities(targetUrl: string): Promise<void> {
    console.log(`[Scan ${this.scanId}] Checking for XSS vulnerabilities...`);
    
    try {
      // Get the web page
      const response = await axios.get(targetUrl, { timeout: 10000 });
      const html = response.data;
      const $ = cheerio.load(html);
      
      // Look for input fields
      const forms = $('form');
      const inputFields = $('input');
      
      if (forms.length === 0 && inputFields.length === 0) {
        console.log(`[Scan ${this.scanId}] No forms or input fields found for XSS testing.`);
        return;
      }
      
      console.log(`[Scan ${this.scanId}] Found ${forms.length} forms and ${inputFields.length} input fields for XSS testing.`);
      
      // Check for reflected XSS
      // Note: This is a basic test - in a real scanner, more tests would be performed
      if (inputFields.length > 0) {
        // Check if any query parameters are reflected in the page
        const urlObj = new URL(targetUrl);
        const params = urlObj.searchParams;
        
        if (params.size > 0) {
          let reflected = false;
          
          // Convert iterator to array to avoid TS downlevelIteration issues
          const paramsArray = Array.from(params.entries());
          for (const [key, value] of paramsArray) {
            if (html.includes(value)) {
              reflected = true;
              
              // Record potential reflected XSS vulnerability
              this.vulnerabilities.push({
                scanId: this.scanId,
                title: "Potential Reflected XSS",
                type: VulnerabilityType.XSS,
                severity: SeverityLevel.MEDIUM,
                location: targetUrl,
                description: "URL parameters appear to be reflected in the page response without proper encoding, which could lead to a reflected XSS vulnerability.",
                stepsToReproduce: `1. Navigate to: ${targetUrl}\n2. Observe that the parameter '${key}' with value '${value}' is reflected in the page response.`,
                impact: "If an attacker can craft a URL with malicious scripts and convince a user to click it, the script could execute in the user's browser context.",
                remediation: "Implement proper output encoding for all user-supplied data displayed on the page. Consider implementing a Content Security Policy (CSP).",
                proofOfConcept: `${targetUrl}?${key}=<script>alert('XSS')</script>`,
                cvssScore: "6.1",
                status: "open"
              });
              
              break;
            }
          }
          
          if (!reflected) {
            console.log(`[Scan ${this.scanId}] No reflected parameters found in page content.`);
          }
        }
      }
      
      // More advanced XSS checks would be implemented here in a real scanner
      
    } catch (error) {
      console.error(`[Scan ${this.scanId}] Error in XSS check: ${(error as Error).message}`);
      // Log the error but continue with other checks
    }
  }

  private async checkForSqlInjectionVulnerabilities(targetUrl: string): Promise<void> {
    console.log(`[Scan ${this.scanId}] Checking for SQL Injection vulnerabilities...`);
    
    try {
      // Get the web page
      const response = await axios.get(targetUrl, { timeout: 10000 });
      const html = response.data;
      const $ = cheerio.load(html);
      
      // Look for forms
      const forms = $('form');
      
      if (forms.length === 0) {
        console.log(`[Scan ${this.scanId}] No forms found for SQL injection testing.`);
        return;
      }
      
      console.log(`[Scan ${this.scanId}] Found ${forms.length} forms for SQL injection testing.`);
      
      // Check for forms with input fields that might be vulnerable
      // Note: These are very basic checks - real SQL injection testing requires more sophisticated approaches
      
      let formIndex = 0;
      forms.each((i: number, form: any) => {
        const method = $(form).attr('method')?.toLowerCase() || 'get';
        const action = $(form).attr('action') || '';
        const formUrl = action ? new URL(action, targetUrl).toString() : targetUrl;
        
        const inputFields = $(form).find('input:not([type="submit"]):not([type="button"]):not([type="file"])');
        
        if (inputFields.length > 0) {
          formIndex++;
          console.log(`[Scan ${this.scanId}] Analyzing form #${formIndex} with ${inputFields.length} input fields.`);
          
          // In a real scanner, this would attempt SQL injection payloads
          // For this demo, we'll just flag forms with certain input names as potentially vulnerable
          
          const suspiciousFields = ['username', 'user', 'id', 'email', 'search', 'query'];
          let hasSuspiciousField = false;
          
          inputFields.each((j: number, input: any) => {
            const name = $(input).attr('name') || '';
            const type = $(input).attr('type') || '';
            
            if (suspiciousFields.some(field => name.toLowerCase().includes(field))) {
              hasSuspiciousField = true;
              
              // Record potential SQL injection point
              this.vulnerabilities.push({
                scanId: this.scanId,
                title: "Potential SQL Injection Point",
                type: VulnerabilityType.SQL_INJECTION,
                severity: SeverityLevel.HIGH,
                location: `${formUrl} (${method} form - ${name} field)`,
                description: `The form contains an input field '${name}' that might be vulnerable to SQL injection if not properly sanitized.`,
                stepsToReproduce: `1. Navigate to: ${targetUrl}\n2. Find the form with action '${action}'\n3. Try entering SQL injection payloads like "' OR 1=1 --" in the ${name} field.`,
                impact: "If exploitable, an attacker could potentially extract data from the database, modify database contents, or gain unauthorized access.",
                remediation: "Use parameterized queries or prepared statements. Implement proper input validation and sanitization.",
                proofOfConcept: `Example payload: ' OR '1'='1`,
                cvssScore: "8.0",
                status: "open"
              });
              
              return false; // Break the loop once we find a suspicious field
            }
          });
          
          if (!hasSuspiciousField) {
            console.log(`[Scan ${this.scanId}] No suspicious fields found in form #${formIndex}.`);
          }
        }
      });
      
    } catch (error) {
      console.error(`[Scan ${this.scanId}] Error in SQL injection check: ${(error as Error).message}`);
      // Log the error but continue with other checks
    }
  }

  private async checkForDirectoryTraversal(targetUrl: string): Promise<void> {
    console.log(`[Scan ${this.scanId}] Checking for directory traversal vulnerabilities...`);
    
    try {
      // Parse the URL to find potential parameters
      const urlObj = new URL(targetUrl);
      const params = urlObj.searchParams;
      
      // Look for parameters that might be file paths
      const fileParamNames = ['file', 'path', 'document', 'page', 'img', 'image', 'download', 'dir'];
      let hasFileParam = false;
      
      // Convert iterator to array to avoid TS downlevelIteration issues
      const paramsArray = Array.from(params.entries());
      for (const [key, value] of paramsArray) {
        if (fileParamNames.some(param => key.toLowerCase().includes(param))) {
          hasFileParam = true;
          
          console.log(`[Scan ${this.scanId}] Found a potential file parameter: ${key}=${value}`);
          
          // In a real scanner, we would test this parameter with directory traversal payloads
          // For this demo, we'll flag it as potentially vulnerable
          
          this.vulnerabilities.push({
            scanId: this.scanId,
            title: "Potential Directory Traversal",
            type: VulnerabilityType.DIRECTORY_TRAVERSAL,
            severity: SeverityLevel.HIGH,
            location: targetUrl,
            description: `The URL contains a parameter '${key}' that might be vulnerable to directory traversal attacks.`,
            stepsToReproduce: `1. Navigate to: ${targetUrl}\n2. Modify the '${key}' parameter to a path traversal sequence like '../../../etc/passwd'`,
            impact: "If exploitable, an attacker could potentially read sensitive files on the server, including configuration files and credentials.",
            remediation: "Validate file paths, use a whitelist of allowed files, and avoid using user input to directly build file paths.",
            proofOfConcept: `${urlObj.origin}${urlObj.pathname}?${key}=../../../etc/passwd`,
            cvssScore: "7.5",
            status: "open"
          });
        }
      }
      
      if (!hasFileParam) {
        // If no file parameters found in URL, look for common endpoints
        const commonEndpoints = ['/download', '/file', '/view', '/docs', '/pdf', '/export', '/images'];
        
        for (const endpoint of commonEndpoints) {
          const endpointUrl = new URL(endpoint, targetUrl).toString();
          
          try {
            // We don't actually try exploits, just check if the endpoint exists
            const response = await axios.get(endpointUrl, { 
              timeout: 5000,
              validateStatus: () => true // Accept any status code
            });
            
            // If the endpoint exists (not 404), flag it for further investigation
            if (response.status !== 404) {
              console.log(`[Scan ${this.scanId}] Found a potential file handling endpoint: ${endpointUrl}`);
              
              this.vulnerabilities.push({
                scanId: this.scanId,
                title: "Potential File Handling Endpoint",
                type: VulnerabilityType.DIRECTORY_TRAVERSAL,
                severity: SeverityLevel.MEDIUM,
                location: endpointUrl,
                description: `The website has a file handling endpoint that might be vulnerable to directory traversal if not properly secured.`,
                stepsToReproduce: `1. Navigate to: ${endpointUrl}\n2. Try appending file path parameters like '?file=../../../etc/passwd'`,
                impact: "If exploitable, an attacker might access sensitive files on the server.",
                remediation: "Implement proper path validation and restrict access to only intended files.",
                proofOfConcept: `${endpointUrl}?file=../../../etc/passwd`,
                cvssScore: "5.5",
                status: "open"
              });
              
              break; // Just find one endpoint to avoid too many requests
            }
          } catch (error) {
            // Endpoint doesn't exist or error occurred, continue to next
            continue;
          }
        }
      }
      
    } catch (error) {
      console.error(`[Scan ${this.scanId}] Error in directory traversal check: ${(error as Error).message}`);
      // Log the error but continue with other checks
    }
  }

  private async performInitialRecon(): Promise<void> {
    console.log(`[Scan ${this.scanId}] Performing initial reconnaissance on ${this.targetDomain}`);
    
    try {
      // Gather HTTP headers to detect server info
      const response = await axios.get(this.ensureUrlHasProtocol(this.targetUrl), { 
        timeout: 10000,
        validateStatus: () => true,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
      });
      
      const headers = response.headers;
      
      // Check for sensitive headers that might reveal server information
      const serverHeader = headers['server'];
      if (serverHeader) {
        console.log(`[Scan ${this.scanId}] Server header detected: ${serverHeader}`);
        
        this.vulnerabilities.push({
          scanId: this.scanId,
          title: "Information Disclosure - Server Header",
          type: VulnerabilityType.MISCONFIGURATION,
          severity: SeverityLevel.LOW,
          location: this.targetUrl,
          description: `The server is revealing its software/version information: ${serverHeader}`,
          stepsToReproduce: `1. Send a request to ${this.targetUrl}\n2. Observe the 'Server' header in the response`,
          impact: "An attacker can use this information to find specific vulnerabilities in the server software version.",
          remediation: "Configure the web server to suppress or modify the Server header.",
          proofOfConcept: `curl -I ${this.targetUrl}`,
          cvssScore: "2.5",
          status: "open"
        });
      }
      
      // Extract all links for reconnaissance
      const html = response.data;
      const $ = cheerio.load(html);
      const links = new Set<string>();
      
      $('a').each((i: number, el: any) => {
        const href = $(el).attr('href');
        if (href && !href.startsWith('#') && !href.startsWith('javascript:')) {
          try {
            // Normalize the link
            const fullUrl = new URL(href, this.targetUrl).toString();
            // Only include links from the same domain
            if (new URL(fullUrl).hostname === this.targetDomain) {
              links.add(fullUrl);
            }
          } catch (e) {
            // Invalid URL, ignore
          }
        }
      });
      
      console.log(`[Scan ${this.scanId}] Found ${links.size} links on the target site for scanning`);
      
      // Detect technologies used by the website
      this.detectWebsiteTechnologies($, headers);
      
    } catch (error) {
      console.error(`[Scan ${this.scanId}] Error during reconnaissance:`, error);
      // Log the error but continue with the scan
    }
  }
  
  private detectWebsiteTechnologies($: any, headers: any): string[] {
    const technologies: string[] = [];
    
    // Check for common frameworks and libraries in the HTML
    if ($('script[src*="jquery"]').length) technologies.push('jQuery');
    if ($('script[src*="bootstrap"]').length) technologies.push('Bootstrap');
    if ($('script[src*="react"]').length) technologies.push('React');
    if ($('script[src*="angular"]').length) technologies.push('Angular');
    if ($('script[src*="vue"]').length) technologies.push('Vue.js');
    
    // Check for CMS signatures
    if ($('meta[name="generator"][content*="WordPress"]').length) technologies.push('WordPress');
    if ($('meta[name="generator"][content*="Drupal"]').length) technologies.push('Drupal');
    if ($('meta[name="generator"][content*="Joomla"]').length) technologies.push('Joomla');
    
    // Check headers for server technologies
    if (headers['x-powered-by']) technologies.push(headers['x-powered-by']);
    
    if (technologies.length > 0) {
      console.log(`[Scan ${this.scanId}] Detected technologies: ${technologies.join(', ')}`);
    }
    
    return technologies;
  }

  private async checkForCsrfVulnerabilities(targetUrl: string): Promise<void> {
    console.log(`[Scan ${this.scanId}] Checking for CSRF vulnerabilities...`);
    
    try {
      // Get the web page
      const response = await axios.get(targetUrl, { timeout: 10000 });
      const html = response.data;
      const $ = cheerio.load(html);
      
      // Look for forms
      const forms = $('form');
      
      if (forms.length === 0) {
        console.log(`[Scan ${this.scanId}] No forms found for CSRF testing.`);
        return;
      }
      
      console.log(`[Scan ${this.scanId}] Found ${forms.length} forms for CSRF testing.`);
      
      // Check each form for CSRF tokens
      forms.each((i: number, form: any) => {
        const method = $(form).attr('method')?.toLowerCase() || 'get';
        
        // Only check state-changing methods (POST, PUT, DELETE)
        if (method === 'post' || method === 'put' || method === 'delete') {
          const action = $(form).attr('action') || '';
          const formUrl = action ? new URL(action, targetUrl).toString() : targetUrl;
          
          // Look for CSRF tokens in various formats
          const csrfInputs = $(form).find('input[name*=csrf], input[name*=token], input[name*=xsrf], input[name*=nonce]');
          
          if (csrfInputs.length === 0) {
            console.log(`[Scan ${this.scanId}] State-changing form found without CSRF token: ${formUrl}`);
            
            // Generate a proof of concept CSRF exploit for the vulnerable form
            const csrfPoC = this.generateCsrfExploit($, form, formUrl);
            
            // Record CSRF vulnerability
            this.vulnerabilities.push({
              scanId: this.scanId,
              title: "Potential CSRF Vulnerability",
              type: VulnerabilityType.CSRF,
              severity: SeverityLevel.MEDIUM,
              location: formUrl,
              description: "The form uses POST method but doesn't appear to have CSRF protection.",
              stepsToReproduce: `1. Navigate to: ${targetUrl}\n2. Observe that the form with action '${action}' does not contain a CSRF token.`,
              impact: "An attacker could create a malicious page that submits this form on behalf of a victim, potentially performing actions without the user's consent.",
              remediation: "Implement anti-CSRF tokens in all forms. Validate the origin and referrer headers. Consider using the SameSite cookie attribute.",
              proofOfConcept: `
<html>
  <body onload="document.forms[0].submit()">
    <form action="${formUrl}" method="POST">
      <!-- Form fields would be pre-filled here -->
      <input type="submit" value="Submit">
    </form>
  </body>
</html>`,
              cvssScore: "6.5",
              status: "open"
            });
          }
        }
      });
      
      // Also check for SameSite cookie attributes
      await this.checkCookieSecurity();
      
    } catch (error) {
      console.error(`[Scan ${this.scanId}] Error in CSRF check: ${(error as Error).message}`);
      // Log the error but continue with other checks
    }
  }
  
  private generateCsrfExploit($: any, form: any, formUrl: string): string {
    let exploitHtml = `<html>\n<body onload="document.forms[0].submit()">\n<form action="${formUrl}" method="POST">\n`;
    
    // Add all the form fields to the exploit
    $(form).find('input').each((i: number, input: any) => {
      const name = $(input).attr('name');
      const type = $(input).attr('type');
      const value = $(input).attr('value') || '';
      
      if (name && type !== 'submit' && type !== 'button') {
        exploitHtml += `  <input type="hidden" name="${name}" value="${value}">\n`;
      }
    });
    
    // Add a submit button
    exploitHtml += '  <input type="submit" value="Submit">\n</form>\n</body>\n</html>';
    
    return exploitHtml;
  }
  
  private async checkCookieSecurity(): Promise<void> {
    try {
      // Make a request to the target and check the cookies
      const response = await axios.get(this.ensureUrlHasProtocol(this.targetUrl), { 
        timeout: 10000,
        withCredentials: true,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
      });
      
      // Check if Set-Cookie headers are present
      const setCookieHeaders = response.headers['set-cookie'] || [];
      
      if (setCookieHeaders.length > 0) {
        console.log(`[Scan ${this.scanId}] Found ${setCookieHeaders.length} cookies to examine`);
        
        // Check each cookie for security attributes
        for (const cookieHeader of setCookieHeaders) {
          // Check for SameSite attribute
          if (!cookieHeader.includes('SameSite=')) {
            console.log(`[Scan ${this.scanId}] Cookie found without SameSite attribute: ${cookieHeader}`);
            
            this.vulnerabilities.push({
              scanId: this.scanId,
              title: "Cookie Missing SameSite Attribute",
              type: VulnerabilityType.CSRF,
              severity: SeverityLevel.LOW,
              location: this.targetUrl,
              description: "A cookie is set without the SameSite attribute, which can make the application vulnerable to CSRF attacks.",
              stepsToReproduce: `1. Navigate to: ${this.targetUrl}\n2. Examine the Set-Cookie headers\n3. Notice that cookies are missing the SameSite attribute`,
              impact: "Cookies without the SameSite attribute can be included in cross-site requests, facilitating CSRF attacks.",
              remediation: "Set SameSite=Lax or SameSite=Strict for all cookies to prevent them from being sent in cross-origin requests.",
              proofOfConcept: `Set-Cookie header: ${cookieHeader}`,
              cvssScore: "3.5",
              status: "open"
            });
          }
          
          // Check for Secure flag
          if (!cookieHeader.includes('Secure') && this.targetUrl.startsWith('https://')) {
            console.log(`[Scan ${this.scanId}] Cookie on HTTPS site missing Secure flag: ${cookieHeader}`);
            
            this.vulnerabilities.push({
              scanId: this.scanId,
              title: "Cookie Missing Secure Flag",
              type: VulnerabilityType.MISCONFIGURATION,
              severity: SeverityLevel.LOW,
              location: this.targetUrl,
              description: "A cookie is set without the Secure flag, which means it can be transmitted over unencrypted HTTP connections.",
              stepsToReproduce: `1. Navigate to: ${this.targetUrl}\n2. Examine the Set-Cookie headers\n3. Notice that cookies are missing the Secure flag`,
              impact: "Cookies without the Secure flag can be transmitted over unencrypted connections, potentially exposing sensitive information.",
              remediation: "Set the Secure flag for all cookies on HTTPS sites to ensure they are only sent over encrypted connections.",
              proofOfConcept: `Set-Cookie header: ${cookieHeader}`,
              cvssScore: "3.0",
              status: "open"
            });
          }
        }
      }
    } catch (error) {
      console.error(`[Scan ${this.scanId}] Error checking cookie security:`, error);
      // Continue with other checks
    }
  }
  
  private async checkForAuthBypass(targetUrl: string): Promise<void> {
    console.log(`[Scan ${this.scanId}] Checking for authentication bypass vulnerabilities...`);
    
    try {
      // Look for login forms
      const response = await axios.get(targetUrl, { timeout: 10000 });
      const html = response.data;
      const $ = cheerio.load(html);
      
      // Find potential login forms
      const loginForms = $('form').filter((i: number, form: any) => {
        const formHtml = $(form).html();
        if (!formHtml) return false;
        
        const lowerHtml = formHtml.toLowerCase();
        return lowerHtml.includes('login') || 
               lowerHtml.includes('password') || 
               lowerHtml.includes('username') || 
               lowerHtml.includes('signin') || 
               lowerHtml.includes('sign in');
      });
      
      if (loginForms.length > 0) {
        console.log(`[Scan ${this.scanId}] Found ${loginForms.length} potential login forms`);
        
        loginForms.each((i: number, form: any) => {
          const action = $(form).attr('action') || '';
          const method = $(form).attr('method')?.toLowerCase() || 'post';
          const formUrl = action ? new URL(action, targetUrl).toString() : targetUrl;
          
          // Check for potential username enumeration
          const usernameField = $(form).find('input[name*=user], input[name*=email], input[name*=login]');
          if (usernameField.length > 0) {
            this.vulnerabilities.push({
              scanId: this.scanId,
              title: "Potential Username Enumeration",
              type: VulnerabilityType.AUTH_BYPASS,
              severity: SeverityLevel.MEDIUM,
              location: formUrl,
              description: "The login form may allow attackers to enumerate valid usernames through different error messages or response times.",
              stepsToReproduce: `1. Navigate to the login form at ${formUrl}\n2. Try different usernames and observe the error messages and response times`,
              impact: "Attackers can identify valid usernames, which facilitates brute force attacks and social engineering.",
              remediation: "Provide generic error messages that don't indicate whether the username or password was incorrect. Implement rate limiting and account lockout policies.",
              proofOfConcept: "Try submitting non-existent usernames vs. existing usernames and compare the responses",
              cvssScore: "5.0",
              status: "open"
            });
          }
          
          // Check for security anti-patterns in the form
          if (method === 'get') {
            this.vulnerabilities.push({
              scanId: this.scanId,
              title: "Login Form Uses GET Method",
              type: VulnerabilityType.AUTH_BYPASS,
              severity: SeverityLevel.LOW,
              location: formUrl,
              description: "The login form uses the GET method, which may expose credentials in browser history, server logs, and Referer headers.",
              stepsToReproduce: `1. Navigate to the login form at ${formUrl}\n2. Observe that the form uses method="get"`,
              impact: "Sensitive authentication credentials could be exposed in URLs, leading to potential credential theft.",
              remediation: "Change the form method from GET to POST for any forms that handle sensitive data, especially login forms.",
              proofOfConcept: `<form method="get" action="${action}">...</form>`,
              cvssScore: "3.5",
              status: "open"
            });
          }
        });
      }
      
      // Check for potential sensitive directories
      const sensitiveEndpoints = [
        '/admin', '/administrator', '/wp-admin', '/dashboard', '/cp', '/control', 
        '/panel', '/login', '/user', '/account', '/console', '/backend', '/manage'
      ];
      
      for (const endpoint of sensitiveEndpoints) {
        try {
          const endpointUrl = new URL(endpoint, targetUrl).toString();
          
          // Check if the endpoint exists
          const response = await axios.get(endpointUrl, { 
            timeout: 5000,
            validateStatus: () => true,
            maxRedirects: 0 // Don't follow redirects to properly detect auth pages
          });
          
          // If we get a 200 OK without authentication, or a 302 redirect to login page
          if (response.status === 200 || response.status === 302) {
            console.log(`[Scan ${this.scanId}] Found sensitive endpoint: ${endpointUrl} (${response.status})`);
            
            // Check if there's a login form or authentication mechanism
            let requiresAuth = false;
            
            if (response.status === 302) {
              const location = response.headers.location;
              if (location && (location.includes('login') || location.includes('signin') || location.includes('auth'))) {
                requiresAuth = true;
              }
            } else if (response.data && typeof response.data === 'string') {
              const pageHtml = response.data.toLowerCase();
              if (pageHtml.includes('login') || pageHtml.includes('password') || pageHtml.includes('signin')) {
                requiresAuth = true;
              }
            }
            
            if (!requiresAuth && response.status === 200) {
              this.vulnerabilities.push({
                scanId: this.scanId,
                title: "Potential Sensitive Endpoint Without Authentication",
                type: VulnerabilityType.AUTH_BYPASS,
                severity: SeverityLevel.HIGH,
                location: endpointUrl,
                description: `The endpoint ${endpoint} appears to be accessible without authentication.`,
                stepsToReproduce: `1. Navigate directly to ${endpointUrl}\n2. Observe that the page loads without requiring authentication`,
                impact: "Attackers can access sensitive functionality or data without authentication.",
                remediation: "Implement proper access controls. Require authentication for all sensitive endpoints, and implement authorization checks.",
                proofOfConcept: `GET ${endpointUrl}`,
                cvssScore: "7.0",
                status: "open"
              });
            }
          }
        } catch (error) {
          // Endpoint doesn't exist or error occurred, continue to next
          continue;
        }
      }
      
    } catch (error) {
      console.error(`[Scan ${this.scanId}] Error in auth bypass check:`, error);
      // Continue with other checks
    }
  }
  
  private async checkForOpenRedirect(targetUrl: string): Promise<void> {
    console.log(`[Scan ${this.scanId}] Checking for open redirect vulnerabilities...`);
    
    try {
      const urlObj = new URL(targetUrl);
      const params = urlObj.searchParams;
      
      // Redirect parameter patterns to check
      const redirectParams = ['redirect', 'url', 'next', 'return', 'returnTo', 'returnUrl', 'go', 'goto', 'link', 'to', 'out', 'view', 'path', 'dest', 'destination', 'redir', 'redirect_uri', 'redirect_url', 'redirect_to', 'location'];
      
      // Check if the URL has potential redirect parameters
      for (const [param, value] of Array.from(params.entries())) {
        if (redirectParams.some(p => param.toLowerCase().includes(p))) {
          console.log(`[Scan ${this.scanId}] Found potential redirect parameter: ${param}`);
          
          this.vulnerabilities.push({
            scanId: this.scanId,
            title: "Potential Open Redirect",
            type: VulnerabilityType.OPEN_REDIRECT,
            severity: SeverityLevel.MEDIUM,
            location: targetUrl,
            description: `The URL contains a parameter '${param}' that might be vulnerable to open redirect attacks.`,
            stepsToReproduce: `1. Navigate to: ${targetUrl}\n2. Modify the '${param}' parameter to an external URL like 'https://evil.com'`,
            impact: "Attackers can craft links that appear to lead to your site but redirect users to malicious sites. This can be used for phishing attacks.",
            remediation: "Implement proper validation of redirect URLs. Only allow relative URLs or maintain a whitelist of allowed domains.",
            proofOfConcept: `${urlObj.origin}${urlObj.pathname}?${param}=https://evil.com`,
            cvssScore: "5.5",
            status: "open"
          });
        }
      }
      
      // Check for redirect endpoints
      const redirectEndpoints = ['/redirect', '/out', '/link', '/goto', '/exit'];
      
      for (const endpoint of redirectEndpoints) {
        try {
          const endpointUrl = new URL(endpoint, targetUrl).toString();
          
          // Check if the endpoint exists
          const response = await axios.get(`${endpointUrl}?url=https://example.com`, { 
            timeout: 5000,
            validateStatus: () => true,
            maxRedirects: 0 // Don't follow redirects to properly detect them
          });
          
          // If we get a redirect status code
          if (response.status >= 300 && response.status < 400) {
            console.log(`[Scan ${this.scanId}] Found redirect endpoint: ${endpointUrl}`);
            
            this.vulnerabilities.push({
              scanId: this.scanId,
              title: "Potential Open Redirect Endpoint",
              type: VulnerabilityType.OPEN_REDIRECT,
              severity: SeverityLevel.MEDIUM,
              location: endpointUrl,
              description: `The website has a redirect endpoint that might be vulnerable to open redirect attacks.`,
              stepsToReproduce: `1. Navigate to: ${endpointUrl}?url=https://evil.com\n2. Observe if the browser redirects to the external URL`,
              impact: "Attackers can use the website to redirect users to malicious sites, potentially adding credibility to phishing attacks.",
              remediation: "Implement proper validation of redirect URLs. Use a whitelist approach for allowed destinations.",
              proofOfConcept: `${endpointUrl}?url=https://evil.com`,
              cvssScore: "5.5",
              status: "open"
            });
          }
        } catch (error) {
          // Endpoint doesn't exist or error occurred, continue to next
          continue;
        }
      }
      
    } catch (error) {
      console.error(`[Scan ${this.scanId}] Error in open redirect check:`, error);
      // Continue with other checks
    }
  }
  
  private async checkForIdor(targetUrl: string): Promise<void> {
    console.log(`[Scan ${this.scanId}] Checking for Insecure Direct Object Reference (IDOR) vulnerabilities...`);
    
    try {
      const urlObj = new URL(targetUrl);
      const params = urlObj.searchParams;
      
      // IDOR parameter patterns to check
      const idorParams = ['id', 'user', 'account', 'document', 'file', 'invoice', 'order', 'profile', 'resource', 'record'];
      
      // Check if the URL has potential IDOR parameters
      for (const [param, value] of Array.from(params.entries())) {
        if (idorParams.some(p => param.toLowerCase().includes(p))) {
          console.log(`[Scan ${this.scanId}] Found potential IDOR parameter: ${param}=${value}`);
          
          // Check if the value is numeric (common for IDs)
          const isNumeric = /^\d+$/.test(value);
          
          if (isNumeric) {
            this.vulnerabilities.push({
              scanId: this.scanId,
              title: "Potential IDOR Vulnerability",
              type: VulnerabilityType.IDOR,
              severity: SeverityLevel.HIGH,
              location: targetUrl,
              description: `The URL contains a parameter '${param}' with a numeric ID that might be vulnerable to IDOR attacks.`,
              stepsToReproduce: `1. Navigate to: ${targetUrl}\n2. Change the value of '${param}' to a different number (e.g., ${parseInt(value) + 1})\n3. Check if you can access another user's data`,
              impact: "If exploitable, attackers could access or modify unauthorized data belonging to other users.",
              remediation: "Implement proper authorization checks for all object references. Validate that the user has permission to access the requested object.",
              proofOfConcept: `${urlObj.origin}${urlObj.pathname}?${param}=${parseInt(value) + 1}`,
              cvssScore: "7.0",
              status: "open"
            });
          }
        }
      }
      
      // Check path-based IDOR
      const pathParts = urlObj.pathname.split('/').filter(part => part);
      for (let i = 0; i < pathParts.length; i++) {
        const part = pathParts[i];
        
        // Check if the path part looks like an ID (numeric or UUID-like)
        if (/^\d+$/.test(part) || /^[a-f0-9-]{36}$/.test(part)) {
          console.log(`[Scan ${this.scanId}] Found potential IDOR in URL path: ${part}`);
          
          this.vulnerabilities.push({
            scanId: this.scanId,
            title: "Potential Path-Based IDOR",
            type: VulnerabilityType.IDOR,
            severity: SeverityLevel.HIGH,
            location: targetUrl,
            description: `The URL path contains what appears to be an ID (${part}) that might be vulnerable to IDOR attacks.`,
            stepsToReproduce: `1. Navigate to: ${targetUrl}\n2. Change the ID in the path to a different value\n3. Check if you can access another user's data`,
            impact: "If exploitable, attackers could access or modify unauthorized data by changing object references in the URL path.",
            remediation: "Implement authorization checks for all endpoints that accept object identifiers. Validate that the current user has permission to access the requested object.",
            proofOfConcept: `If the URL is ${targetUrl}, try accessing a different ID by changing the path component`,
            cvssScore: "7.0",
            status: "open"
          });
        }
      }
      
    } catch (error) {
      console.error(`[Scan ${this.scanId}] Error in IDOR check:`, error);
      // Continue with other checks
    }
  }
  
  private async checkForWeakCrypto(targetUrl: string): Promise<void> {
    console.log(`[Scan ${this.scanId}] Checking for weak cryptography...`);
    
    try {
      // Check for SSL/TLS configuration issues
      if (targetUrl.startsWith('https://')) {
        // In a real scan, we would use tools like sslscan or sslyze
        // For this example, we'll just check the server headers
        
        const response = await axios.get(targetUrl, { 
          timeout: 10000,
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
          }
        });
        
        // Check for HSTS header
        if (!response.headers['strict-transport-security']) {
          this.vulnerabilities.push({
            scanId: this.scanId,
            title: "Missing HTTP Strict Transport Security (HSTS)",
            type: VulnerabilityType.WEAK_CRYPTO,
            severity: SeverityLevel.LOW,
            location: targetUrl,
            description: "The server does not implement HTTP Strict Transport Security (HSTS), which helps protect against protocol downgrade attacks and cookie hijacking.",
            stepsToReproduce: `1. Send a request to ${targetUrl}\n2. Check the response headers for Strict-Transport-Security`,
            impact: "Without HSTS, the site may be vulnerable to SSL stripping attacks that downgrade HTTPS connections to HTTP.",
            remediation: "Implement HSTS by adding the Strict-Transport-Security header with a long max-age value.",
            proofOfConcept: `curl -I ${targetUrl}`,
            cvssScore: "4.0",
            status: "open"
          });
        }
        
        // Check for insecure security headers
        if (!response.headers['content-security-policy']) {
          this.vulnerabilities.push({
            scanId: this.scanId,
            title: "Missing Content Security Policy (CSP)",
            type: VulnerabilityType.WEAK_CRYPTO,
            severity: SeverityLevel.LOW,
            location: targetUrl,
            description: "The server does not implement a Content Security Policy (CSP), which helps protect against Cross-Site Scripting (XSS) and data injection attacks.",
            stepsToReproduce: `1. Send a request to ${targetUrl}\n2. Check the response headers for Content-Security-Policy`,
            impact: "Without CSP, the site is more vulnerable to content injection attacks like XSS.",
            remediation: "Implement a Content Security Policy by adding the Content-Security-Policy header with appropriate directives.",
            proofOfConcept: `curl -I ${targetUrl}`,
            cvssScore: "3.5",
            status: "open"
          });
        }
      } else {
        // Plain HTTP connection
        this.vulnerabilities.push({
          scanId: this.scanId,
          title: "Unencrypted HTTP Connection",
          type: VulnerabilityType.WEAK_CRYPTO,
          severity: SeverityLevel.MEDIUM,
          location: targetUrl,
          description: "The website is using unencrypted HTTP instead of HTTPS.",
          stepsToReproduce: `1. Navigate to ${targetUrl}\n2. Observe that the connection is not encrypted (HTTP instead of HTTPS)`,
          impact: "Unencrypted connections expose all transmitted data to eavesdropping. Anyone on the network path can intercept and view sensitive information.",
          remediation: "Implement HTTPS across the entire site. Obtain an SSL/TLS certificate and configure the web server to use HTTPS. Redirect all HTTP traffic to HTTPS.",
          proofOfConcept: `curl -I ${targetUrl}`,
          cvssScore: "5.0",
          status: "open"
        });
      }
      
    } catch (error) {
      console.error(`[Scan ${this.scanId}] Error in weak crypto check:`, error);
      // Continue with other checks
    }
  }
  
  private async checkForMisconfiguration(targetUrl: string): Promise<void> {
    console.log(`[Scan ${this.scanId}] Checking for server misconfigurations...`);
    
    try {
      // Check for common sensitive files and directories
      const sensitivePaths = [
        '/.git/',
        '/.env',
        '/config.php',
        '/config.js',
        '/wp-config.php',
        '/phpinfo.php',
        '/backup/',
        '/db.sql',
        '/dump.sql',
        '/database.sql',
        '/.DS_Store',
        '/robots.txt',
        '/server-status',
        '/.htaccess',
        '/sitemap.xml',
        '/crossdomain.xml'
      ];
      
      for (const path of sensitivePaths) {
        try {
          const checkUrl = new URL(path, targetUrl).toString();
          
          const response = await axios.get(checkUrl, { 
            timeout: 5000,
            validateStatus: () => true
          });
          
          // If the file exists and returns a 200 OK status
          if (response.status === 200) {
            console.log(`[Scan ${this.scanId}] Found sensitive file: ${checkUrl}`);
            
            this.vulnerabilities.push({
              scanId: this.scanId,
              title: `Sensitive File Exposed: ${path}`,
              type: VulnerabilityType.MISCONFIGURATION,
              severity: SeverityLevel.MEDIUM,
              location: checkUrl,
              description: `A potentially sensitive file or directory (${path}) is publicly accessible.`,
              stepsToReproduce: `1. Navigate to: ${checkUrl}\n2. Observe that the file/directory is accessible`,
              impact: "Sensitive files may contain configuration data, credentials, or reveal information about the server structure that could aid attackers.",
              remediation: `Restrict access to the ${path} file/directory or remove it entirely if not needed.`,
              proofOfConcept: `curl -I ${checkUrl}`,
              cvssScore: "5.5",
              status: "open"
            });
          }
        } catch (error) {
          // File doesn't exist or error occurred, continue to next
          continue;
        }
      }
      
      // Check for directory listing
      const directoryPaths = ['/images/', '/uploads/', '/includes/', '/assets/', '/js/', '/css/', '/backup/'];
      
      for (const path of directoryPaths) {
        try {
          const dirUrl = new URL(path, targetUrl).toString();
          
          const response = await axios.get(dirUrl, { 
            timeout: 5000,
            validateStatus: () => true
          });
          
          // Check for directory listing signatures in the response
          const dirListingSignatures = [
            'Index of /',
            'Directory Listing For',
            '<title>Index of',
            '<h1>Index of',
            'Parent Directory</a>'
          ];
          
          if (response.status === 200 && typeof response.data === 'string') {
            for (const signature of dirListingSignatures) {
              if (response.data.includes(signature)) {
                console.log(`[Scan ${this.scanId}] Found directory listing: ${dirUrl}`);
                
                this.vulnerabilities.push({
                  scanId: this.scanId,
                  title: "Directory Listing Enabled",
                  type: VulnerabilityType.MISCONFIGURATION,
                  severity: SeverityLevel.MEDIUM,
                  location: dirUrl,
                  description: `Directory listing is enabled on the server, revealing the contents of the ${path} directory.`,
                  stepsToReproduce: `1. Navigate to: ${dirUrl}\n2. Observe that the directory contents are listed`,
                  impact: "Directory listing can expose sensitive files, backup files, and reveal the site structure to attackers.",
                  remediation: "Disable directory listing in the web server configuration. For Apache, use 'Options -Indexes'. For Nginx, remove 'autoindex on'.",
                  proofOfConcept: `Browser screenshot of directory listing at ${dirUrl}`,
                  cvssScore: "5.0",
                  status: "open"
                });
                
                break; // No need to check other signatures
              }
            }
          }
        } catch (error) {
          // Directory doesn't exist or error occurred, continue to next
          continue;
        }
      }
      
    } catch (error) {
      console.error(`[Scan ${this.scanId}] Error in misconfiguration check:`, error);
      // Continue with other checks
    }
  }
  
  private async scanSubdomains(): Promise<void> {
    console.log(`[Scan ${this.scanId}] Scanning for subdomains of ${this.targetDomain}...`);
    
    try {
      // Common subdomain prefixes to check
      const commonSubdomains = [
        'www', 'mail', 'ftp', 'webmail', 'admin', 'support', 'dev', 'test',
        'staging', 'api', 'shop', 'blog', 'portal', 'secure', 'cdn', 'app',
        'beta', 'demo', 'm', 'mobile', 'vpn', 'dns'
      ];
      
      // For demonstration purposes, we'll just check a few common subdomains
      // In a real implementation, this would use more advanced techniques
      
      const baseDomain = this.targetDomain.replace(/^www\./, '');
      const promises = [];
      
      for (const sub of commonSubdomains) {
        const subdomain = `${sub}.${baseDomain}`;
        
        // Skip the current domain
        if (subdomain === this.targetDomain) continue;
        
        promises.push(this.checkSubdomain(subdomain));
        
        // Limit concurrency to avoid overwhelming the target
        if (promises.length >= 5) {
          await Promise.all(promises);
          promises.length = 0;
        }
      }
      
      // Process any remaining promises
      if (promises.length > 0) {
        await Promise.all(promises);
      }
      
    } catch (error) {
      console.error(`[Scan ${this.scanId}] Error in subdomain scanning:`, error);
      // Continue with other checks
    }
  }
  
  private async checkSubdomain(subdomain: string): Promise<void> {
    try {
      // Check if the subdomain resolves
      const url = `https://${subdomain}`;
      
      // Try to connect to the subdomain
      const response = await axios.get(url, {
        timeout: 5000,
        validateStatus: () => true,
        maxRedirects: 0  // Don't follow redirects
      });
      
      console.log(`[Scan ${this.scanId}] Found active subdomain: ${subdomain} (${response.status})`);
      
      // If subdomain exists, check for basic security issues
      if (response.status !== 404) {
        // Add as information rather than a vulnerability
        this.vulnerabilities.push({
          scanId: this.scanId,
          title: "Subdomain Discovery",
          type: VulnerabilityType.MISCONFIGURATION,
          severity: SeverityLevel.INFO,
          location: url,
          description: `Active subdomain discovered: ${subdomain}`,
          stepsToReproduce: `1. Navigate to: ${url}`,
          impact: "Discovered subdomains may have different security controls and could provide additional attack surface.",
          remediation: "Ensure all subdomains have proper security controls and are intended to be publicly accessible.",
          proofOfConcept: `curl -I ${url}`,
          cvssScore: "0.0",
          status: "open"
        });
        
        // If we find a test or staging subdomain, flag it as a potential issue
        if (['dev', 'test', 'staging', 'beta', 'demo'].some(env => subdomain.includes(env))) {
          this.vulnerabilities.push({
            scanId: this.scanId,
            title: "Development/Testing Environment Exposed",
            type: VulnerabilityType.MISCONFIGURATION,
            severity: SeverityLevel.MEDIUM,
            location: url,
            description: `A development or testing environment (${subdomain}) is publicly accessible.`,
            stepsToReproduce: `1. Navigate to: ${url}`,
            impact: "Development environments often have weaker security controls, debugging features enabled, or test credentials that could be leveraged by attackers.",
            remediation: "Restrict access to development and testing environments. Use IP filtering, VPN requirements, or password protection.",
            proofOfConcept: `curl -I ${url}`,
            cvssScore: "5.5",
            status: "open"
          });
        }
      }
    } catch (error) {
      // Subdomain likely doesn't exist or isn't accessible
      console.log(`[Scan ${this.scanId}] Subdomain ${subdomain} not found or error: ${(error as Error).message}`);
    }
  }
  
  private async discoverAndTestApiEndpoints(): Promise<void> {
    console.log(`[Scan ${this.scanId}] Discovering and testing API endpoints...`);
    
    try {
      // Common API endpoint patterns
      const apiPatterns = [
        '/api/',
        '/api/v1/',
        '/api/v2/',
        '/rest/',
        '/graphql',
        '/v1/',
        '/v2/',
        '/service/',
        '/services/',
        '/json/',
        '/api/users',
        '/api/products',
        '/api/items',
        '/api/data',
        '/wp-json/'
      ];
      
      // For comprehensive scans, check all patterns
      for (const pattern of apiPatterns) {
        const apiUrl = new URL(pattern, this.ensureUrlHasProtocol(this.targetUrl)).toString();
        
        try {
          // First try a GET request
          const response = await axios.get(apiUrl, {
            timeout: 5000,
            validateStatus: () => true,
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json'
            }
          });
          
          // Check if the response looks like an API (JSON format or API-like status codes)
          const isJson = response.headers['content-type']?.includes('json');
          const isApiResponse = isJson || 
                              response.status === 200 || 
                              response.status === 401 || 
                              response.status === 403;
          
          if (isApiResponse) {
            console.log(`[Scan ${this.scanId}] Found potential API endpoint: ${apiUrl} (${response.status})`);
            
            // Check for missing authentication
            if (response.status === 200) {
              // Look for data that suggests this should be authenticated
              let dataLooksPrivate = false;
              
              if (typeof response.data === 'object') {
                // Look for common sensitive data fields
                const sensitiveFields = ['user', 'id', 'email', 'password', 'token', 'private', 'account'];
                
                for (const field of sensitiveFields) {
                  if (JSON.stringify(response.data).includes(`"${field}"`)) {
                    dataLooksPrivate = true;
                    break;
                  }
                }
              }
              
              if (dataLooksPrivate) {
                this.vulnerabilities.push({
                  scanId: this.scanId,
                  title: "API Endpoint Missing Authentication",
                  type: VulnerabilityType.AUTH_BYPASS,
                  severity: SeverityLevel.HIGH,
                  location: apiUrl,
                  description: "The API endpoint returns what appears to be sensitive data without requiring authentication.",
                  stepsToReproduce: `1. Send a GET request to ${apiUrl} without authentication\n2. Observe that sensitive data is returned`,
                  impact: "Attackers can access sensitive data or functionality without authentication.",
                  remediation: "Implement proper authentication for all API endpoints that serve non-public data.",
                  proofOfConcept: `curl -H "Accept: application/json" ${apiUrl}`,
                  cvssScore: "7.5",
                  status: "open"
                });
              }
            }
            
            // Check for verbose error messages
            if (response.status >= 400 && response.status < 500) {
              let hasVerboseError = false;
              let errorDetails = '';
              
              if (typeof response.data === 'object') {
                // Check for detailed error messages
                const verboseErrorFields = ['stack', 'trace', 'exception', 'stacktrace', 'line', 'file'];
                
                for (const field of verboseErrorFields) {
                  if (JSON.stringify(response.data).includes(`"${field}"`)) {
                    hasVerboseError = true;
                    errorDetails = field;
                    break;
                  }
                }
              } else if (typeof response.data === 'string') {
                // Check for stack traces in text responses
                const verboseErrorPatterns = [
                  'at ', 'line ', 'file:', 'Exception', 'Error:', 'Stack trace:',
                  'SQL syntax', 'ORA-', 'Fatal error', 'Warning:'
                ];
                
                for (const pattern of verboseErrorPatterns) {
                  if (response.data.includes(pattern)) {
                    hasVerboseError = true;
                    errorDetails = pattern;
                    break;
                  }
                }
              }
              
              if (hasVerboseError) {
                this.vulnerabilities.push({
                  scanId: this.scanId,
                  title: "API Returns Verbose Error Messages",
                  type: VulnerabilityType.MISCONFIGURATION,
                  severity: SeverityLevel.LOW,
                  location: apiUrl,
                  description: `The API returns verbose error messages that may contain sensitive implementation details (${errorDetails}).`,
                  stepsToReproduce: `1. Send a request to ${apiUrl}\n2. Observe the detailed error information in the response`,
                  impact: "Verbose error messages can reveal internal implementation details, file paths, or other sensitive information that aids attackers.",
                  remediation: "Configure API error handling to return generic error messages in production. Implement proper logging for debugging.",
                  proofOfConcept: `curl -H "Accept: application/json" ${apiUrl}`,
                  cvssScore: "3.0",
                  status: "open"
                });
              }
            }
          }
        } catch (error) {
          // API endpoint doesn't exist or error occurred, continue to next
          continue;
        }
      }
      
    } catch (error) {
      console.error(`[Scan ${this.scanId}] Error in API discovery:`, error);
      // Continue with other checks
    }
  }
  
  private async attemptExploitation(): Promise<void> {
    console.log(`[Scan ${this.scanId}] Attempting to safely validate discovered vulnerabilities...`);
    
    try {
      // This is where real exploitation attempts would go in an actual penetration test
      // For ethical and legal reasons, we only perform safe validation of vulnerabilities
      
      console.log(`[Scan ${this.scanId}] Exploitation attempts would go here in a real penetration test with explicit permission`);
      
      // Add disclaimer note
      this.vulnerabilities.push({
        scanId: this.scanId,
        title: "Exploitation Note",
        type: VulnerabilityType.OTHER,
        severity: SeverityLevel.INFO,
        location: this.targetUrl,
        description: "For ethical and legal reasons, actual exploitation attempts were not performed. All vulnerabilities listed are potential issues that should be validated manually by authorized security personnel.",
        stepsToReproduce: "N/A - This is an informational note only.",
        impact: "N/A",
        remediation: "Review and validate the identified potential vulnerabilities in a controlled environment.",
        proofOfConcept: "N/A",
        cvssScore: "0.0",
        status: "open"
      });
      
    } catch (error) {
      console.error(`[Scan ${this.scanId}] Error during exploitation attempts:`, error);
      // Continue with other checks
    }
  }
}

export const startRealScan = async (scanId: number): Promise<{ success: boolean; message?: string }> => {
  const scan = await storage.getScan(scanId);
  
  if (!scan) {
    return { success: false, message: "Scan not found" };
  }
  
  // Ensure we have valid vulnerability types
  const vulnerabilityTypes = scan.vulnerabilityTypes || [];
  
  const scanner = new RealScanner(
    {
      targetUrl: scan.targetUrl,
      scanType: scan.scanType,
      vulnerabilityTypes: vulnerabilityTypes,
      scanIntensity: scan.scanIntensity,
      hasPermission: scan.hasPermission
    },
    scanId
  );
  
  return scanner.scan();
};