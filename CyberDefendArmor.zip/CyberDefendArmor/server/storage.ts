import { 
  users, type User, type InsertUser,
  scans, type Scan, type InsertScan,
  vulnerabilities, type Vulnerability, type InsertVulnerability,
  reports, type Report, type InsertReport,
  bountySubmissions, type BountySubmission, type InsertBountySubmission
} from "@shared/schema";

// Interface for all storage operations
export interface IStorage {
  // Screenshot and attachment operations
  saveScreenshot(vulnId: number, screenshot: Buffer): Promise<string>;
  getScreenshot(vulnId: number): Promise<Buffer | undefined>;
  
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Scan operations
  createScan(scan: InsertScan): Promise<Scan>;
  getScan(id: number): Promise<Scan | undefined>;
  getScans(): Promise<Scan[]>;
  updateScanStatus(id: number, status: string): Promise<Scan | undefined>;
  updateScanCompletion(id: number): Promise<Scan | undefined>;
  addScanHistory(scanId: number, results: any): Promise<void>; // Added function for scan history

  // Vulnerability operations
  createVulnerability(vuln: InsertVulnerability): Promise<Vulnerability>;
  getVulnerability(id: number): Promise<Vulnerability | undefined>;
  getVulnerabilitiesByScan(scanId: number): Promise<Vulnerability[]>;
  getVulnerabilities(): Promise<Vulnerability[]>;
  updateVulnerabilityStatus(id: number, status: string): Promise<Vulnerability | undefined>;

  // Report operations
  createReport(report: InsertReport): Promise<Report>;
  getReport(id: number): Promise<Report | undefined>;
  getReports(): Promise<Report[]>;
  updateReportPath(id: number, path: string): Promise<Report | undefined>;

  // Bounty submission operations
  createBountySubmission(submission: InsertBountySubmission): Promise<BountySubmission>;
  getBountySubmission(id: number): Promise<BountySubmission | undefined>;
  getBountySubmissions(): Promise<BountySubmission[]>;
  updateBountySubmissionStatus(id: number, status: string, reward?: string): Promise<BountySubmission | undefined>;

  // Dashboard statistics
  getScanStats(): Promise<{
    activeScans: number;
    totalVulnerabilities: number;
    reportsGenerated: number;
    bountySubmissions: number;
  }>;

  getVulnerabilityDistribution(): Promise<{
    critical: number;
    high: number;
    medium: number;
    low: number;
  }>;

  getVulnerabilityTypeDistribution(): Promise<{
    sqlInjection: number;
    xss: number;
    csrf: number;
    directoryTraversal: number;
    other: number;
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private scans: Map<number, Scan>;
  private screenshots: Map<number, Buffer> = new Map();
  
  async saveScreenshot(vulnId: number, screenshot: Buffer): Promise<string> {
    this.screenshots.set(vulnId, screenshot);
    return `screenshot_${vulnId}.png`;
  }

  async getScreenshot(vulnId: number): Promise<Buffer | undefined> {
    return this.screenshots.get(vulnId);
  }
  private scanHistory: Map<number, {timestamp: Date, results: any}[]>; // Added scan history
  private vulnerabilities: Map<number, Vulnerability>;
  private reports: Map<number, Report>;
  private bountySubmissions: Map<number, BountySubmission>;

  private userCurrentId: number;
  private scanCurrentId: number;
  private vulnCurrentId: number;
  private reportCurrentId: number;
  private submissionCurrentId: number;

  constructor() {
    this.users = new Map();
    this.scans = new Map();
    this.scanHistory = new Map(); // Initialize scan history
    this.vulnerabilities = new Map();
    this.reports = new Map();
    this.bountySubmissions = new Map();

    this.userCurrentId = 1;
    this.scanCurrentId = 1;
    this.vulnCurrentId = 1;
    this.reportCurrentId = 1;
    this.submissionCurrentId = 1;

    // Add default user
    this.createUser({
      username: "ethical_hacker",
      password: "secure_password123"
    });

    // Add sample data for demo purposes
    this.initializeDemoData();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Scan operations
  async createScan(insertScan: InsertScan): Promise<Scan> {
    const id = this.scanCurrentId++;
    const scan: Scan = { 
      ...insertScan, 
      id,
      startedAt: new Date(),
      completedAt: null
    };
    this.scans.set(id, scan);
    return scan;
  }

  async getScan(id: number): Promise<Scan | undefined> {
    return this.scans.get(id);
  }

  async getScans(): Promise<Scan[]> {
    return Array.from(this.scans.values()).sort((a, b) => 
      new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime()
    );
  }

  async updateScanStatus(id: number, status: string): Promise<Scan | undefined> {
    const scan = await this.getScan(id);
    if (!scan) return undefined;

    const updatedScan = { ...scan, status };
    this.scans.set(id, updatedScan);
    return updatedScan;
  }

  async updateScanCompletion(id: number): Promise<Scan | undefined> {
    const scan = await this.getScan(id);
    if (!scan) return undefined;

    const updatedScan = { 
      ...scan, 
      status: "completed",
      completedAt: new Date()
    };
    this.scans.set(id, updatedScan);
    return updatedScan;
  }

  async addScanHistory(scanId: number, results: any): Promise<void> {
    const history = this.scanHistory.get(scanId) || [];
    history.push({ timestamp: new Date(), results });
    this.scanHistory.set(scanId, history);
  } // Added function for scan history


  // Vulnerability operations
  async createVulnerability(insertVuln: InsertVulnerability): Promise<Vulnerability> {
    const id = this.vulnCurrentId++;
    const vulnerability: Vulnerability = { 
      ...insertVuln, 
      id,
      detectedAt: new Date()
    };
    this.vulnerabilities.set(id, vulnerability);
    return vulnerability;
  }

  async getVulnerability(id: number): Promise<Vulnerability | undefined> {
    return this.vulnerabilities.get(id);
  }

  async getVulnerabilitiesByScan(scanId: number): Promise<Vulnerability[]> {
    return Array.from(this.vulnerabilities.values())
      .filter(v => v.scanId === scanId)
      .sort((a, b) => {
        // Sort by severity (critical first)
        const severityOrder = { "critical": 0, "high": 1, "medium": 2, "low": 3 };
        return severityOrder[a.severity as keyof typeof severityOrder] - 
               severityOrder[b.severity as keyof typeof severityOrder];
      });
  }

  async getVulnerabilities(): Promise<Vulnerability[]> {
    return Array.from(this.vulnerabilities.values())
      .sort((a, b) => new Date(b.detectedAt).getTime() - new Date(a.detectedAt).getTime());
  }

  async updateVulnerabilityStatus(id: number, status: string): Promise<Vulnerability | undefined> {
    const vuln = await this.getVulnerability(id);
    if (!vuln) return undefined;

    const updatedVuln = { ...vuln, status };
    this.vulnerabilities.set(id, updatedVuln);
    return updatedVuln;
  }

  // Report operations
  async createReport(insertReport: InsertReport): Promise<Report> {
    const id = this.reportCurrentId++;
    const report: Report = { 
      ...insertReport, 
      id,
      createdAt: new Date(),
      reportPath: null
    };
    this.reports.set(id, report);
    return report;
  }

  async getReport(id: number): Promise<Report | undefined> {
    return this.reports.get(id);
  }

  async getReports(): Promise<Report[]> {
    return Array.from(this.reports.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async updateReportPath(id: number, path: string): Promise<Report | undefined> {
    const report = await this.getReport(id);
    if (!report) return undefined;

    const updatedReport = { ...report, reportPath: path };
    this.reports.set(id, updatedReport);
    return updatedReport;
  }

  // Bounty submission operations
  async createBountySubmission(insertSubmission: InsertBountySubmission): Promise<BountySubmission> {
    const id = this.submissionCurrentId++;
    const submission: BountySubmission = { 
      ...insertSubmission, 
      id,
      submittedAt: new Date()
    };
    this.bountySubmissions.set(id, submission);
    return submission;
  }

  async getBountySubmission(id: number): Promise<BountySubmission | undefined> {
    return this.bountySubmissions.get(id);
  }

  async getBountySubmissions(): Promise<BountySubmission[]> {
    return Array.from(this.bountySubmissions.values())
      .sort((a, b) => new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime());
  }

  async updateBountySubmissionStatus(
    id: number, 
    status: string, 
    reward?: string
  ): Promise<BountySubmission | undefined> {
    const submission = await this.getBountySubmission(id);
    if (!submission) return undefined;

    const updatedSubmission = { 
      ...submission, 
      status,
      reward: reward !== undefined ? reward : submission.reward
    };
    this.bountySubmissions.set(id, updatedSubmission);
    return updatedSubmission;
  }

  // Dashboard statistics
  async getScanStats(): Promise<{
    activeScans: number;
    totalVulnerabilities: number;
    reportsGenerated: number;
    bountySubmissions: number;
  }> {
    const scans = Array.from(this.scans.values());
    const activeScans = scans.filter(s => s.status === "in_progress").length;

    return {
      activeScans,
      totalVulnerabilities: this.vulnerabilities.size,
      reportsGenerated: this.reports.size,
      bountySubmissions: this.bountySubmissions.size
    };
  }

  async getVulnerabilityDistribution(): Promise<{
    critical: number;
    high: number;
    medium: number;
    low: number;
  }> {
    const vulns = Array.from(this.vulnerabilities.values());

    return {
      critical: vulns.filter(v => v.severity === "critical").length,
      high: vulns.filter(v => v.severity === "high").length,
      medium: vulns.filter(v => v.severity === "medium").length,
      low: vulns.filter(v => v.severity === "low").length
    };
  }

  async getVulnerabilityTypeDistribution(): Promise<{
    sqlInjection: number;
    xss: number;
    csrf: number;
    directoryTraversal: number;
    other: number;
  }> {
    const vulns = Array.from(this.vulnerabilities.values());
    const total = vulns.length;

    const sqlInjection = vulns.filter(v => v.type === "sql_injection").length;
    const xss = vulns.filter(v => v.type === "xss").length;
    const csrf = vulns.filter(v => v.type === "csrf").length;
    const directoryTraversal = vulns.filter(v => v.type === "directory_traversal").length;

    return {
      sqlInjection,
      xss,
      csrf,
      directoryTraversal,
      other: total - (sqlInjection + xss + csrf + directoryTraversal)
    };
  }

  // Initialize demo data
  private initializeDemoData() {
    // Create sample scans
    const scan1 = this.createScan({
      targetUrl: "example.com",
      status: "completed",
      scanType: "comprehensive",
      vulnerabilityTypes: ["sql_injection", "xss", "csrf", "directory_traversal"],
      scanIntensity: 4,
      hasPermission: true,
      startedAt: new Date(Date.now() - 24 * 60 * 60 * 1000) // 1 day ago
    });

    const scan2 = this.createScan({
      targetUrl: "secure-bank.org",
      status: "in_progress",
      scanType: "quick",
      vulnerabilityTypes: ["sql_injection", "xss", "csrf"],
      scanIntensity: 3,
      hasPermission: true,
      startedAt: new Date()
    });

    const scan3 = this.createScan({
      targetUrl: "testshop.com",
      status: "completed",
      scanType: "comprehensive",
      vulnerabilityTypes: ["sql_injection", "xss", "directory_traversal"],
      scanIntensity: 5,
      hasPermission: true,
      startedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000) // 2 days ago
    });

    // Update completed scans
    scan1.then(scan => {
      this.updateScanCompletion(scan.id);

      // Add sample vulnerabilities for completed scans
      this.createVulnerability({
        scanId: scan.id,
        title: "SQL Injection in Search Feature",
        type: "sql_injection",
        severity: "critical",
        location: "https://example.com/search?q=test",
        description: "The search feature is vulnerable to SQL injection attacks, allowing an attacker to manipulate database queries and potentially extract sensitive information.",
        stepsToReproduce: "1. Navigate to the search page\n2. Enter the payload: ' OR '1'='1\n3. Observe all records being returned",
        impact: "This vulnerability allows an attacker to access sensitive data, bypass authentication, and potentially execute administrative operations on the database.",
        remediation: "Use parameterized queries instead of string concatenation. Implement proper input validation and sanitization.",
        proofOfConcept: "GET /search?q=test%27%20OR%20%271%27%3D%271 HTTP/1.1\nHost: example.com",
        cvssScore: "9.8",
        status: "open"
      });

      this.createVulnerability({
        scanId: scan.id,
        title: "Cross-Site Scripting (XSS) in Comments",
        type: "xss",
        severity: "high",
        location: "https://example.com/comments",
        description: "The comments section is vulnerable to stored XSS attacks, allowing attackers to inject malicious scripts.",
        stepsToReproduce: "1. Navigate to any post with comments\n2. Add a comment with the payload: <script>alert('XSS')</script>\n3. When any user views the comment, the script executes",
        impact: "Attackers can steal session cookies, redirect users to malicious sites, or modify page content.",
        remediation: "Implement proper output encoding. Sanitize user inputs and use Content Security Policy (CSP).",
        proofOfConcept: "POST /comments HTTP/1.1\nHost: example.com\nContent-Type: application/x-www-form-urlencoded\n\ncomment=<script>alert('XSS')</script>",
        cvssScore: "7.5",
        status: "open"
      });

      this.createVulnerability({
        scanId: scan.id,
        title: "CSRF in Account Settings",
        type: "csrf",
        severity: "medium",
        location: "https://example.com/account/settings",
        description: "The account settings page is vulnerable to CSRF attacks, allowing attackers to change user settings without their knowledge.",
        stepsToReproduce: "1. Create a malicious HTML page with a form that submits to the account settings endpoint\n2. When a logged-in user visits the page, their settings are changed",
        impact: "Attackers can change user email, password, or other sensitive settings without user consent.",
        remediation: "Implement anti-CSRF tokens in all forms. Validate the origin and referrer headers.",
        proofOfConcept: "<form action='https://example.com/account/settings' method='POST'>\n  <input type='hidden' name='email' value='attacker@evil.com'>\n  <input type='submit' value='Click me'>\n</form>",
        cvssScore: "6.5",
        status: "open"
      });
    });

    scan3.then(scan => {
      this.updateScanCompletion(scan.id);

      this.createVulnerability({
        scanId: scan.id,
        title: "Directory Traversal in File Download",
        type: "directory_traversal",
        severity: "high",
        location: "https://testshop.com/download?file=product.pdf",
        description: "The file download feature is vulnerable to directory traversal attacks, allowing attackers to access files outside the intended directory.",
        stepsToReproduce: "1. Navigate to the download page\n2. Modify the file parameter to: ../../../etc/passwd\n3. Observe server files being exposed",
        impact: "Attackers can access sensitive configuration files, credentials, and other restricted files on the server.",
        remediation: "Validate and sanitize file path inputs. Use a whitelist of allowed files or file patterns.",
        proofOfConcept: "GET /download?file=..%2F..%2F..%2Fetc%2Fpasswd HTTP/1.1\nHost: testshop.com",
        cvssScore: "7.8",
        status: "open"
      });

      this.createVulnerability({
        scanId: scan.id,
        title: "Weak Authentication on Login Page",
        type: "auth_bypass",
        severity: "medium",
        location: "https://testshop.com/login",
        description: "The login page has weak authentication mechanisms, including no account lockout after multiple failed attempts.",
        stepsToReproduce: "1. Attempt to login with incorrect credentials multiple times\n2. Observe that no lockout occurs, enabling brute force attacks",
        impact: "Attackers can use brute force techniques to guess user passwords and gain unauthorized access.",
        remediation: "Implement account lockout after multiple failed attempts. Use strong password policies and multi-factor authentication.",
        proofOfConcept: "Automated script to try multiple password combinations without being blocked",
        cvssScore: "6.2",
        status: "open"
      });
    });

    // Create some sample reports
    scan1.then(scan => {
      this.createReport({
        title: "Security Assessment - Example.com",
        scanId: scan.id,
        format: "pdf",
        vulnerabilityIds: [1, 2, 3],
        sections: ["executive_summary", "technical_details", "remediation", "screenshots", "risk_analysis"],
        createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000) // 12 hours ago
      });
    });

    scan3.then(scan => {
      this.createReport({
        title: "Vulnerability Report - TestShop.com",
        scanId: scan.id,
        format: "docx",
        vulnerabilityIds: [4, 5],
        sections: ["executive_summary", "technical_details", "remediation", "risk_analysis"],
        createdAt: new Date(Date.now() - 36 * 60 * 60 * 1000) // 36 hours ago
      });
    });

    // Create some sample bounty submissions
    Promise.all([
      this.getVulnerability(1),
      this.getVulnerability(2),
      this.getVulnerability(4)
    ]).then(([vuln1, vuln2, vuln4]) => {
      if (vuln1) {
        this.createBountySubmission({
          vulnerabilityId: vuln1.id,
          platform: "hackerone",
          title: "SQL Injection in Search Feature",
          description: vuln1.description,
          stepsToReproduce: vuln1.stepsToReproduce,
          impact: vuln1.impact,
          severity: vuln1.severity,
          suggestedFix: vuln1.remediation,
          status: "accepted",
          reward: "$500",
          submittedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) // 7 days ago
        });
      }

      if (vuln2) {
        this.createBountySubmission({
          vulnerabilityId: vuln2.id,
          platform: "bugcrowd",
          title: "XSS in Comments Section",
          description: vuln2.description,
          stepsToReproduce: vuln2.stepsToReproduce,
          impact: vuln2.impact,
          severity: vuln2.severity,
          suggestedFix: vuln2.remediation,
          status: "in_review",
          reward: null,
          submittedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000) // 3 days ago
        });
      }

      if (vuln4) {
        this.createBountySubmission({
          vulnerabilityId: vuln4.id,
          platform: "hackerone",
          title: "Directory Traversal in File Download",
          description: vuln4.description,
          stepsToReproduce: vuln4.stepsToReproduce,
          impact: vuln4.impact,
          severity: vuln4.severity,
          suggestedFix: vuln4.remediation,
          status: "needs_info",
          reward: null,
          submittedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000) // 5 days ago
        });
      }
    });
  }
}

export const storage = new MemStorage();