import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import * as crypto from "crypto";
import { storage } from "./storage";
import { startScan } from "./scanner";
import { startRealScan } from "./realScanner";
import { 
  insertScanSchema, 
  insertVulnerabilitySchema, 
  insertReportSchema,
  insertBountySubmissionSchema
} from "@shared/schema";
import { 
  configureDirectReporting, 
  getAllReports, 
  clearAllReports, 
  getReportById, 
  deleteReport, 
  setHttpServer, 
  sendTestDirectEmail,
  generateAndSendPdfReport,
  generateAndSendWordReport,
  sendDirectReport,
  reportStore
} from "./directReporting";
import { 
  getAllCTFChallenges, 
  getCTFChallengeById, 
  startCTFChallenge, 
  submitCTFFlag, 
  getCTFProgress,
  scanCTFChallenge,
  CTFCategories
} from "./ctfChallenges";
import { NotificationMethod, DirectVulnerabilityReport } from "@shared/types";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes for the application
  
  // Get dashboard stats
  app.get("/api/stats", async (req: Request, res: Response) => {
    try {
      const scanStats = await storage.getScanStats();
      const vulnDistribution = await storage.getVulnerabilityDistribution();
      const vulnTypeDistribution = await storage.getVulnerabilityTypeDistribution();
      
      res.json({
        scanStats,
        vulnDistribution,
        vulnTypeDistribution
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });
  
  // Scan routes
  app.post("/api/scans", async (req: Request, res: Response) => {
    try {
      const scanData = insertScanSchema.parse(req.body);
      const scan = await storage.createScan(scanData);
      
      // Check if this is a real scan or simulated scan
      const useRealScanner = req.body.useRealScanner === true;
      
      // Start the scan in the background
      const scanFunction = useRealScanner ? startRealScan : startScan;
      scanFunction(scan.id)
        .then(result => {
          console.log(`Scan ${scan.id} completed: ${result.message}`);
        })
        .catch(err => {
          console.error(`Scan ${scan.id} failed:`, err);
        });
      
      res.status(201).json({ ...scan, useRealScanner });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid scan data", 
          errors: error.errors
        });
      }
      res.status(500).json({ message: "Failed to create scan" });
    }
  });
  
  app.get("/api/scans", async (req: Request, res: Response) => {
    try {
      const scans = await storage.getScans();
      res.json(scans);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch scans" });
    }
  });
  
  app.get("/api/scans/:id", async (req: Request, res: Response) => {
    try {
      const scanId = parseInt(req.params.id);
      if (isNaN(scanId)) {
        return res.status(400).json({ message: "Invalid scan ID" });
      }
      
      const scan = await storage.getScan(scanId);
      if (!scan) {
        return res.status(404).json({ message: "Scan not found" });
      }
      
      res.json(scan);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch scan" });
    }
  });
  
  // Vulnerability routes
  app.get("/api/vulnerabilities", async (req: Request, res: Response) => {
    try {
      const scanId = req.query.scanId ? parseInt(req.query.scanId as string) : undefined;
      
      let vulnerabilities;
      if (scanId && !isNaN(scanId)) {
        vulnerabilities = await storage.getVulnerabilitiesByScan(scanId);
      } else {
        vulnerabilities = await storage.getVulnerabilities();
      }
      
      res.json(vulnerabilities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch vulnerabilities" });
    }
  });
  
  app.get("/api/vulnerabilities/:id", async (req: Request, res: Response) => {
    try {
      const vulnId = parseInt(req.params.id);
      if (isNaN(vulnId)) {
        return res.status(400).json({ message: "Invalid vulnerability ID" });
      }
      
      const vulnerability = await storage.getVulnerability(vulnId);
      if (!vulnerability) {
        return res.status(404).json({ message: "Vulnerability not found" });
      }
      
      // Get screenshot if available
      const screenshot = await storage.getScreenshot(vulnId);
      
      res.json({
        ...vulnerability,
        hasScreenshot: !!screenshot
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch vulnerability" });
    }
  });

  // Screenshot endpoints
  app.get("/api/vulnerabilities/:id/screenshot", async (req: Request, res: Response) => {
    try {
      const vulnId = parseInt(req.params.id);
      if (isNaN(vulnId)) {
        return res.status(400).json({ message: "Invalid vulnerability ID" });
      }
      
      const screenshot = await storage.getScreenshot(vulnId);
      if (!screenshot) {
        return res.status(404).json({ message: "Screenshot not found" });
      }
      
      res.setHeader('Content-Type', 'image/png');
      res.setHeader('Content-Disposition', `attachment; filename="vulnerability-${vulnId}-proof.png"`);
      res.send(screenshot);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch screenshot" });
    }
  });

  app.post("/api/vulnerabilities/:id/screenshot", async (req: Request, res: Response) => {
    try {
      const vulnId = parseInt(req.params.id);
      if (isNaN(vulnId)) {
        return res.status(400).json({ message: "Invalid vulnerability ID" });
      }

      if (!req.body.screenshot) {
        return res.status(400).json({ message: "Screenshot data is required" });
      }

      const screenshotBuffer = Buffer.from(req.body.screenshot, 'base64');
      const path = await storage.saveScreenshot(vulnId, screenshotBuffer);
      
      res.json({ success: true, path });
    } catch (error) {
      res.status(500).json({ message: "Failed to save screenshot" });
    }
  });
  
  app.patch("/api/vulnerabilities/:id/status", async (req: Request, res: Response) => {
    try {
      const vulnId = parseInt(req.params.id);
      if (isNaN(vulnId)) {
        return res.status(400).json({ message: "Invalid vulnerability ID" });
      }
      
      const statusSchema = z.object({
        status: z.string()
      });
      
      const { status } = statusSchema.parse(req.body);
      
      const vulnerability = await storage.updateVulnerabilityStatus(vulnId, status);
      if (!vulnerability) {
        return res.status(404).json({ message: "Vulnerability not found" });
      }
      
      res.json(vulnerability);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid status data", 
          errors: error.errors
        });
      }
      res.status(500).json({ message: "Failed to update vulnerability status" });
    }
  });
  
  // Report routes
  app.post("/api/reports", async (req: Request, res: Response) => {
    try {
      const reportData = insertReportSchema.parse(req.body);
      const report = await storage.createReport(reportData);
      
      try {
        // Ensure reports directory exists
        const reportsDir = path.join(process.cwd(), 'reports');
        await fs.promises.mkdir(reportsDir, { recursive: true });

        // Generate report buffer
        let buffer: Buffer;
        if (reportData.format === 'pdf') {
          console.log('Generating PDF report...');
          buffer = await generatePdfReport(reportData.vulnerabilities, reportData.targetUrl);
        } else {
          console.log('Generating Word report...');
          buffer = await generateWordReport(reportData.vulnerabilities, reportData.targetUrl);
        }
        
        const reportPath = `/reports/${report.id}_${report.title.replace(/[^a-zA-Z0-9]/g, '_')}.${report.format}`;
        await storage.updateReportPath(report.id, reportPath);
        
        // Save the report file
        const fullPath = path.join(reportsDir, path.basename(reportPath));
        await fs.promises.writeFile(fullPath, buffer);
        
        console.log(`Report successfully saved to ${fullPath}`);
        res.status(201).json({ ...report, path: reportPath });
      } catch (error) {
        console.error('Error generating report:', error);
        await storage.deleteReport(report.id);
        throw error;
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid report data", 
          errors: error.errors
        });
      }
      res.status(500).json({ message: "Failed to create report" });
    }
  });
  
  app.get("/api/reports", async (req: Request, res: Response) => {
    try {
      const reports = await storage.getReports();
      res.json(reports);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reports" });
    }
  });
  
  app.get("/api/reports/:id", async (req: Request, res: Response) => {
    try {
      const reportId = parseInt(req.params.id);
      if (isNaN(reportId)) {
        return res.status(400).json({ message: "Invalid report ID" });
      }
      
      const report = await storage.getReport(reportId);
      if (!report) {
        return res.status(404).json({ message: "Report not found" });
      }
      
      res.json(report);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch report" });
    }
  });
  
  // Bounty submission routes
  app.post("/api/bounty-submissions", async (req: Request, res: Response) => {
    try {
      const submissionData = insertBountySubmissionSchema.parse(req.body);
      const submission = await storage.createBountySubmission(submissionData);
      
      res.status(201).json(submission);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid submission data", 
          errors: error.errors
        });
      }
      res.status(500).json({ message: "Failed to create bounty submission" });
    }
  });
  
  app.get("/api/bounty-submissions", async (req: Request, res: Response) => {
    try {
      const submissions = await storage.getBountySubmissions();
      res.json(submissions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bounty submissions" });
    }
  });
  
  app.patch("/api/bounty-submissions/:id/status", async (req: Request, res: Response) => {
    try {
      const submissionId = parseInt(req.params.id);
      if (isNaN(submissionId)) {
        return res.status(400).json({ message: "Invalid submission ID" });
      }
      
      const statusSchema = z.object({
        status: z.string(),
        reward: z.string().optional()
      });
      
      const { status, reward } = statusSchema.parse(req.body);
      
      const submission = await storage.updateBountySubmissionStatus(submissionId, status, reward);
      if (!submission) {
        return res.status(404).json({ message: "Submission not found" });
      }
      
      res.json(submission);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid status data", 
          errors: error.errors
        });
      }
      res.status(500).json({ message: "Failed to update submission status" });
    }
  });

  // Direct reporting API routes
  app.post("/api/reporting/config", async (req: Request, res: Response) => {
    try {
      const configSchema = z.object({
        reportEmail: z.string().email().optional(),
        webhookUrl: z.string().url().optional(),
        notificationMethod: z.enum([NotificationMethod.EMAIL, NotificationMethod.WEBHOOK]).optional(),
        includeScreenshots: z.boolean().optional(),
        includePoc: z.boolean().optional()
      });
      
      const config = configSchema.parse(req.body);
      
      // Configure the direct reporting system
      configureDirectReporting(config);
      
      res.status(200).json({ 
        message: "Reporting configuration updated successfully", 
        config 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid configuration data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ 
        message: "Failed to update reporting configuration" 
      });
    }
  });
  
  // Create a new direct report
  app.post("/api/direct-reports", async (req: Request, res: Response) => {
    try {
      const { vulnerability, targetUrl } = req.body;
      
      if (!vulnerability || !targetUrl) {
        return res.status(400).json({
          success: false,
          message: "vulnerability and targetUrl are required"
        });
      }
      
      // Create a direct report
      const reportId = crypto.randomUUID();
      const report: DirectVulnerabilityReport = {
        reportId,
        title: vulnerability.title,
        severity: vulnerability.severity,
        description: vulnerability.description,
        location: vulnerability.location,
        impact: vulnerability.impact,
        details: vulnerability.proofOfConcept,
        request: vulnerability.stepsToReproduce,
        response: vulnerability.response || null,
        remediation: vulnerability.remediation,
        targetUrl,
        timestamp: new Date().toISOString()
      };
      
      // Store the report in our local store for API access
      reportStore.set(reportId, report);
      
      // Send the report via email
      const emailSent = await sendDirectReport(report);
      
      res.status(200).json({
        success: true,
        message: "Vulnerability report created and " + (emailSent ? "sent" : "stored"),
        reportId
      });
    } catch (error) {
      console.error("Error creating direct report:", error);
      res.status(500).json({
        success: false,
        message: "Failed to create vulnerability report",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  app.get("/api/direct-reports", async (req: Request, res: Response) => {
    try {
      const reports = getAllReports();
      res.status(200).json(reports);
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to fetch direct reports" 
      });
    }
  });
  
  app.get("/api/direct-reports/:id", async (req: Request, res: Response) => {
    try {
      const reportId = req.params.id;
      const report = getReportById(reportId);
      
      if (!report) {
        return res.status(404).json({ 
          message: "Direct report not found" 
        });
      }
      
      res.status(200).json(report);
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to fetch direct report" 
      });
    }
  });
  
  app.delete("/api/direct-reports/:id", async (req: Request, res: Response) => {
    try {
      const reportId = req.params.id;
      const success = deleteReport(reportId);
      
      if (!success) {
        return res.status(404).json({ 
          message: "Direct report not found" 
        });
      }
      
      res.status(200).json({ 
        message: "Direct report deleted successfully" 
      });
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to delete direct report" 
      });
    }
  });
  
  app.delete("/api/direct-reports", async (req: Request, res: Response) => {
    try {
      clearAllReports();
      res.status(200).json({ 
        message: "All direct reports cleared successfully" 
      });
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to clear direct reports" 
      });
    }
  });
  
  // Test endpoint for WebSocket broadcasts
  app.post("/api/direct-report/test", async (req: Request, res: Response) => {
    try {
      const vulnerability = req.body;
      
      // Broadcast to all WebSocket clients
      const wss = (httpServer as any).wss as WebSocketServer;
      
      if (!wss) {
        return res.status(500).json({ message: "WebSocket server not initialized" });
      }
      
      const notification = {
        type: 'vulnerability',
        severity: vulnerability.severity,
        title: vulnerability.title,
        description: vulnerability.description,
        timestamp: new Date().toISOString(),
        targetUrl: vulnerability.targetUrl,
        reportId: vulnerability.reportId
      };
      
      let connectedClients = 0;
      
      wss.clients.forEach((client: WebSocket) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify(notification));
          connectedClients++;
        }
      });
      
      res.status(200).json({ 
        message: `Test notification broadcast to ${connectedClients} clients`,
        notification
      });
    } catch (error) {
      console.error('Error in test endpoint:', error);
      res.status(500).json({ 
        message: "Failed to broadcast test notification", 
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  const httpServer = createServer(app);
  
  // Set up WebSocket server for real-time notifications
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  wss.on('connection', (ws: WebSocket) => {
    console.log('WebSocket client connected');
    
    // Send a welcome message
    ws.send(JSON.stringify({
      type: 'connection',
      message: 'Connected to real-time vulnerability notification system'
    }));

    // Add error handler
    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
    });

    // Add ping/pong for connection keep-alive
    const pingInterval = setInterval(() => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.ping();
      }
    }, 30000);
    
    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        console.log('Received message:', data);
        
        // Handle different message types (if needed)
        if (data.type === 'ping') {
          ws.send(JSON.stringify({ type: 'pong', timestamp: new Date().toISOString() }));
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    });
    
    ws.on('close', () => {
      console.log('WebSocket client disconnected');
      clearInterval(pingInterval);
    });
  });
  
  // Export the WebSocket server for use in other modules
  (httpServer as any).wss = wss;
  
  // CTF Challenge Routes
  app.get("/api/ctf/challenges", async (req: Request, res: Response) => {
    try {
      const challenges = getAllCTFChallenges();
      res.status(200).json(challenges);
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to fetch CTF challenges" 
      });
    }
  });

  app.get("/api/ctf/challenges/:id", async (req: Request, res: Response) => {
    try {
      const challengeId = req.params.id;
      const challenge = getCTFChallengeById(challengeId);
      
      if (!challenge) {
        return res.status(404).json({ 
          message: "CTF challenge not found" 
        });
      }
      
      res.status(200).json(challenge);
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to fetch CTF challenge" 
      });
    }
  });

  app.get("/api/ctf/categories", async (req: Request, res: Response) => {
    try {
      res.status(200).json(CTFCategories);
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to fetch CTF categories" 
      });
    }
  });

  app.post("/api/ctf/start", async (req: Request, res: Response) => {
    try {
      const startSchema = z.object({
        userId: z.number(),
        challengeId: z.string()
      });
      
      const { userId, challengeId } = startSchema.parse(req.body);
      
      // Start the CTF challenge
      const sessionId = startCTFChallenge(userId, challengeId);
      
      res.status(200).json({
        success: true,
        sessionId,
        message: "Challenge started successfully"
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid start challenge data", 
          errors: error 
        });
      }
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to start CTF challenge" 
      });
    }
  });

  app.post("/api/ctf/flag", async (req: Request, res: Response) => {
    try {
      const flagSchema = z.object({
        sessionId: z.string(),
        flagValue: z.string()
      });
      
      const { sessionId, flagValue } = flagSchema.parse(req.body);
      
      // Submit the flag
      const result = submitCTFFlag(sessionId, flagValue);
      
      res.status(200).json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid flag submission data", 
          errors: error 
        });
      }
      res.status(500).json({ 
        message: "Failed to submit flag" 
      });
    }
  });

  app.get("/api/ctf/progress/:sessionId", async (req: Request, res: Response) => {
    try {
      const sessionId = req.params.sessionId;
      const progress = getCTFProgress(sessionId);
      
      if (!progress) {
        return res.status(404).json({ 
          message: "CTF session not found" 
        });
      }
      
      res.status(200).json(progress);
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to fetch CTF progress" 
      });
    }
  });

  app.post("/api/ctf/scan", async (req: Request, res: Response) => {
    try {
      const scanSchema = z.object({
        sessionId: z.string(),
        scanId: z.number()
      });
      
      const { sessionId, scanId } = scanSchema.parse(req.body);
      
      // Scan the CTF challenge
      const result = await scanCTFChallenge(sessionId, scanId);
      
      res.status(200).json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid CTF scan data", 
          errors: error 
        });
      }
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to scan CTF challenge" 
      });
    }
  });

  // Email testing endpoint
  app.post("/api/email/test", async (req: Request, res: Response) => {
    console.log("Received test email request");
    
    try {
      const success = await sendTestDirectEmail();
      
      if (success) {
        res.status(200).json({ 
          success: true, 
          message: 'Test email sent successfully' 
        });
      } else {
        res.status(500).json({ 
          success: false, 
          message: 'Failed to send test email' 
        });
      }
    } catch (error) {
      console.error("Error sending test email:", error);
      res.status(500).json({ 
        success: false, 
        message: 'Failed to send test email',
        error: String(error)
      });
    }
  });
  
  // PDF report generation and email endpoint
  app.post("/api/reports/pdf", async (req: Request, res: Response) => {
    console.log("Received PDF report generation request");
    const { vulnerabilities, targetUrl } = req.body;
    
    if (!vulnerabilities || !targetUrl) {
      return res.status(400).json({ 
        success: false, 
        message: 'vulnerabilities and targetUrl are required' 
      });
    }
    
    try {
      const success = await generateAndSendPdfReport(vulnerabilities, targetUrl);
      
      if (success) {
        res.status(200).json({ 
          success: true, 
          message: 'PDF report generated and sent successfully' 
        });
      } else {
        res.status(500).json({ 
          success: false, 
          message: 'Failed to generate or send PDF report' 
        });
      }
    } catch (error) {
      console.error("Error generating PDF report:", error);
      res.status(500).json({ 
        success: false, 
        message: 'Failed to generate PDF report',
        error: String(error)
      });
    }
  });
  
  // Word document report generation and email endpoint
  app.post("/api/reports/word", async (req: Request, res: Response) => {
    console.log("Received Word report generation request");
    const { vulnerabilities, targetUrl } = req.body;
    
    if (!vulnerabilities || !targetUrl) {
      return res.status(400).json({ 
        success: false, 
        message: 'vulnerabilities and targetUrl are required' 
      });
    }
    
    try {
      const success = await generateAndSendWordReport(vulnerabilities, targetUrl);
      
      if (success) {
        res.status(200).json({ 
          success: true, 
          message: 'Word report generated and sent successfully' 
        });
      } else {
        res.status(500).json({ 
          success: false, 
          message: 'Failed to generate or send Word report' 
        });
      }
    } catch (error) {
      console.error("Error generating Word report:", error);
      res.status(500).json({ 
        success: false, 
        message: 'Failed to generate Word report',
        error: String(error)
      });
    }
  });
  
  // Set the HTTP server for direct reporting to enable WebSocket broadcasts
  setHttpServer(httpServer);
  
  return httpServer;
}
