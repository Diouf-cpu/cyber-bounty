// Type definitions for external modules

declare module 'node-nmap' {
  export class NmapScan {
    constructor(target: string, args: string);
    on(event: string, callback: (data: any) => void): void;
    startScan(): void;
  }
}