/**
 * Simple test script to debug Word document generation
 */
import { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType } from 'docx';
import * as fs from 'fs';
import * as path from 'path';

// Function to generate a simple Word document
async function generateSimpleWordDoc() {
  console.log('Starting simple Word document generation test...');
  
  try {
    // Create document
    console.log('Creating Word document...');
    const doc = new Document({
      sections: [{
        properties: {},
        children: [
          new Paragraph({
            text: 'Test Word Document',
            heading: HeadingLevel.TITLE,
            alignment: AlignmentType.CENTER
          }),
          
          new Paragraph({
            text: 'This is a test Word document',
            alignment: AlignmentType.CENTER
          }),
          
          new Paragraph({
            text: `Generated on: ${new Date().toLocaleString()}`,
            alignment: AlignmentType.CENTER
          }),
          
          new Paragraph({
            text: '', // Empty paragraph for spacing
          }),
          
          new Paragraph({
            text: 'Sample Heading',
            heading: HeadingLevel.HEADING_1
          }),
          
          new Paragraph({
            text: 'This is sample text for testing Word document generation.'
          })
        ]
      }]
    });
    
    console.log('Word document created with content');
    
    // Generate the document as a buffer
    console.log('Generating buffer from document...');
    const buffer = await Packer.toBuffer(doc);
    console.log(`Word document generated successfully. Buffer size: ${buffer.length} bytes`);
    
    // Save document to disk
    try {
      const reportsDir = path.join(process.cwd(), 'reports');
      console.log(`Reports directory path: ${reportsDir}`);
      
      // Create directory if it doesn't exist
      if (!fs.existsSync(reportsDir)) {
        console.log(`Creating reports directory at ${reportsDir}`);
        fs.mkdirSync(reportsDir, { recursive: true });
      }
      
      const filename = `test_debug_${new Date().toISOString().split('T')[0]}.docx`;
      const filePath = path.join(reportsDir, filename);
      console.log(`Writing file to: ${filePath}`);
      
      fs.writeFileSync(filePath, buffer);
      
      if (fs.existsSync(filePath)) {
        const stats = fs.statSync(filePath);
        console.log(`File successfully saved: ${filePath}, size: ${stats.size} bytes`);
      } else {
        console.error(`Failed to save file: ${filePath}`);
      }
      
      return { success: true, buffer, filePath };
    } catch (error) {
      console.error('Error saving Word document to disk:', error);
      throw error;
    }
  } catch (error) {
    console.error('Error generating Word document:', error);
    if (error.stack) {
      console.error(error.stack);
    }
    throw error;
  }
}

// Execute the test
async function runTest() {
  try {
    console.log('Starting Word document debug test');
    const result = await generateSimpleWordDoc();
    
    console.log('Word document test completed successfully');
    console.log(`Word document file available at: ${result.filePath}`);
  } catch (error) {
    console.error('Test failed with error:', error);
  }
}

// Run the test
runTest();